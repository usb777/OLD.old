//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_flur.h"
#include "Udm.h"
#include "CL_MY_DBWork.h"
#include "U_sprPolnySpisok.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_flur *F_flur;
MY_DBWork* wdb =new MY_DBWork;

TComboBox* cb[14];
String gl_dat[3];
String gl_sql="SELECT flu.flu_nom, flu.srz_tabnom, srz.FAM, srz.IM, srz.OTCH, srz.DR, srz.POL, srz.CEX, prof.NAIMPROF, flu.flu_data, flu.flu_mesto, flu.flu_nomer, flu.flu_doz, flu.flu_result, flu.flu_konting, flu.flu_vredn FROM flu INNER JOIN (srz INNER JOIN prof ON srz.PROF = prof.KODPROF) ON flu.srz_tabnom = srz.TN";




//----------------------------------------------------------
__fastcall TF_flur::TF_flur(TComponent* Owner)
        : TForm(Owner)
{
    cb[0]=Comfam;
    cb[1]=ComboBox1;
    cb[2]=ComboBox2;
    cb[3]=ComboBox3;
    cb[4]=ComboBox4;
    cb[5]=ComboBox5;
    cb[6]=ComboBox6;
    cb[7]=ComboBox7;
  //  cb[8]=ComboBox8;
    cb[9]=ComboBox9;
    cb[10]=ComboBox10;
    cb[11]=ComboBox11;
    cb[12]=ComboBox12;
    cb[13]=ComboBox13;


}
//---------------------------------------------------------------------------


void __fastcall TF_flur::Button5Click(TObject *Sender)
{
gbb->Visible=false;
}
//---------------------------------------------------------------------------

void __fastcall TF_flur::butaClick(TObject *Sender)
{
gbb->Caption=buta->Caption;

//Edit1->Clear();
//Edit1->Text="1063";
try
 {  dm->aqsrz->First();
  Edit1->Text=IntToStr(dm->aqsrz->FieldByName("tn")->AsInteger);
  }
 catch (Exception &e)   // "�" - ��� ������
 {  ShowMessage("������� ������: "+e.Message);   // ���������� "�" � ����� ���������  
 }

  dtp1->Date=Now();
 // dtp2->Date=Now();

Edit2->Clear();
Edit3->Clear();
Edit4->Clear();
Edit5->Clear();
Edit6->Clear();

ComboBox8->Text="";
ComboBox13->Text="";


Label14->Caption="";
Label15->Caption="";
Label16->Caption="";
Label17->Caption="";
Label18->Caption="";
Label19->Caption="";

gbb->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TF_flur::butuClick(TObject *Sender)
{

gbb->Caption=butu->Caption;
gbb->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::butdClick(TObject *Sender)
{

gbb->Caption=butd->Caption;
gbb->Visible=true;

 if (MessageDlg("������� ������� ������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {
  //   delete  from telsp where pns=:pns1
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="delete  from flu where flu_nom=:flu_nom";
        qub->Parameters->ParamByName("flu_nom")->Value=dm->aqflur->FieldByName("flu_nom")->AsInteger;
        qub->ExecSQL();
    sb1->Click();
    gbb->Visible=false;

  }
else
    {
       gbb->Visible=false;
    }








}
//---------------------------------------------------------------------------

void __fastcall TF_flur::BitokClick(TObject *Sender)
{


        gl_dat[1]=DateToStr(dtp1->DateTime);
     //   gl_dat[2]=DateToStr(dtp2->DateTime);


if (MessageDlg("�� ������� � ��������� ������?",mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {

  try
    {
       if (gbb->Caption==buta->Caption)
      {

 //     "SELECT flu.flu_nom, flu.srz_tabnom, srz.FAM, srz.IM, srz.OTCH, srz.DR, srz.POL, srz.CEX, prof.NAIMPROF, flu.flu_data, flu.flu_mesto, flu.flu_nomer, flu.flu_doz, flu.flu_result, flu.flu_konting, flu.flu_vredn,  flu.flu_grup  FROM flu INNER JOIN (srz INNER JOIN prof ON srz.PROF = prof.KODPROF) ON flu.srz_tabnom = srz.TN";

      //  ShowMessage("����������");
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="insert into flu (srz_tabnom,flu_data,flu_mesto,flu_nomer,flu_doz, flu_result, flu_konting, flu_vredn) values(:srz_tabnom, :flu_data, :flu_mesto,:flu_nomer, :flu_doz, :flu_result, :flu_konting, :flu_vredn) ";
    //    ShowMessage(qub->SQL->Text);
        qub->Parameters->ParamByName("srz_tabnom")->Value=StrToInt(Edit1->Text);
        qub->Parameters->ParamByName("flu_data")->Value=StrToDate(gl_dat[1]);
        qub->Parameters->ParamByName("flu_mesto")->Value=Edit2->Text;
        qub->Parameters->ParamByName("flu_nomer")->Value=Edit3->Text;
        qub->Parameters->ParamByName("flu_doz")->Value=Edit4->Text;
        qub->Parameters->ParamByName("flu_result")->Value=Edit5->Text;
        qub->Parameters->ParamByName("flu_konting")->Value=ComboBox8->Text;
        qub->Parameters->ParamByName("flu_vredn")->Value=Edit6->Text;

        qub->ExecSQL();

       }

       if (gbb->Caption==butu->Caption)
      {
    //    ShowMessage("���������");
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="update flu set srz_tabnom=:srz_tabnom, flu_data=:flu_data, flu_mesto=:flu_mesto, flu_nomer=:flu_nomer, flu_doz=:flu_doz, flu_result=:flu_result, flu_konting=:flu_konting, flu_vredn=:flu_vredn where flu_nom=:flu_nom";

        qub->Parameters->ParamByName("srz_tabnom")->Value=StrToInt(Edit1->Text);
        qub->Parameters->ParamByName("flu_data")->Value=StrToDate(gl_dat[1]);
        qub->Parameters->ParamByName("flu_mesto")->Value=Edit2->Text;
        qub->Parameters->ParamByName("flu_nomer")->Value=Edit3->Text;
        qub->Parameters->ParamByName("flu_doz")->Value=Edit4->Text;
        qub->Parameters->ParamByName("flu_result")->Value=Edit5->Text;
        qub->Parameters->ParamByName("flu_konting")->Value=ComboBox8->Text;
        qub->Parameters->ParamByName("flu_vredn")->Value=Edit6->Text;

      qub->Parameters->ParamByName("flu_nom")->Value=dm->aqflur->FieldByName("flu_nom")->AsInteger;


        qub->ExecSQL();


       }

    } //try end
   catch  (Exception &e)   // "�" - ��� ������
     {
       ShowMessage("������� ������: "+e.Message);
         // ���������� "�" � ����� ���������
     }

  }
else
    {

    }



gbb->Visible=false;
//FormCreate(Sender);
sb1->Click();

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::BitcanClick(TObject *Sender)
{

  gbb->Visible=false;

}
//---------------------------------------------------------------------------


void __fastcall TF_flur::DSbolDataChange(TObject *Sender, TField *Field)
{

 dtp1->Date=dm->aqflur->FieldByName("flu_data")->AsDateTime;

 Edit1->Text=dm->aqflur->FieldByName("srz_tabnom")->AsString;
 Edit2->Text=dm->aqflur->FieldByName("flu_mesto")->AsString;
 Edit3->Text=dm->aqflur->FieldByName("flu_nomer")->AsString;
 Edit4->Text=dm->aqflur->FieldByName("flu_doz")->AsString;
 Edit5->Text=dm->aqflur->FieldByName("flu_result")->AsString;
 Edit6->Text=dm->aqflur->FieldByName("flu_vredn")->AsString;

 ComboBox8->Text=dm->aqflur->FieldByName("flu_konting")->AsString;


TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("Tn",Edit1->Text,Opts);


Label14->Caption=dm->aqsrz->FieldByName("Fam")->AsString;
Label15->Caption=dm->aqsrz->FieldByName("Im")->AsString;
Label16->Caption=dm->aqsrz->FieldByName("Otch")->AsString;
Label17->Caption=dm->aqsrz->FieldByName("dr")->AsString;
Label18->Caption=dm->aqsrz->FieldByName("CEX")->AsString;
Label19->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::sb1Click(TObject *Sender)
{

  dm->aqflur->Close();
  dm->aqflur->SQL->Clear();
  dm->aqflur->SQL->Text=gl_sql+" order by srz.FAM ";
  dm->aqflur->Open();
//  FormCreate(Sender);



}
//---------------------------------------------------------------------------

void __fastcall TF_flur::SpeedButton1Click(TObject *Sender)
{

TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("tn",StrToInt(Edit1->Text),Opts);

F_srz->Show();
//F_srz->gl_datform=2;
F_srz->p3->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::FormCreate(TObject *Sender)
{
   for (int i=2;i<=14;i++)
   {
     DBGrid1->Columns->Items[i]->Width=100;
   }



  //

  for (int i=0;i<=7;i++)
   {
     cb[i]->Clear();
   }

    for (int i=9;i<=10;i++)
   {
     cb[i]->Clear();
   }
   cb[12]->Clear();
   ComboBox13->Clear();
 //  ComboBox14->Clear();
 //  cb[14]->Clear();

   cb[0]->Text=Labfam->Caption;
   cb[1]->Text=Label1->Caption;
   cb[2]->Text=Label2->Caption;
   cb[3]->Text=Label3->Caption;
   cb[4]->Text=Label4->Caption;
   cb[5]->Text=Label5->Caption;
   cb[6]->Text=Label6->Caption;

   cb[7]->Text=Label9->Caption;
 //  cb[8]->Text=Label8->Caption;
   cb[9]->Text=Label10->Caption;
   cb[10]->Text=Label11->Caption;
   cb[11]->Text=Label12->Caption;
   cb[12]->Text=Label25->Caption;
   cb[13]->Text=Label7->Caption;


        dm->aqflur->First();
       while (!dm->aqflur->Eof)
        {
          ComboBox6->Items->Add(dm->aqflur->FieldByName("flu_mesto")->AsString);
          ComboBox7->Items->Add(dm->aqflur->FieldByName("flu_nomer")->AsString);
          ComboBox9->Items->Add(dm->aqflur->FieldByName("flu_doz")->AsString);
          ComboBox10->Items->Add(dm->aqflur->FieldByName("flu_result")->AsString);
          ComboBox12->Items->Add(dm->aqflur->FieldByName("flu_vredn")->AsString);
          ComboBox13->Items->Add(dm->aqflur->FieldByName("flu_data")->AsString);

          dm->aqflur->Next();
        }
          

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComfamChange(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"srz.FAM",Comfam->Text,"srz.FAM");
}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox1Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"srz.im",ComboBox1->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox2Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"srz.otch",ComboBox2->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox4Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"srz.cex",ComboBox4->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox5Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"prof.naimprof",ComboBox5->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox6Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"flu_mesto",ComboBox6->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox9Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"flu_doz",ComboBox9->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox12Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"flu_vredn",ComboBox12->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox7Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"flu_nomer",ComboBox7->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox10Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"flu_result",ComboBox10->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox11Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"flu_konting",ComboBox11->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox3Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"srz.dr",ComboBox3->Text,"srz.FAM");

}
//---------------------------------------------------------------------------


void __fastcall TF_flur::ComboBox14Change(TObject *Sender)
{
//wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"flu_grup",ComboBox14->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_flur::ComboBox13Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"flu_data",ComboBox13->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

