//---------------------------------------------------------------------------

#ifndef U_privH
#define U_privH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
#include <ComCtrls.hpp>

//---------------------------------------------------------------------------
class TF_priv : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TButton *buta;
        TButton *butu;
        TButton *butd;
        TPanel *Panel2;
        TDBGrid *DBGrid1;
        TComboBox *Comfam;
        TBevel *Bevel1;
        TLabel *Labfam;
        TGroupBox *gbb;
        TLabel *Label1;
        TComboBox *ComboBox1;
        TLabel *Label2;
        TComboBox *ComboBox2;
        TComboBox *ComboBox3;
        TLabel *Label3;
        TComboBox *ComboBox4;
        TLabel *Label4;
        TComboBox *ComboBox5;
        TLabel *Label5;
        TComboBox *ComboBox7;
        TComboBox *ComboBox8;
        TComboBox *ComboBox9;
        TComboBox *ComboBox10;
        TComboBox *ComboBox6;
        TComboBox *ComboBox11;
        TBitBtn *Bitok;
        TBitBtn *Bitcan;
        TEdit *Edit1;
        TLabel *Label13;
        TSpeedButton *SpeedButton1;
        TLabel *Label14;
        TLabel *Label15;
        TDataSource *DSpriv;
        TLabel *Label16;
        TLabel *Label17;
        TLabel *Label18;
        TLabel *Label19;
        TEdit *Edit2;
        TLabel *Label20;
        TEdit *Edit4;
        TLabel *Label21;
        TLabel *Label22;
        TEdit *Edit5;
        TDateTimePicker *dtp1;
        TEdit *Edit6;
        TLabel *Label23;
        TLabel *Label24;
        TLabel *Label26;
        TSpeedButton *sb1;
        TBevel *Bevel2;
        TEdit *Edit3;
        TLabel *Label27;
        TADOQuery *qub;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label6;
        TLabel *Label11;
        TComboBox *ComboBox12;
        TLabel *Label12;
        void __fastcall Button5Click(TObject *Sender);
        void __fastcall butaClick(TObject *Sender);
        void __fastcall butuClick(TObject *Sender);
        void __fastcall butdClick(TObject *Sender);
        void __fastcall BitokClick(TObject *Sender);
        void __fastcall BitcanClick(TObject *Sender);
        void __fastcall DSprivDataChange(TObject *Sender, TField *Field);
        void __fastcall sb1Click(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall ComfamChange(TObject *Sender);
        void __fastcall ComboBox1Change(TObject *Sender);
        void __fastcall ComboBox2Change(TObject *Sender);
        void __fastcall ComboBox4Change(TObject *Sender);
        void __fastcall ComboBox5Change(TObject *Sender);
        void __fastcall ComboBox8Change(TObject *Sender);
        void __fastcall ComboBox9Change(TObject *Sender);
        void __fastcall ComboBox11Change(TObject *Sender);
        void __fastcall ComboBox7Change(TObject *Sender);
        void __fastcall ComboBox10Change(TObject *Sender);
        void __fastcall ComboBox6Change(TObject *Sender);
        void __fastcall ComboBox3Change(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TF_priv(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_priv *F_priv;
//---------------------------------------------------------------------------
#endif
