//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "U_sprprof.h"
#include "U_sprPolnySpisok.h" 
#include "U_flur.h"
#include "U_priv.h"
#include "U_boln.h"
#include "U_gen.h"
#include "Uabout.h"
#include "U_disp.h"
#include "Udm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N2Click(TObject *Sender)
{

//F_gen->WindowState=wsMinimized;

}
//---------------------------------------------------------------------------


void __fastcall TForm1::N13Click(TObject *Sender)
{

F_prof->Show();
F_prof->p3->Visible=false;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N12Click(TObject *Sender)
{
F_srz->Show();
F_srz->p3->Visible=false;
}
//---------------------------------------------------------------------------




void __fastcall TForm1::N14Click(TObject *Sender)
{
F_boln->WindowState=wsMaximized;        
}
//---------------------------------------------------------------------------



void __fastcall TForm1::N16Click(TObject *Sender)
{
F_flur->WindowState=wsMaximized;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::N18Click(TObject *Sender)
{
F_priv->WindowState=wsMaximized;
 
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N20Click(TObject *Sender)
{
F_gen->WindowState=wsMaximized;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N10Click(TObject *Sender)
{
Fabout->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N23Click(TObject *Sender)
{
F_disp->WindowState=wsMaximized;;        
}
//---------------------------------------------------------------------------




void __fastcall TForm1::N26Click(TObject *Sender)
{
String s="";
s=InputBox("�������� �������","������� ��� �� ������� ��������������� �����","");
if (FileExists("archiv\\c"+s+".mdb"))
{dm->adc1->Connected=false;
dm->adc1->ConnectionString="Provider=Microsoft.Jet.OLEDB.4.0;Data Source=archiv\\c"+s+".mdb;Persist Security Info=False" ;
dm->adc1->Connected=true;

Form1->Caption=Form1->Caption+"�������� ������ �� "+s+" ���";
priarh=1;
N28->Visible=true;
N27->Enabled=false;}
else
        {ShowMessage("������ ��"+s+" ��� �� ����������!");
        }
 CloseOpen(1);
}
//---------------------------------------------------------------------------



void __fastcall TForm1::N28Click(TObject *Sender)
{
dm->adc1->Connected=false;
dm->adc1->ConnectionString="Provider=Microsoft.Jet.OLEDB.4.0;Data Source=medicin.mdb;Persist Security Info=False" ;
//dm2->adc1->Connected=true;
CloseOpen(1);
Form1->Caption="��������� ��� ��� 640�480" ;
N28->Visible=false;
N27->Enabled=true;
//Form1->Caption=Cap;
}
//---------------------------------------------------------------------------

 void __fastcall TForm1:: CloseOpen(int pr)
{

switch (pr)
{case 0:
         {  dm->adc1->Connected=false;

            dm->aqboln->Active=false;
            dm->aqflur->Active=false;
            dm->aqpriv->Active=false;
            dm->aqgen->Active=false;
            dm->aqdisp->Active=false;
            dm->aqsrz->Active=false;
            dm->aqprof->Active=false;


          }
case 1:  {   dm->adc1->Connected=true;

            dm->aqboln->Active=true;
            dm->aqflur->Active=true;
            dm->aqpriv->Active=true;
            dm->aqgen->Active=true;
            dm->aqdisp->Active=true;
            dm->aqsrz->Active=true;
            dm->aqprof->Active=true;



         }
}

 }
