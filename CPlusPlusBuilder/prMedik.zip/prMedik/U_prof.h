//---------------------------------------------------------------------------

#ifndef U_profH
#define U_profH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TF_prof : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TGroupBox *gb;
        TBevel *Bevel1;
        TButton *buta;
        TButton *butu;
        TButton *butd;
        TPanel *Panel2;
        TDBGrid *DBGrid1;
        TBitBtn *Bitok;
        TBitBtn *Bitcan;
        TEdit *Edit1;
        TEdit *Edit2;
        TLabel *Label1;
        TLabel *Label2;
        void __fastcall butaClick(TObject *Sender);
        void __fastcall butuClick(TObject *Sender);
        void __fastcall butdClick(TObject *Sender);
        void __fastcall BitokClick(TObject *Sender);
        void __fastcall BitcanClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TF_prof(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_prof *F_prof;
//---------------------------------------------------------------------------
#endif
