//----------------------------------------------------------------------------
#ifndef UaboutH
#define UaboutH
//----------------------------------------------------------------------------
#include <vcl\System.hpp>
#include <vcl\Windows.hpp>
#include <vcl\SysUtils.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\ExtCtrls.hpp>
#include <jpeg.hpp>
//----------------------------------------------------------------------------
class TFabout : public TForm
{
__published:
	TPanel *Panel1;
	TImage *ProgramIcon;
	TLabel *ProductName;
	TLabel *Version;
	TLabel *Copyright;
	TLabel *Comments;
        TLabel *Label1;
        TBitBtn *BitBtn1;
        TLabel *Label2;
        void __fastcall BitBtn1Click(TObject *Sender);
private:
public:
	virtual __fastcall TFabout(TComponent* AOwner);
};
//----------------------------------------------------------------------------
extern PACKAGE TFabout *Fabout;
//----------------------------------------------------------------------------
#endif    
