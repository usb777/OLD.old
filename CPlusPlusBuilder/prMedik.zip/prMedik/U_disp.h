//---------------------------------------------------------------------------

#ifndef U_dispH
#define U_dispH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
#include <ComCtrls.hpp>
#include <Mask.hpp>

//---------------------------------------------------------------------------
class TF_disp : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TButton *buta;
        TButton *butu;
        TButton *butd;
        TPanel *Panel2;
        TDBGrid *DBGrid1;
        TComboBox *Comfam;
        TBevel *Bevel1;
        TLabel *Labfam;
        TGroupBox *gbb;
        TLabel *Label1;
        TComboBox *ComboBox1;
        TLabel *Label2;
        TComboBox *ComboBox2;
        TComboBox *ComboBox3;
        TLabel *Label3;
        TComboBox *ComboBox4;
        TLabel *Label4;
        TComboBox *ComboBox5;
        TLabel *Label5;
        TLabel *Label6;
        TComboBox *ComboBox6;
        TComboBox *ComboBox7;
        TBitBtn *Bitok;
        TBitBtn *Bitcan;
        TEdit *Edit1;
        TLabel *Label13;
        TSpeedButton *SpeedButton1;
        TLabel *Label14;
        TLabel *Label15;
        TDataSource *DSbol;
        TLabel *Label16;
        TLabel *Label17;
        TLabel *Label18;
        TLabel *Label19;
        TDateTimePicker *dtp1;
        TEdit *Edit6;
        TLabel *Label23;
        TLabel *Label24;
        TLabel *Label26;
        TSpeedButton *sb1;
        TBevel *Bevel2;
        TADOQuery *qub;
        TComboBox *ComboBox8;
        TLabel *Label20;
        TLabel *Label9;
        TLabel *Label11;
        TLabel *Label29;
        TLabel *Label7;
        TComboBox *ComboBox13;
        TDateTimePicker *dtp2;
        TLabel *Label8;
        TDateTimePicker *dtp3;
        TDateTimePicker *dtp4;
        TLabel *Label21;
        TLabel *Label22;
        TComboBox *ComboBox14;
        TLabel *Label27;
        TEdit *Edit2;
        TLabel *Label28;
        TComboBox *ComboBox15;
        TLabel *Label30;
        TComboBox *ComboBox9;
        TMaskEdit *me1;
        TMaskEdit *me2;
        void __fastcall Button5Click(TObject *Sender);
        void __fastcall butaClick(TObject *Sender);
        void __fastcall butuClick(TObject *Sender);
        void __fastcall butdClick(TObject *Sender);
        void __fastcall BitokClick(TObject *Sender);
        void __fastcall BitcanClick(TObject *Sender);
        void __fastcall DSbolDataChange(TObject *Sender, TField *Field);
        void __fastcall sb1Click(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall ComfamChange(TObject *Sender);
        void __fastcall ComboBox1Change(TObject *Sender);
        void __fastcall ComboBox2Change(TObject *Sender);
        void __fastcall ComboBox4Change(TObject *Sender);
        void __fastcall ComboBox5Change(TObject *Sender);
        void __fastcall ComboBox6Change(TObject *Sender);
        void __fastcall ComboBox9Change(TObject *Sender);
      
        void __fastcall ComboBox7Change(TObject *Sender);

        void __fastcall ComboBox3Change(TObject *Sender);
        void __fastcall ComboBox14Change(TObject *Sender);
        void __fastcall ComboBox13Change(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TF_disp(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_disp *F_disp;
//---------------------------------------------------------------------------
#endif
