//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_gen.h"
#include "Udm.h"
#include "CL_MY_DBWork.h"
#include "U_sprPolnySpisok.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_gen *F_gen;
MY_DBWork* wdb =new MY_DBWork;

TComboBox* cb[13];
String gl_dat[3];
String gl_sql="SELECT ginek.gin_pn, ginek.srz_tabnom, srz.FAM, srz.IM, srz.OTCH, srz.DR, srz.POL, srz.CEX, prof.NAIMPROF, ginek.gin_mesto, ginek.gin_data, ginek.gin_diagnoz, ginek.gin_moljel, ginek.gin_rekom FROM ginek INNER JOIN (srz INNER JOIN prof ON srz.PROF = prof.KODPROF) ON ginek.srz_tabnom = srz.TN ";

//ginek.gin_pn, ginek.srz_tabnom, ginek.gin_mesto, ginek.gin_data, ginek.gin_diagnoz, ginek.gin_moljel, ginek.gin_rekom


//----------------------------------------------------------
__fastcall TF_gen::TF_gen(TComponent* Owner)
        : TForm(Owner)
{
    cb[0]=Comfam;
    cb[1]=ComboBox1;
    cb[2]=ComboBox2;
    cb[3]=ComboBox3;
    cb[4]=ComboBox4;
    cb[5]=ComboBox5;
    cb[6]=ComboBox6;
    cb[7]=ComboBox7;
    cb[8]=ComboBox8;
    cb[9]=ComboBox9;
    cb[10]=ComboBox10;



}
//---------------------------------------------------------------------------


void __fastcall TF_gen::Button5Click(TObject *Sender)
{
gbb->Visible=false;
}
//---------------------------------------------------------------------------

void __fastcall TF_gen::butaClick(TObject *Sender)
{
gbb->Caption=buta->Caption;

//Edit1->Clear();
//Edit1->Text="1063";
try
 {  dm->aqsrz->First();
  Edit1->Text=IntToStr(dm->aqsrz->FieldByName("tn")->AsInteger);
  }
 catch (Exception &e)   // "�" - ��� ������
 {  ShowMessage("������� ������: "+e.Message);   // ���������� "�" � ����� ���������  
 }

  dtp1->Date=Now();
  //dtp2->Date=Now();

Edit2->Clear();
Edit3->Clear();
Edit4->Clear();
ComboBox13->Text;

Label14->Caption="";
Label15->Caption="";
Label16->Caption="";
Label17->Caption="";
Label18->Caption="";
Label19->Caption="";

gbb->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TF_gen::butuClick(TObject *Sender)
{

gbb->Caption=butu->Caption;
gbb->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::butdClick(TObject *Sender)
{

gbb->Caption=butd->Caption;
gbb->Visible=true;

 if (MessageDlg("������� ������� ������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {
  //   delete  from telsp where pns=:pns1
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="delete  from ginek where gin_pn=:gin_pn";
        qub->Parameters->ParamByName("gin_pn")->Value=dm->aqgen->FieldByName("gin_pn")->AsInteger;
        qub->ExecSQL();
    sb1->Click();
    gbb->Visible=false;

  }
else
    {gbb->Visible=false;}








}
//---------------------------------------------------------------------------

void __fastcall TF_gen::BitokClick(TObject *Sender)
{


        gl_dat[1]=DateToStr(dtp1->DateTime);
       //gl_dat[2]=DateToStr(dtp2->DateTime);
       //gin_pn, srz_tabnom, gin_mesto, gin_data, gin_diagnoz, gin_moljel, gin_rekom

if (MessageDlg("�� ������� � ��������� ������?",mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {

  try
    {
       if (gbb->Caption==buta->Caption)
      {
      //  ShowMessage("����������");
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="insert into ginek (srz_tabnom, gin_mesto, gin_data, gin_diagnoz, gin_moljel, gin_rekom) values(:srz_tabnom, :gin_mesto, :gin_data, :gin_diagnoz, :gin_moljel, :gin_rekom) ";
    //    ShowMessage(qub->SQL->Text);
        qub->Parameters->ParamByName("srz_tabnom")->Value=StrToInt(Edit1->Text);
        qub->Parameters->ParamByName("gin_mesto")->Value=Edit2->Text;
        qub->Parameters->ParamByName("gin_data")->Value=StrToDate(gl_dat[1]);
        qub->Parameters->ParamByName("gin_diagnoz")->Value=Edit3->Text;
        qub->Parameters->ParamByName("gin_moljel")->Value=ComboBox13->Text;
        qub->Parameters->ParamByName("gin_rekom")->Value=Edit4->Text;


        qub->ExecSQL();

       }

       if (gbb->Caption==butu->Caption)
      {
    //    ShowMessage("���������");
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="update ginek set srz_tabnom=:srz_tabnom, gin_mesto=:gin_mesto, gin_data=:gin_data, gin_diagnoz=:gin_diagnoz, gin_moljel=:gin_moljel, gin_rekom=:gin_rekom where gin_pn=:gin_pn";

        qub->Parameters->ParamByName("srz_tabnom")->Value=StrToInt(Edit1->Text);
        qub->Parameters->ParamByName("gin_mesto")->Value=Edit2->Text;
        qub->Parameters->ParamByName("gin_data")->Value=StrToDate(gl_dat[1]);
        qub->Parameters->ParamByName("gin_diagnoz")->Value=Edit3->Text;
        qub->Parameters->ParamByName("gin_moljel")->Value=ComboBox13->Text;
        qub->Parameters->ParamByName("gin_rekom")->Value=Edit4->Text;


      qub->Parameters->ParamByName("gin_pn")->Value=dm->aqgen->FieldByName("gin_pn")->AsInteger;

        qub->ExecSQL();


       }

    } //try end
   catch  (Exception &e)   // "�" - ��� ������
     {
       ShowMessage("������� ������: "+e.Message);
         // ���������� "�" � ����� ���������
     }

  }
else
    {

    }



gbb->Visible=false;
//FormCreate(Sender);
sb1->Click();

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::BitcanClick(TObject *Sender)
{

  gbb->Visible=false;

}
//---------------------------------------------------------------------------


void __fastcall TF_gen::DSbolDataChange(TObject *Sender, TField *Field)
{
//srz_tabnom, gin_mesto, gin_data, gin_diagnoz, gin_moljel, gin_rekom
 Edit1->Text=dm->aqgen->FieldByName("srz_tabnom")->AsString;
 Edit2->Text=dm->aqgen->FieldByName("gin_mesto")->AsString;
 dtp1->Date=dm->aqgen->FieldByName("gin_data")->AsDateTime;
 Edit3->Text=dm->aqgen->FieldByName("gin_diagnoz")->AsString;
 ComboBox13->Text=dm->aqgen->FieldByName("gin_moljel")->AsString;
 Edit4->Text=dm->aqgen->FieldByName("gin_rekom")->AsString;

TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("Tn",Edit1->Text,Opts);
//dm->aqprof->Locate("naimprof",dm->aqsrz->FieldByName("naimprof")->AsString,Opts);


Label14->Caption=dm->aqsrz->FieldByName("Fam")->AsString;
Label15->Caption=dm->aqsrz->FieldByName("Im")->AsString;
Label16->Caption=dm->aqsrz->FieldByName("Otch")->AsString;
Label17->Caption=dm->aqsrz->FieldByName("dr")->AsString;
Label18->Caption=dm->aqsrz->FieldByName("CEX")->AsString;
Label19->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;

/*
TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("Tn",Edit1->Text,Opts);

Label19->Caption=dm->aqsrz->FieldByName("Otch")->AsString;
*/

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::sb1Click(TObject *Sender)
{

  dm->aqgen->Close();
  dm->aqgen->SQL->Clear();
  dm->aqgen->SQL->Text=gl_sql+" order by srz.FAM ";
  dm->aqgen->Open();
//  FormCreate(Sender);



}
//---------------------------------------------------------------------------

void __fastcall TF_gen::SpeedButton1Click(TObject *Sender)
{
dm->aqsrz->Close();
dm->aqsrz->SQL->Clear();
dm->aqsrz->SQL->Text="SELECT srz.kod, srz.TN, srz.FAM, srz.IM, srz.OTCH, srz.DR, srz.adres, srz.CEX, ";
dm->aqsrz->SQL->Add("prof.NAIMPROF, srz.POL, srz.PROF FROM srz INNER JOIN prof ON srz.PROF = prof.KODPROF where srz.POL='2' order by srz.FAM");
dm->aqsrz->Open();


TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("tn",StrToInt(Edit1->Text),Opts);


F_srz->Show();
F_srz->p3->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::FormCreate(TObject *Sender)
{
   for (int i=2;i<=11;i++)
   {
     DBGrid1->Columns->Items[i]->Width=100;
   }



  //

  for (int i=0;i<=5;i++)
   {
     cb[i]->Clear();
   }
  for (int i=7;i<=10;i++)
   {
     cb[i]->Clear();
   }


   cb[0]->Text=Labfam->Caption;
   cb[1]->Text=Label1->Caption;
   cb[2]->Text=Label2->Caption;
   cb[3]->Text=Label3->Caption;
   cb[4]->Text=Label4->Caption;
   cb[5]->Text=Label5->Caption;
   cb[6]->Text=Label6->Caption;
   cb[7]->Text=Label7->Caption;
   cb[8]->Text=Label8->Caption;
   cb[9]->Text=Label9->Caption;
   cb[10]->Text=Label10->Caption;



        dm->aqgen->First();
       while (!dm->aqgen->Eof)
        {
         // ComboBox6->Items->Add(dm->aqgen->FieldByName("gin_mesto")->AsString);
          ComboBox7->Items->Add(dm->aqgen->FieldByName("gin_data")->AsString);
          ComboBox8->Items->Add(dm->aqgen->FieldByName("gin_diagnoz")->AsString);
          ComboBox9->Items->Add(dm->aqgen->FieldByName("gin_moljel")->AsString);
          ComboBox10->Items->Add(dm->aqgen->FieldByName("gin_rekom")->AsString);

          dm->aqgen->Next();
        }







}
//---------------------------------------------------------------------------

void __fastcall TF_gen::ComfamChange(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"srz.FAM",Comfam->Text,"srz.FAM");
}
//---------------------------------------------------------------------------

void __fastcall TF_gen::ComboBox1Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"srz.im",ComboBox1->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::ComboBox2Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"srz.otch",ComboBox2->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::ComboBox4Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"srz.cex",ComboBox4->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::ComboBox5Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"prof.naimprof",ComboBox5->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::ComboBox7Change(TObject *Sender)
{


wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"gin_data",ComboBox7->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::ComboBox8Change(TObject *Sender)
{

wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"gin_diagnoz",ComboBox8->Text,"srz.FAM");



}
//---------------------------------------------------------------------------

void __fastcall TF_gen::ComboBox6Change(TObject *Sender)
{

wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"gin_mesto",ComboBox6->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_gen::ComboBox9Change(TObject *Sender)
{
//wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"boln.boln_netrn",ComboBox10->Text,"srz.FAM");
wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"gin_moljel",ComboBox9->Text,"srz.FAM");



}
//---------------------------------------------------------------------------


void __fastcall TF_gen::ComboBox3Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"srz.dr",ComboBox3->Text,"srz.FAM");

}
//---------------------------------------------------------------------------


void __fastcall TF_gen::ComboBox10Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqgen,gl_sql,"gin_rekom",ComboBox10->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

