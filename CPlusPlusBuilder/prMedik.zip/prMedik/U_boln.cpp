//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_boln.h"
#include "Udm.h"
#include "CL_MY_DBWork.h"
#include "U_sprPolnySpisok.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_boln *F_boln;
MY_DBWork* wdb =new MY_DBWork;

TComboBox* cb[13];
String gl_dat[3];
String gl_sql="SELECT boln.boln_pn, srz.FAM, srz.IM,srz.pol, srz.OTCH, srz.DR, srz.CEX, prof.NAIMPROF, boln.boln_kemvyd, boln.boln_kod, boln.boln_dopkod, boln.boln_nombol, boln.boln_netrn, boln.boln_netrk, boln.boln_prodoljit, boln.boln_tn FROM (boln INNER JOIN srz ON boln.boln_tn = srz.TN) INNER JOIN prof ON srz.PROF = prof.KODPROF";




//----------------------------------------------------------
__fastcall TF_boln::TF_boln(TComponent* Owner)
        : TForm(Owner)
{
    cb[0]=Comfam;
    cb[1]=ComboBox1;
    cb[2]=ComboBox2;
    cb[3]=ComboBox3;
    cb[4]=ComboBox4;
    cb[5]=ComboBox5;
    cb[6]=ComboBox6;
    cb[7]=ComboBox7;
    cb[8]=ComboBox8;
    cb[9]=ComboBox9;
    cb[10]=ComboBox10;
    cb[11]=ComboBox11;
    cb[12]=ComboBox12;


}
//---------------------------------------------------------------------------


void __fastcall TF_boln::Button5Click(TObject *Sender)
{
gbb->Visible=false;
}
//---------------------------------------------------------------------------

void __fastcall TF_boln::butaClick(TObject *Sender)
{
gbb->Caption=buta->Caption;

//Edit1->Clear();
//Edit1->Text="1063";
try
 {  dm->aqsrz->First();
  Edit1->Text=IntToStr(dm->aqsrz->FieldByName("tn")->AsInteger);
  }
 catch (Exception &e)   // "�" - ��� ������
 {  ShowMessage("������� ������: "+e.Message);   // ���������� "�" � ����� ���������  
 }

  dtp1->Date=Now();
  dtp2->Date=Now();

Edit2->Clear();
Edit3->Clear();
Edit4->Clear();
Edit5->Clear();
Edit6->Clear();

Label14->Caption="";
Label15->Caption="";
Label16->Caption="";
Label17->Caption="";
Label18->Caption="";
Label19->Caption="";

gbb->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TF_boln::butuClick(TObject *Sender)
{

gbb->Caption=butu->Caption;
gbb->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_boln::butdClick(TObject *Sender)
{

gbb->Caption=butd->Caption;
gbb->Visible=true;

 if (MessageDlg("������� ������� ������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {
  //   delete  from telsp where pns=:pns1
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="delete  from boln where boln_pn=:boln_pn";
        qub->Parameters->ParamByName("boln_pn")->Value=dm->aqboln->FieldByName("boln_pn")->AsInteger;
        qub->ExecSQL();
    sb1->Click();
    gbb->Visible=false;

  }
else
    {gbb->Visible=false;}








}
//---------------------------------------------------------------------------

void __fastcall TF_boln::BitokClick(TObject *Sender)
{


        gl_dat[1]=DateToStr(dtp1->DateTime);
        gl_dat[2]=DateToStr(dtp2->DateTime);


if (MessageDlg("�� ������� � ��������� ������?",mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {

  try
    {
       if (gbb->Caption==buta->Caption)
      {
      //  ShowMessage("����������");
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="insert into boln (boln_tn, boln_kemvyd,boln_kod,boln_dopkod,boln_nombol,boln_netrn,boln_netrk,boln_prodoljit) values(:boln_tn,:boln_kemvyd,:boln_kod,:boln_dopkod,:boln_nombol,:boln_netrn,:boln_netrk,:boln_prodoljit) ";
    //    ShowMessage(qub->SQL->Text);
        qub->Parameters->ParamByName("boln_tn")->Value=StrToInt(Edit1->Text);
        qub->Parameters->ParamByName("boln_kemvyd")->Value=Edit2->Text;
        qub->Parameters->ParamByName("boln_kod")->Value=Edit3->Text;
        qub->Parameters->ParamByName("boln_dopkod")->Value=Edit4->Text;
        qub->Parameters->ParamByName("boln_prodoljit")->Value=Edit5->Text;

        qub->Parameters->ParamByName("boln_netrn")->Value=StrToDate(gl_dat[1]);
        qub->Parameters->ParamByName("boln_netrk")->Value=StrToDate(gl_dat[2]);
        qub->Parameters->ParamByName("boln_nombol")->Value=Edit6->Text;


        qub->ExecSQL();

       }

       if (gbb->Caption==butu->Caption)
      {
    //    ShowMessage("���������");
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="update boln set boln_tn=:boln_tn, boln_kemvyd=:boln_kemvyd,boln_kod=:boln_kod,boln_dopkod=:boln_dopkod,boln_nombol=:boln_nombol,boln_netrn=:boln_netrn,boln_netrk=:boln_netrk,boln_prodoljit=:boln_prodoljit where boln_pn=:boln_pn";

        qub->Parameters->ParamByName("boln_tn")->Value=StrToInt(Edit1->Text);
        qub->Parameters->ParamByName("boln_kemvyd")->Value=Edit2->Text;
        qub->Parameters->ParamByName("boln_kod")->Value=Edit3->Text;
        qub->Parameters->ParamByName("boln_dopkod")->Value=Edit4->Text;
        qub->Parameters->ParamByName("boln_prodoljit")->Value=Edit5->Text;

        qub->Parameters->ParamByName("boln_netrn")->Value=StrToDate(gl_dat[1]);
        qub->Parameters->ParamByName("boln_netrk")->Value=StrToDate(gl_dat[2]);

       qub->Parameters->ParamByName("boln_nombol")->Value=Edit6->Text;
       qub->Parameters->ParamByName("boln_pn")->Value=dm->aqboln->FieldByName("boln_pn")->AsInteger;

        qub->ExecSQL();


       }

    } //try end
   catch  (Exception &e)   // "�" - ��� ������
     {
       ShowMessage("������� ������: "+e.Message);
         // ���������� "�" � ����� ���������
     }

  }
else
    {

    }



gbb->Visible=false;
//FormCreate(Sender);
sb1->Click();

}
//---------------------------------------------------------------------------

void __fastcall TF_boln::BitcanClick(TObject *Sender)
{

  gbb->Visible=false;

}
//---------------------------------------------------------------------------


void __fastcall TF_boln::DSbolDataChange(TObject *Sender, TField *Field)
{

 Edit1->Text=dm->aqboln->FieldByName("boln_tn")->AsString;
 Edit2->Text=dm->aqboln->FieldByName("boln_kemvyd")->AsString;
 Edit3->Text=dm->aqboln->FieldByName("boln_kod")->AsString;
 Edit4->Text=dm->aqboln->FieldByName("boln_dopkod")->AsString;
 Edit5->Text=dm->aqboln->FieldByName("boln_prodoljit")->AsString;
 Edit6->Text=dm->aqboln->FieldByName("boln_nombol")->AsString;
  dtp1->Date=dm->aqboln->FieldByName("boln_netrn")->AsDateTime;
  dtp2->Date=dm->aqboln->FieldByName("boln_netrk")->AsDateTime;

TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("Tn",Edit1->Text,Opts);

Label14->Caption=dm->aqsrz->FieldByName("Fam")->AsString;
Label15->Caption=dm->aqsrz->FieldByName("Im")->AsString;
Label16->Caption=dm->aqsrz->FieldByName("Otch")->AsString;
Label17->Caption=dm->aqsrz->FieldByName("dr")->AsString;
Label18->Caption=dm->aqsrz->FieldByName("CEX")->AsString;
Label19->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;


}
//---------------------------------------------------------------------------

void __fastcall TF_boln::sb1Click(TObject *Sender)
{

  dm->aqboln->Close();
  dm->aqboln->SQL->Clear();
  dm->aqboln->SQL->Text="SELECT boln.boln_pn, srz.FAM, srz.IM, srz.OTCH, srz.DR, srz.CEX, prof.NAIMPROF, boln.boln_kemvyd, boln.boln_kod, boln.boln_dopkod, boln.boln_nombol, boln.boln_netrn, boln.boln_netrk, boln.boln_prodoljit, boln.boln_tn FROM (boln INNER JOIN srz ON boln.boln_tn = srz.TN) INNER JOIN prof ON srz.PROF = prof.KODPROF order by srz.FAM ";
  dm->aqboln->Open();    
//  FormCreate(Sender);
GroupBox1->Visible=true;
Label28->Caption="���-�� ������� �� �������: "+IntToStr(CountSql(dm->aqboln));




}
//---------------------------------------------------------------------------

void __fastcall TF_boln::SpeedButton1Click(TObject *Sender)
{
 
TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("tn",StrToInt(Edit1->Text),Opts);

F_srz->Show();
F_srz->p3->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_boln::FormCreate(TObject *Sender)
{
   for (int i=2;i<=14;i++)
   {
     DBGrid1->Columns->Items[i]->Width=100;
   }



  //

  for (int i=0;i<=12;i++)
   {
     cb[i]->Clear();
   }
   cb[0]->Text=Labfam->Caption;
   cb[1]->Text=Label1->Caption;
   cb[2]->Text=Label2->Caption;
   cb[3]->Text=Label3->Caption;
   cb[4]->Text=Label4->Caption;
   cb[5]->Text=Label5->Caption;
   cb[6]->Text=Label6->Caption;
   cb[7]->Text=Label7->Caption;
   cb[8]->Text=Label8->Caption;
   cb[9]->Text=Label9->Caption;
   cb[10]->Text=Label10->Caption;
   cb[11]->Text=Label11->Caption;
   cb[12]->Text=Label12->Caption;


   for (int i=1;i<=63;i++)
      {
        ComboBox7->Items->Add(IntToStr(i));
      }
   for (int i=70;i<=77;i++)
      {
        ComboBox7->Items->Add(IntToStr(i));
      }


      dm->aqboln->First();
       while (!dm->aqboln->Eof)
        {
            for(int i=0;i<=ComboBox9->Items->Count-1;i++)
         {
              if (ComboBox9->Items->Strings[i]==dm->aqboln->FieldByName("boln_nombol")->AsString)
               {
                 goto m2;
               } //if
         } //for
          ComboBox6->Items->Add(dm->aqboln->FieldByName("boln_kemvyd")->AsString);
          ComboBox8->Items->Add(dm->aqboln->FieldByName("boln_dopkod")->AsString);
          ComboBox9->Items->Add(dm->aqboln->FieldByName("boln_nombol")->AsString);
          ComboBox10->Items->Add(dm->aqboln->FieldByName("boln_netrn")->AsString);
          ComboBox11->Items->Add(dm->aqboln->FieldByName("boln_netrk")->AsString);
          ComboBox12->Items->Add(dm->aqboln->FieldByName("boln_prodoljit")->AsString);

       m2:   dm->aqboln->Next();
        }







}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComfamChange(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"srz.FAM",Comfam->Text,"srz.FAM");
 GroupBox1->Visible=false;

}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox1Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"srz.im",ComboBox1->Text,"srz.FAM");
     GroupBox1->Visible=false;

}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox2Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"srz.otch",ComboBox2->Text,"srz.FAM");
  GroupBox1->Visible=false;

}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox4Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"srz.cex",ComboBox4->Text,"srz.FAM");
  GroupBox1->Visible=false;

}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox5Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"prof.naimprof",ComboBox5->Text,"srz.FAM");
 GroupBox1->Visible=false;

}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox7Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"boln.boln_kod",ComboBox7->Text,"srz.FAM");
 GroupBox1->Visible=true;
Label28->Caption="���-�� ������� �� �������: "+IntToStr(CountSql(dm->aqboln));
}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox9Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"boln.boln_nombol",ComboBox9->Text,"srz.FAM");
GroupBox1->Visible=true;
Label28->Caption="���-�� ������� �� �������: "+IntToStr(CountSql(dm->aqboln));
}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox12Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"boln.boln_prodoljit",ComboBox12->Text,"srz.FAM");
GroupBox1->Visible=true;
Label28->Caption="���-�� ������� �� �������: "+IntToStr(CountSql(dm->aqboln));
}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox6Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"boln.boln_kemvyd",ComboBox6->Text,"srz.FAM");
GroupBox1->Visible=true;
Label28->Caption="���-�� ������� �� �������: "+IntToStr(CountSql(dm->aqboln));
}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox10Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborkud(dm->aqboln,gl_sql,"boln.boln_netrn",StrToDate(ComboBox10->Text),"srz.FAM");
GroupBox1->Visible=true;
Label28->Caption="���-�� ������� �� �������: "+IntToStr(CountSql(dm->aqboln));

}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox11Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"boln.boln_netrk",ComboBox11->Text,"srz.FAM");
GroupBox1->Visible=true;
Label28->Caption="���-�� ������� �� �������: "+IntToStr(CountSql(dm->aqboln));
}
//---------------------------------------------------------------------------

void __fastcall TF_boln::ComboBox3Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqboln,gl_sql,"srz.dr",ComboBox3->Text,"srz.FAM");
  GroupBox1->Visible=false;

}
//---------------------------------------------------------------------------

int TF_boln::CountSql(TADOQuery *q)
{
int kol=0;
q->First();

while (!q->Eof)
{ kol++ ;
  q->Next();
}

return kol;

}
//---------------------------------------------------------------------------

