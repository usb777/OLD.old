//---------------------------------------------------------------------------

#ifndef U_sprprofH
#define U_sprprofH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------
class TF_prof : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TGroupBox *gb;
        TBevel *Bevel1;
        TButton *buta;
        TButton *butu;
        TButton *butd;
        TPanel *Panel2;
        TDBGrid *DBGrid1;
        TBitBtn *Bitok;
        TBitBtn *Bitcan;
        TEdit *Edprof;
        TEdit *Edtab;
        TLabel *Label1;
        TLabel *Label2;
        TADOQuery *qu;
        TDataSource *DataSource1;
        TComboBox *ComboBox1;
        TLabel *Label3;
        TEdit *Edit1;
        TLabel *Label4;
        TPanel *p3;
        TBitBtn *BitBtn1;
        TSpeedButton *sb1;
        void __fastcall butaClick(TObject *Sender);
        void __fastcall butuClick(TObject *Sender);
        void __fastcall butdClick(TObject *Sender);
        void __fastcall BitokClick(TObject *Sender);
        void __fastcall BitcanClick(TObject *Sender);
        void __fastcall DataSource1DataChange(TObject *Sender,
          TField *Field);
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall ComboBox1Change(TObject *Sender);
        void __fastcall Edit1Change(TObject *Sender);
        void __fastcall sb1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TF_prof(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_prof *F_prof;
//---------------------------------------------------------------------------
#endif
