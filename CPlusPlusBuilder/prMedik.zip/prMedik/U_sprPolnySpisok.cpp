//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_sprPolnySpisok.h"
#include "Udm.h"
#include "CL_MY_DBWork.h"
#include "U_sprprof.h"
#include "U_boln.h"
#include "U_flur.h"
#include "U_priv.h"
#include "U_gen.h"
#include "U_disp.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_srz *F_srz;

 // MY_DBWork* wdb =new MY_DBWork;
//---------------------------------------------------------------------------
__fastcall TF_srz::TF_srz(TComponent* Owner)
        : TForm(Owner)
{



}
//---------------------------------------------------------------------------
void __fastcall TF_srz::butaClick(TObject *Sender)
{
gb->Caption=buta->Caption;
Edtab->Clear();
//Edit1->Clear();
Edit2->Clear();
Edit3->Clear();
Edit4->Clear();
Edit5->Clear();
Edit6->Clear();
Edit7->Clear();
Edprof->Clear();

gb->Visible=true;

}
//---------------------------------------------------------------------------
void __fastcall TF_srz::butuClick(TObject *Sender)
{
gb->Caption=butu->Caption;
 if (butu->Caption==gb->Caption)
{
Edtab->Text=IntToStr(dm->aqsrz->FieldByName("TN")->AsInteger);
Edit2->Text=dm->aqsrz->FieldByName("fam")->AsString;
Edit3->Text=dm->aqsrz->FieldByName("im")->AsString;
Edit4->Text=dm->aqsrz->FieldByName("otch")->AsString;
Edit5->Text=DateToStr(dm->aqsrz->FieldByName("dr")->AsDateTime);
Edit6->Text=dm->aqsrz->FieldByName("CEX")->AsString;
Edit7->Text=dm->aqsrz->FieldByName("adres")->AsString;
Edprof->Text=dm->aqsrz->FieldByName("naimprof")->AsString;
if (dm->aqsrz->FieldByName("Pol")->AsInteger==1)
   { CBpol->Text="�������";
   }
   else
       {
        CBpol->Text="�������";
       }



Edprof->Text=dm->aqprof->FieldByName("naimprof")->AsString;
 }

gb->Visible=true;
}
//---------------------------------------------------------------------------
void __fastcall TF_srz::butdClick(TObject *Sender)
{
gb->Caption=butd->Caption;
gb->Visible=true;

//Edtab->Text=IntToStr(dm->aqprof->FieldByName("prof_kod")->AsInteger);
Edprof->Text=dm->aqprof->FieldByName("naimprof")->AsString;


if (MessageDlg("������� ������� ������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {
  //   delete  from telsp where pns=:pns1
        qu->Close();
        qu->SQL->Clear();
        qu->SQL->Text="delete  from srz where kod=:kod";
        qu->Parameters->ParamByName("kod")->Value=dm->aqsrz->FieldByName("kod")->AsInteger;
        qu->ExecSQL();
    sb1->Click();
    gb->Visible=false;

  }
else
    {gb->Visible=false;}


}
//---------------------------------------------------------------------------
void __fastcall TF_srz::BitokClick(TObject *Sender)
{

if (MessageDlg("�� ������� � ��������� ������?",mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {

  try
    {
       if (gb->Caption==buta->Caption)
      {
        ShowMessage("����������");
        qu->Close();
        qu->SQL->Clear();


    qu->SQL->Text="insert into srz(TN,fam,im,otch,dr,Cex,adres,pol,prof) values(:TN,:fam,:im,:otch,:dr,:Cex,:adres,:pol,:prof) ";

   qu->Parameters->ParamByName("Tn")->Value=StrToInt(Edtab->Text);
   qu->Parameters->ParamByName("fam")->Value =Edit2->Text;
   qu->Parameters->ParamByName("im")->Value=Edit3->Text;
   qu->Parameters->ParamByName("otch")->Value=Edit4->Text;
   qu->Parameters->ParamByName("dr")->Value=StrToDate(Edit5->Text);
   qu->Parameters->ParamByName("cex")->Value=Edit6->Text;
   qu->Parameters->ParamByName("adres")->Value=Edit7->Text;


TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqprof->Locate("naimprof",Edprof->Text,Opts);
qu->Parameters->ParamByName("prof")->Value=dm->aqprof->FieldByName("kodprof")->AsInteger;




   if (CBpol->Text=="�������")
      {   qu->Parameters->ParamByName("pol")->Value=1;
      }
   if (CBpol->Text=="�������")
      {   qu->Parameters->ParamByName("pol")->Value=2;
      }

        qu->ExecSQL();

       }

       if (gb->Caption==butu->Caption)
      {
        ShowMessage("���������");
        qu->Close();
        qu->SQL->Clear();
        qu->SQL->Text="update srz set TN=:tn,fam=:fam,im=:im,otch=:otch,dr=:dr,Cex=:cex,adres=:adres,pol=:pol, prof=:prof where kod=:kod";
   //

   qu->Parameters->ParamByName("Tn")->Value=StrToInt(Edtab->Text);
     qu->Parameters->ParamByName("fam")->Value =Edit2->Text;
   qu->Parameters->ParamByName("im")->Value=Edit3->Text;
   qu->Parameters->ParamByName("otch")->Value=Edit4->Text;
   qu->Parameters->ParamByName("dr")->Value=StrToDate(Edit5->Text);
   qu->Parameters->ParamByName("cex")->Value=Edit6->Text;
   qu->Parameters->ParamByName("adres")->Value=Edit7->Text;

TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqprof->Locate("naimprof",Edprof->Text,Opts);
qu->Parameters->ParamByName("prof")->Value=dm->aqprof->FieldByName("kodprof")->AsInteger;


   if (CBpol->Text=="�������")
      {   qu->Parameters->ParamByName("pol")->Value=1;
      }
   if (CBpol->Text=="�������")
      {   qu->Parameters->ParamByName("pol")->Value=2;
      }
         ShowMessage(IntToStr(dm->aqsrz->FieldByName("kod")->AsInteger));
   qu->Parameters->ParamByName("kod")->Value=dm->aqsrz->FieldByName("kod")->AsInteger;



        qu->ExecSQL();


       }

    } //try end
   catch  (Exception &e)   // "�" - ��� ������
     {
       ShowMessage("������� ������: "+e.Message);
         // ���������� "�" � ����� ���������
     }

  }
else
    {

    }

     gb->Visible=false;
     FormCreate(Sender);
  sb1->Click();
 


}

//---------------------------------------------------------------------------
void __fastcall TF_srz::BitcanClick(TObject *Sender)
{
gb->Visible=false;
}
//---------------------------------------------------------------------------
void __fastcall TF_srz::DataSource1DataChange(TObject *Sender,
      TField *Field)
{

 if (butu->Caption==gb->Caption)
{
Edtab->Text=IntToStr(dm->aqprof->FieldByName("kodprof")->AsInteger);
Edprof->Text=dm->aqprof->FieldByName("naimprof")->AsString;
 }
}
//---------------------------------------------------------------------------


void __fastcall TF_srz::BitBtn1Click(TObject *Sender)
{

/*
F_boln->Edit1->Text=dm->aqsrz->FieldByName("tn")->AsString;
F_boln->Label14->Caption=dm->aqsrz->FieldByName("fam")->AsString;
F_boln->Label15->Caption=dm->aqsrz->FieldByName("im")->AsString;
F_boln->Label16->Caption=dm->aqsrz->FieldByName("otch")->AsString;
F_boln->Label17->Caption=dm->aqsrz->FieldByName("dr")->AsString;
F_boln->Label18->Caption=dm->aqsrz->FieldByName("cex")->AsString;
F_boln->Label19->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;

F_flur->Edit1->Text=dm->aqsrz->FieldByName("tn")->AsString;
F_flur->Label14->Caption=dm->aqsrz->FieldByName("fam")->AsString;
F_flur->Label15->Caption=dm->aqsrz->FieldByName("im")->AsString;
F_flur->Label16->Caption=dm->aqsrz->FieldByName("otch")->AsString;
F_flur->Label17->Caption=dm->aqsrz->FieldByName("dr")->AsString;
F_flur->Label18->Caption=dm->aqsrz->FieldByName("cex")->AsString;
F_flur->Label19->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;

F_priv->Edit1->Text=dm->aqsrz->FieldByName("tn")->AsString;
F_priv->Label14->Caption=dm->aqsrz->FieldByName("fam")->AsString;
F_priv->Label15->Caption=dm->aqsrz->FieldByName("im")->AsString;
F_priv->Label16->Caption=dm->aqsrz->FieldByName("otch")->AsString;
F_priv->Label17->Caption=dm->aqsrz->FieldByName("dr")->AsString;
F_priv->Label18->Caption=dm->aqsrz->FieldByName("cex")->AsString;
F_priv->Label19->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;


F_gen->Edit1->Text=dm->aqsrz->FieldByName("tn")->AsString;
F_gen->Label14->Caption=dm->aqsrz->FieldByName("fam")->AsString;
F_gen->Label15->Caption=dm->aqsrz->FieldByName("im")->AsString;
F_gen->Label16->Caption=dm->aqsrz->FieldByName("otch")->AsString;
F_gen->Label17->Caption=dm->aqsrz->FieldByName("dr")->AsString;
F_gen->Label18->Caption=dm->aqsrz->FieldByName("cex")->AsString;
F_gen->Label19->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;
 */
ChangeLabel(F_boln->Edit1,F_boln->Label14,F_boln->Label15,F_boln->Label16,F_boln->Label17,F_boln->Label18,F_boln->Label19);
ChangeLabel(F_flur->Edit1,F_flur->Label14,F_flur->Label15,F_flur->Label16,F_flur->Label17,F_flur->Label18,F_flur->Label19);
ChangeLabel(F_priv->Edit1,F_priv->Label14,F_priv->Label15,F_priv->Label16,F_priv->Label17,F_priv->Label18,F_priv->Label19);
ChangeLabel(F_gen->Edit1,F_gen->Label14,F_gen->Label15,F_gen->Label16,F_gen->Label17,F_gen->Label18,F_gen->Label19);
ChangeLabel(F_disp->Edit1,F_disp->Label14,F_disp->Label15,F_disp->Label16,F_disp->Label17,F_disp->Label18,F_disp->Label19);


dm->aqsrz->Close();
dm->aqsrz->SQL->Clear();
dm->aqsrz->SQL->Text="SELECT srz.kod, srz.TN, srz.FAM, srz.IM, srz.OTCH, srz.DR, srz.adres, srz.CEX, ";
dm->aqsrz->SQL->Add("prof.NAIMPROF, srz.POL, srz.PROF FROM srz INNER JOIN prof ON srz.PROF = prof.KODPROF order by srz.FAM");
dm->aqsrz->Open();




Close();
}
//---------------------------------------------------------------------------
 /*
void __fastcall TF_srz::CbprofChange(TObject *Sender)
{
dm->aqprof->Close();
dm->aqprof->SQL->Clear();
 dm->aqprof->SQL->Text="select * from prof where naimprof='"+ComboBox1->Text+"' order by naimprof" ;

//dm->aqprof->Open();

}
*/
//---------------------------------------------------------------------------

void __fastcall TF_srz::Edit1Change(TObject *Sender)
{


 TLocateOptions Opts;
 Opts.Clear();
 Opts << loPartialKey	;
 dm->aqsrz->Locate("fam",Edit1->Text,Opts);



 }
//---------------------------------------------------------------------------

void __fastcall TF_srz::sb1Click(TObject *Sender)
{



  dm->aqsrz->Close();
  dm->aqsrz->SQL->Clear();
  dm->aqsrz->SQL->Text="SELECT srz.kod, srz.TN, srz.FAM, srz.IM, srz.OTCH, srz.DR, srz.adres, srz.CEX, prof.NAIMPROF, srz.POL, srz.PROF FROM srz INNER JOIN prof ON srz.PROF = prof.KODPROF order by srz.FAM  ";
 // dm->aqsrz->SQL->t="  ";
//  dm->aqsrz->SQL->Text=" ";
  dm->aqsrz->Open();



}
//---------------------------------------------------------------------------

void __fastcall TF_srz::DSsrzDataChange(TObject *Sender, TField *Field)
{

Edtab->Text=IntToStr(dm->aqsrz->FieldByName("TN")->AsInteger);
Edit2->Text=dm->aqsrz->FieldByName("Fam")->AsString;
Edit3->Text=dm->aqsrz->FieldByName("Im")->AsString;
Edit4->Text=dm->aqsrz->FieldByName("Otch")->AsString;
Edit5->Text=DateToStr(dm->aqsrz->FieldByName("dr")->AsDateTime);
Edit6->Text=dm->aqsrz->FieldByName("Cex")->AsString;
Edprof->Text=dm->aqsrz->FieldByName("naimprof")->AsString;

if (dm->aqsrz->FieldByName("Pol")->AsInteger==1)
   { CBpol->Text="�������";
   }
   else
       {
        CBpol->Text="�������";
       }


Edit7->Text=dm->aqsrz->FieldByName("adres")->AsString;





}
//---------------------------------------------------------------------------

void __fastcall TF_srz::SpeedButton1Click(TObject *Sender)
{

TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqprof->Locate("naimprof",Edprof->Text,Opts);
F_prof->Show();
F_prof->p3->Visible=true;
}
//---------------------------------------------------------------------------


void __fastcall TF_srz::FormCreate(TObject *Sender)
{
  MY_DBWork* wdb =new MY_DBWork;
   Cbprof->Clear();

    Cbprof->Items->Clear();
    Cbfam->Items->Clear();

       dm->aqsrz->First();

       while (!dm->aqsrz->Eof)
        {

           Cbprof->Items->Add(dm->aqsrz->FieldByName("naimprof")->AsString);
           Cbfam->Items->Add(dm->aqsrz->FieldByName("fam")->AsString);

           // �� �� ��������� ������� ����� ��� ���������  - ��-�� ����������� ��������!!!
           F_disp->Comfam->Items->Add(dm->aqsrz->FieldByName("fam")->AsString);
           F_disp->ComboBox1->Items->Add(dm->aqsrz->FieldByName("im")->AsString);
           F_disp->ComboBox2->Items->Add(dm->aqsrz->FieldByName("otch")->AsString);
           F_disp->ComboBox3->Items->Add(dm->aqsrz->FieldByName("Dr")->AsString);
           F_disp->ComboBox4->Items->Add(dm->aqsrz->FieldByName("cex")->AsString);

           F_boln->Comfam->Items->Add(dm->aqsrz->FieldByName("fam")->AsString);
           F_boln->ComboBox1->Items->Add(dm->aqsrz->FieldByName("im")->AsString);
           F_boln->ComboBox2->Items->Add(dm->aqsrz->FieldByName("otch")->AsString);
           F_boln->ComboBox3->Items->Add(dm->aqsrz->FieldByName("Dr")->AsString);
           F_boln->ComboBox4->Items->Add(dm->aqsrz->FieldByName("cex")->AsString);

           F_flur->Comfam->Items->Add(dm->aqsrz->FieldByName("fam")->AsString);
           F_flur->ComboBox1->Items->Add(dm->aqsrz->FieldByName("im")->AsString);
           F_flur->ComboBox2->Items->Add(dm->aqsrz->FieldByName("otch")->AsString);
           F_flur->ComboBox3->Items->Add(dm->aqsrz->FieldByName("Dr")->AsString);
           F_flur->ComboBox4->Items->Add(dm->aqsrz->FieldByName("cex")->AsString);

           F_gen->Comfam->Items->Add(dm->aqsrz->FieldByName("fam")->AsString);
           F_gen->ComboBox1->Items->Add(dm->aqsrz->FieldByName("im")->AsString);
           F_gen->ComboBox2->Items->Add(dm->aqsrz->FieldByName("otch")->AsString);
           F_gen->ComboBox3->Items->Add(dm->aqsrz->FieldByName("Dr")->AsString);
           F_gen->ComboBox4->Items->Add(dm->aqsrz->FieldByName("cex")->AsString);

           F_priv->Comfam->Items->Add(dm->aqsrz->FieldByName("fam")->AsString);
           F_priv->ComboBox1->Items->Add(dm->aqsrz->FieldByName("im")->AsString);
           F_priv->ComboBox2->Items->Add(dm->aqsrz->FieldByName("otch")->AsString);
           F_priv->ComboBox3->Items->Add(dm->aqsrz->FieldByName("Dr")->AsString);
           F_priv->ComboBox4->Items->Add(dm->aqsrz->FieldByName("cex")->AsString);

           // �� �� ��������� ������� ����� ��� ���������  - ��-�� ����������� ��������!!!





           dm->aqsrz->Next();

        }





   

}
//---------------------------------------------------------------------------

void __fastcall TF_srz::CbprofChange(TObject *Sender)
{
 TLocateOptions Opts;
 Opts.Clear();
 Opts << loPartialKey	;
 dm->aqsrz->Locate("naimprof",Cbprof->Text,Opts);

}
//---------------------------------------------------------------------------

void __fastcall TF_srz::CbfamChange(TObject *Sender)
{
 TLocateOptions Opts;
 Opts.Clear();
 Opts << loPartialKey	;
 dm->aqsrz->Locate("fam",Cbfam->Text,Opts);

}
//---------------------------------------------------------------------------

void __fastcall TF_srz::FormDeactivate(TObject *Sender)
{
//gl_datform=0;
}
//---------------------------------------------------------------------------

 void __fastcall TF_srz::ChangeLabel(TEdit *e1,TLabel *l1,TLabel *l2,TLabel *l3,TLabel *l4,TLabel *l5,TLabel *l6)
 {
e1->Text=dm->aqsrz->FieldByName("tn")->AsString;
l1->Caption=dm->aqsrz->FieldByName("fam")->AsString;
l2->Caption=dm->aqsrz->FieldByName("im")->AsString;
l3->Caption=dm->aqsrz->FieldByName("otch")->AsString;
l4->Caption=dm->aqsrz->FieldByName("dr")->AsString;
l5->Caption=dm->aqsrz->FieldByName("cex")->AsString;
l6->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;


 }

 //---------------------------------------------------------------------------

