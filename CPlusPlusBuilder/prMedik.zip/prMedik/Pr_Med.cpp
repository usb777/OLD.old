//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("Unit1.cpp", Form1);
USEFORM("U_disp.cpp", F_disp);
USEFORM("Udm.cpp", dm); /* TDataModule: File Type */
USEFORM("U_sprPolnySpisok.cpp", F_srz);
USEFORM("U_sprprof.cpp", F_prof);
USEFORM("U_gen.cpp", F_gen);
USEFORM("U_priv.cpp", F_priv);
USEFORM("U_boln.cpp", F_boln);
USEFORM("Uabout.cpp", Fabout);
USEFORM("U_flur.cpp", F_flur);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(Tdm), &dm);
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TF_priv), &F_priv);
                 Application->CreateForm(__classid(TF_boln), &F_boln);
                 Application->CreateForm(__classid(TF_flur), &F_flur);
                 Application->CreateForm(__classid(TF_gen), &F_gen);
                 Application->CreateForm(__classid(TF_disp), &F_disp);
                 Application->CreateForm(__classid(TF_srz), &F_srz);
                 Application->CreateForm(__classid(TF_prof), &F_prof);
                 Application->CreateForm(__classid(TFabout), &Fabout);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
