//---------------------------------------------------------------------------

#ifndef U_sprPolnySpisokH
#define U_sprPolnySpisokH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------
class TF_srz : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TGroupBox *gb;
        TBevel *Bevel1;
        TButton *buta;
        TButton *butu;
        TButton *butd;
        TPanel *Panel2;
        TDBGrid *DBGrid1;
        TBitBtn *Bitok;
        TBitBtn *Bitcan;
        TEdit *Edprof;
        TEdit *Edtab;
        TLabel *Label1;
        TLabel *Label2;
        TADOQuery *qu;
        TEdit *Edit1;
        TLabel *Label4;
        TPanel *p3;
        TBitBtn *BitBtn1;
        TSpeedButton *sb1;
        TEdit *Edit2;
        TLabel *Label5;
        TEdit *Edit3;
        TLabel *Label6;
        TLabel *Label7;
        TEdit *Edit4;
        TLabel *Label8;
        TEdit *Edit5;
        TSpeedButton *SpeedButton1;
        TEdit *Edit6;
        TLabel *Label9;
        TLabel *Label10;
        TComboBox *CBpol;
        TLabel *Label11;
        TEdit *Edit7;
        TDataSource *DSsrz;
        TLabel *Label3;
        TComboBox *Cbprof;
        TLabel *Label12;
        TComboBox *Cbfam;
        void __fastcall butaClick(TObject *Sender);
        void __fastcall butuClick(TObject *Sender);
        void __fastcall butdClick(TObject *Sender);
        void __fastcall BitokClick(TObject *Sender);
        void __fastcall BitcanClick(TObject *Sender);
        void __fastcall DataSource1DataChange(TObject *Sender,
          TField *Field);
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall Edit1Change(TObject *Sender);
        void __fastcall sb1Click(TObject *Sender);
        void __fastcall DSsrzDataChange(TObject *Sender, TField *Field);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall CbprofChange(TObject *Sender);
        void __fastcall CbfamChange(TObject *Sender);
        void __fastcall FormDeactivate(TObject *Sender);

private:	// User declarations
        void __fastcall ChangeLabel(TEdit *e1,TLabel *l1,TLabel *l2,TLabel *l3,TLabel *l4,TLabel *l5,TLabel *l6);


public:		// User declarations
        __fastcall TF_srz(TComponent* Owner);
      
};
//---------------------------------------------------------------------------
extern PACKAGE TF_srz *F_srz;
//---------------------------------------------------------------------------
#endif
