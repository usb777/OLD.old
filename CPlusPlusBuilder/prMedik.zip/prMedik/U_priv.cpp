//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_priv.h"
#include "Udm.h"
#include "CL_MY_DBWork.h"
#include "U_sprPolnySpisok.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_priv *F_priv;
MY_DBWork* wdb =new MY_DBWork;

TComboBox* cb[13];
String gl_dat[3];
String gl_sql="SELECT privivki.priv_nom, privivki.srz_tabnom, srz.FAM, srz.IM, srz.OTCH, srz.DR, srz.POL, prof.NAIMPROF, privivki.priv_data, privivki.priv_tipimun, privivki.priv_naimprep, privivki.priv_doza, privivki.priv_seria, privivki.priv_strana, privivki.priv_reakcia  FROM privivki INNER JOIN (srz INNER JOIN prof ON srz.PROF = prof.KODPROF) ON privivki.srz_tabnom = srz.TN ";




//----------------------------------------------------------
__fastcall TF_priv::TF_priv(TComponent* Owner)
        : TForm(Owner)
{
    cb[0]=Comfam;
    cb[1]=ComboBox1;
    cb[2]=ComboBox2;
    cb[3]=ComboBox3;
    cb[4]=ComboBox4;
    cb[5]=ComboBox5;
    cb[6]=ComboBox6;
    cb[7]=ComboBox7;
    cb[8]=ComboBox8;
    cb[9]=ComboBox9;
    cb[10]=ComboBox10;
    cb[11]=ComboBox11;


}
//---------------------------------------------------------------------------


void __fastcall TF_priv::Button5Click(TObject *Sender)
{
gbb->Visible=false;
}
//---------------------------------------------------------------------------

void __fastcall TF_priv::butaClick(TObject *Sender)
{
gbb->Caption=buta->Caption;

//Edit1->Clear();
//Edit1->Text="1063";
try
 {  dm->aqsrz->First();
  Edit1->Text=IntToStr(dm->aqsrz->FieldByName("tn")->AsInteger);
  }
 catch (Exception &e)   // "�" - ��� ������
 {  ShowMessage("������� ������: "+e.Message);   // ���������� "�" � ����� ���������  
 }

  dtp1->Date=Now();

Edit2->Clear();
Edit3->Clear();
Edit4->Clear();
Edit5->Clear();
Edit6->Clear();
ComboBox12->Text="";

Label14->Caption="";
Label15->Caption="";
Label16->Caption="";
Label17->Caption="";
Label18->Caption="";
Label19->Caption="";

gbb->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TF_priv::butuClick(TObject *Sender)
{

gbb->Caption=butu->Caption;
gbb->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::butdClick(TObject *Sender)
{

gbb->Caption=butd->Caption;
gbb->Visible=true;

 if (MessageDlg("������� ������� ������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {
  
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="delete  from privivki where priv_nom=:priv_nom";
        qub->Parameters->ParamByName("priv_nom")->Value=dm->aqpriv->FieldByName("priv_nom")->AsInteger;
        qub->ExecSQL();
    sb1->Click();
    gbb->Visible=false;

  }
else
    {gbb->Visible=false;}








}
//---------------------------------------------------------------------------

void __fastcall TF_priv::BitokClick(TObject *Sender)
{


        gl_dat[1]=DateToStr(dtp1->DateTime);


if (MessageDlg("�� ������� � ��������� ������?",mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {

  try
    {
       if (gbb->Caption==buta->Caption)
      {
      //  ShowMessage("����������");
        qub->Close();
        qub->SQL->Clear();

    //privivki.priv_nom, privivki.srz_tabnom, privivki.priv_data, privivki.priv_tipimun, privivki.priv_naimprep, privivki.priv_doza, privivki.priv_seria, privivki.priv_strana, privivki.priv_reakcia

        qub->SQL->Text="insert into privivki (srz_tabnom, priv_data, priv_tipimun, priv_naimprep, priv_doza, priv_seria, priv_strana, priv_reakcia) values(:srz_tabnom, :priv_data, :priv_tipimun, :priv_naimprep, :priv_doza, :priv_seria, :priv_strana, :priv_reakcia) ";
    //    ShowMessage(qub->SQL->Text);
        qub->Parameters->ParamByName("srz_tabnom")->Value=StrToInt(Edit1->Text);
        qub->Parameters->ParamByName("priv_data")->Value=StrToDate(gl_dat[1]);
        qub->Parameters->ParamByName("priv_tipimun")->Value=ComboBox12->Text;
        qub->Parameters->ParamByName("priv_naimprep")->Value=Edit2->Text;
        qub->Parameters->ParamByName("priv_doza")->Value=Edit3->Text;
        qub->Parameters->ParamByName("priv_seria")->Value=Edit4->Text;
        qub->Parameters->ParamByName("priv_strana")->Value=Edit5->Text;
        qub->Parameters->ParamByName("priv_reakcia")->Value=Edit6->Text;
    
        qub->ExecSQL();

       }

       if (gbb->Caption==butu->Caption)
      {
    //    ShowMessage("���������");
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="update privivki set srz_tabnom=:srz_tabnom, priv_data=:priv_data, priv_tipimun=:priv_tipimun, priv_naimprep=:priv_naimprep, priv_doza=:priv_doza, priv_seria=:priv_seria, priv_strana=:priv_strana, priv_reakcia=:priv_reakcia where priv_nom=:priv_nom";

        qub->Parameters->ParamByName("srz_tabnom")->Value=StrToInt(Edit1->Text);
        qub->Parameters->ParamByName("priv_data")->Value=StrToDate(gl_dat[1]);
        qub->Parameters->ParamByName("priv_tipimun")->Value=ComboBox12->Text;
        qub->Parameters->ParamByName("priv_naimprep")->Value=Edit2->Text;
        qub->Parameters->ParamByName("priv_doza")->Value=Edit3->Text;
        qub->Parameters->ParamByName("priv_seria")->Value=Edit4->Text;
        qub->Parameters->ParamByName("priv_strana")->Value=Edit5->Text;
        qub->Parameters->ParamByName("priv_reakcia")->Value=Edit6->Text;
       qub->Parameters->ParamByName("priv_nom")->Value=dm->aqpriv->FieldByName("priv_nom")->AsInteger;

        qub->ExecSQL();


       }

    } //try end
   catch  (Exception &e)   // "�" - ��� ������
     {
       ShowMessage("������� ������: "+e.Message);
         // ���������� "�" � ����� ���������
     }

  }
else
    {

    }



gbb->Visible=false;
//FormCreate(Sender);
sb1->Click();

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::BitcanClick(TObject *Sender)
{

  gbb->Visible=false;

}
//---------------------------------------------------------------------------


void __fastcall TF_priv::DSprivDataChange(TObject *Sender, TField *Field)
{

 Edit1->Text=dm->aqpriv->FieldByName("srz_tabnom")->AsString;

 ComboBox12->Text=dm->aqpriv->FieldByName("priv_tipimun")->AsString;
 Edit2->Text=dm->aqpriv->FieldByName("priv_naimprep")->AsString;
 Edit3->Text=dm->aqpriv->FieldByName("priv_doza")->AsString;
 Edit4->Text=dm->aqpriv->FieldByName("priv_seria")->AsString;
 Edit5->Text=dm->aqpriv->FieldByName("priv_strana")->AsString;
 Edit6->Text=dm->aqpriv->FieldByName("priv_reakcia")->AsString;
 dtp1->Date=dm->aqpriv->FieldByName("priv_data")->AsDateTime;


TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("Tn",Edit1->Text,Opts);


Label14->Caption=dm->aqsrz->FieldByName("Fam")->AsString;
Label15->Caption=dm->aqsrz->FieldByName("Im")->AsString;
Label16->Caption=dm->aqsrz->FieldByName("Otch")->AsString;
Label17->Caption=dm->aqsrz->FieldByName("dr")->AsString;
Label18->Caption=dm->aqsrz->FieldByName("CEX")->AsString;
Label19->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;


}
//---------------------------------------------------------------------------

void __fastcall TF_priv::sb1Click(TObject *Sender)
{

  dm->aqpriv->Close();
  dm->aqpriv->SQL->Clear();
  dm->aqpriv->SQL->Text=gl_sql+" order by srz.FAM ";
  dm->aqpriv->Open();
//  FormCreate(Sender);



}
//---------------------------------------------------------------------------

void __fastcall TF_priv::SpeedButton1Click(TObject *Sender)
{
 
TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("tn",StrToInt(Edit1->Text),Opts);

F_srz->Show();
F_srz->p3->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::FormCreate(TObject *Sender)
{

   for (int i=2;i<=10;i++)
   {
     DBGrid1->Columns->Items[i]->Width=100;
   }



  //

  for (int i=0;i<=11;i++)
   {
     cb[i]->Clear();
   }

   cb[0]->Text=Labfam->Caption;
   cb[1]->Text=Label1->Caption;
   cb[2]->Text=Label2->Caption;
   cb[3]->Text=Label3->Caption;
   cb[4]->Text=Label4->Caption;
   cb[5]->Text=Label5->Caption;
   cb[6]->Text=Label6->Caption;
   cb[7]->Text=Label7->Caption;
   cb[8]->Text=Label8->Caption;
   cb[9]->Text=Label9->Caption;
   cb[10]->Text=Label10->Caption;
   cb[11]->Text=Label11->Caption;





      dm->aqpriv->First();
       while (!dm->aqpriv->Eof)
        {
          ComboBox6->Items->Add(dm->aqpriv->FieldByName("priv_data")->AsString);
          ComboBox7->Items->Add(dm->aqpriv->FieldByName("priv_tipimun")->AsString);
          ComboBox8->Items->Add(dm->aqpriv->FieldByName("priv_naimprep")->AsString);
          ComboBox9->Items->Add(dm->aqpriv->FieldByName("priv_doza")->AsString);
          ComboBox10->Items->Add(dm->aqpriv->FieldByName("priv_seria")->AsString);
          ComboBox11->Items->Add(dm->aqpriv->FieldByName("priv_strana")->AsString);

          dm->aqpriv->Next();
        }







}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComfamChange(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"srz.FAM",Comfam->Text,"srz.FAM");
}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox1Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"srz.im",ComboBox1->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox2Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"srz.otch",ComboBox2->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox4Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"srz.cex",ComboBox4->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox5Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"prof.naimprof",ComboBox5->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox8Change(TObject *Sender)
{     //   , priv_doza, priv_seria, priv_strana, priv_reakcia
 wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"priv_naimprep",ComboBox8->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox9Change(TObject *Sender)
{
 //    priv_seria, priv_strana, priv_reakcia


wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"priv_doza",ComboBox9->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox11Change(TObject *Sender)
{

wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"priv_strana",ComboBox11->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox7Change(TObject *Sender)
{ 
wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"priv_tipimun",ComboBox7->Text,"srz.FAM");
    
}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox10Change(TObject *Sender)
{


wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"priv_seria",ComboBox10->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox6Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborkud(dm->aqpriv,gl_sql,"priv_data",StrToDate(ComboBox6->Text),"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_priv::ComboBox3Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqpriv,gl_sql,"srz.dr",ComboBox3->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

