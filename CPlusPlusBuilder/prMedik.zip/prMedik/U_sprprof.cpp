//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_sprprof.h"
#include "Udm.h"
#include "CL_MY_DBWork.h"
#include "U_sprPolnySpisok.h"

#include "U_boln.h"
#include "U_flur.h"
#include "U_priv.h"
#include "U_gen.h"
#include "U_disp.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_prof *F_prof;
  MY_DBWork* wdb =new MY_DBWork;

//---------------------------------------------------------------------------
__fastcall TF_prof::TF_prof(TComponent* Owner)
        : TForm(Owner)
{

}


//---------------------------------------------------------------------------

void __fastcall TF_prof::FormCreate(TObject *Sender)
{
 ComboBox1->Clear();

   while (!dm->aqprof->Eof)
        {

           ComboBox1->Items->Add(dm->aqprof->FieldByName("naimprof")->AsString);
           F_disp->ComboBox5->Items->Add(dm->aqprof->FieldByName("naimprof")->AsString);
           F_boln->ComboBox5->Items->Add(dm->aqprof->FieldByName("naimprof")->AsString);
           F_flur->ComboBox5->Items->Add(dm->aqprof->FieldByName("naimprof")->AsString);
           F_gen->ComboBox5->Items->Add(dm->aqprof->FieldByName("naimprof")->AsString);
           F_priv->ComboBox5->Items->Add(dm->aqprof->FieldByName("naimprof")->AsString);





          dm->aqprof->Next();

        }

}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
void __fastcall TF_prof::butaClick(TObject *Sender)
{

gb->Caption=buta->Caption;
Edtab->Clear();
Edprof->Clear();
gb->Visible=true;

}
//---------------------------------------------------------------------------
void __fastcall TF_prof::butuClick(TObject *Sender)
{
gb->Caption=butu->Caption;
 if (butu->Caption==gb->Caption)
{
Edtab->Text=IntToStr(dm->aqprof->FieldByName("kodprof")->AsInteger);
Edprof->Text=dm->aqprof->FieldByName("naimprof")->AsString;
 }

gb->Visible=true;
}
//---------------------------------------------------------------------------
void __fastcall TF_prof::butdClick(TObject *Sender)
{
gb->Caption=butd->Caption;


//Edtab->Text=IntToStr(dm->aqprof->FieldByName("prof_kod")->AsInteger);
Edprof->Text=dm->aqprof->FieldByName("naimprof")->AsString;


if (MessageDlg("������� ������� ������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {
  //   delete  from telsp where pns=:pns1
        qu->Close();
        qu->SQL->Clear();
        qu->SQL->Text="delete  from prof where prof_kod=:prof_kod";
        qu->Parameters->ParamByName("prof_kod")->Value=StrToInt(dm->aqprof->FieldByName("prof_kod")->AsInteger);
        qu->ExecSQL();
   sb1->Click();


  }
else
    {}

gb->Visible=true;
}
//---------------------------------------------------------------------------
void __fastcall TF_prof::BitokClick(TObject *Sender)
{

if (MessageDlg("�� ������� � ��������� ������?",mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {

  try
    {
       if (gb->Caption==buta->Caption)
      {
        ShowMessage("����������");
        qu->Close();
        qu->SQL->Clear();
        qu->SQL->Text="insert into prof(kodprof,naimprof) values(:kodprof,:naimprof) ";
        qu->Parameters->ParamByName("kodprof")->Value=StrToInt(Edtab->Text);
        qu->Parameters->ParamByName("naimprof")->Value=Edprof->Text;

     //  qu->ParamByName("kodprof")->asinteger=StrtoInt(Edtab.text);
     //  qu->parambyname("naimprof")->asstring=Edprof->Text;
        qu->ExecSQL();

       }

       if (gb->Caption==butu->Caption)
      {
        ShowMessage("���������");
        qu->Close();
        qu->SQL->Clear();
        qu->SQL->Text="update prof set naimprof=:naimprof where kodprof=:kodprof";

        qu->Parameters->ParamByName("kodprof")->Value=StrToInt(Edtab->Text);
        qu->Parameters->ParamByName("naimprof")->Value=Edprof->Text;


        qu->ExecSQL();


       }

    } //try end
   catch  (Exception &e)   // "�" - ��� ������
     {
       ShowMessage("������� ������: "+e.Message);
         // ���������� "�" � ����� ���������
     }

  }
else
    {

    }

     gb->Visible=false;
   sb1->Click();
 //    dm->aqprof->Close();
 //    dm->aqprof->Open();
  



}

//---------------------------------------------------------------------------
void __fastcall TF_prof::BitcanClick(TObject *Sender)
{
gb->Visible=false;
}
//---------------------------------------------------------------------------
void __fastcall TF_prof::DataSource1DataChange(TObject *Sender,
      TField *Field)
{

 if (butu->Caption==gb->Caption)
{
Edtab->Text=IntToStr(dm->aqprof->FieldByName("kodprof")->AsInteger);
Edprof->Text=dm->aqprof->FieldByName("naimprof")->AsString;
 }
}
//---------------------------------------------------------------------------


void __fastcall TF_prof::BitBtn1Click(TObject *Sender)
{

F_srz->Edprof->Text=dm->aqprof->FieldByName("naimprof")->AsString;
//p3->Visible=false;
F_prof->Close();

}
//---------------------------------------------------------------------------

void __fastcall TF_prof::ComboBox1Change(TObject *Sender)
{
dm->aqprof->Close();
dm->aqprof->SQL->Clear();
  dm->aqprof->SQL->Text="select * from prof where naimprof='"+ComboBox1->Text+"' order by naimprof" ;

dm->aqprof->Open();
}
//---------------------------------------------------------------------------

void __fastcall TF_prof::Edit1Change(TObject *Sender)
{
 TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqprof->Locate("naimprof",Edit1->Text,Opts);
}
//---------------------------------------------------------------------------

void __fastcall TF_prof::sb1Click(TObject *Sender)
{



  dm->aqprof->Close();
  dm->aqprof->SQL->Clear();
  dm->aqprof->SQL->Text="select * from prof ";
  dm->aqprof->Open();



}
