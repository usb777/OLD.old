//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_disp.h"
#include "Udm.h"
#include "CL_MY_DBWork.h"
#include "U_sprPolnySpisok.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_disp *F_disp;
MY_DBWork* wdb =new MY_DBWork;

TComboBox* cb[14];
String gl_dat[5];
String gl_sql="SELECT disp.disp_nom, srz_tabnom, srz.FAM, srz.IM, srz.OTCH, srz.POL, srz.DR, srz.CEX, prof.NAIMPROF, disp.disp_dv, disp.disp_ds,disp.disp_nya, disp.disp_otmya, disp.disp_krg, disp.disp_slvn, disp.disp_perinv, disp.disp_prsn, disp.disp_zabol FROM disp INNER JOIN (srz INNER JOIN prof ON srz.PROF = prof.KODPROF) ON disp.srz_tabnom = srz.TN ";




//----------------------------------------------------------
__fastcall TF_disp::TF_disp(TComponent* Owner)
        : TForm(Owner)
{
    cb[0]=Comfam;
    cb[1]=ComboBox1;
    cb[2]=ComboBox2;
    cb[3]=ComboBox3;
    cb[4]=ComboBox4;
    cb[5]=ComboBox5;
    cb[6]=ComboBox13;
    cb[7]=ComboBox6;
    cb[8]=ComboBox7;
    cb[9]=ComboBox9;







}

//---------------------------------------------------------------------------

void __fastcall TF_disp::FormCreate(TObject *Sender)
{
   for (int i=2;i<=14;i++)
   {
     DBGrid1->Columns->Items[i]->Width=100;
   }




  for (int i=0;i<=5;i++)
   {
     cb[i]->Clear();
   }


   cb[0]->Text=Labfam->Caption;
   cb[1]->Text=Label1->Caption;
   cb[2]->Text=Label2->Caption;
   cb[3]->Text=Label3->Caption;
   cb[4]->Text=Label4->Caption;
   cb[5]->Text=Label5->Caption;
   cb[6]->Text=Label7->Caption;
   cb[7]->Text=Label13->Caption;
   cb[8]->Text=Label9->Caption;
   cb[9]->Text=Label11->Caption;



       dm->aqdisp->First();
       while (!dm->aqdisp->Eof)
        {
          ComboBox6->Items->Add(dm->aqdisp->FieldByName("disp_slvn")->AsString);
        
          dm->aqdisp->Next();
        }


}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------


void __fastcall TF_disp::Button5Click(TObject *Sender)
{
gbb->Visible=false;
}
//---------------------------------------------------------------------------

void __fastcall TF_disp::butaClick(TObject *Sender)
{
gbb->Caption=buta->Caption;

//Edit1->Clear();
//Edit1->Text="1063";
try
 {  dm->aqsrz->First();
  Edit1->Text=IntToStr(dm->aqsrz->FieldByName("tn")->AsInteger);
  }
 catch (Exception &e)   // "�" - ��� ������
 {  ShowMessage("������� ������: "+e.Message);   // ���������� "�" � ����� ���������  
 }



  dtp1->Date=Now();
 // dtp2->Date=Now();
 me1->Text="";
 me2->Text="";

  dtp3->Date=Now();
 // dtp4->Date=Now();

  ComboBox8->Text="";
  Edit6->Clear();
  ComboBox14->Text="";
  Edit2->Clear();
  ComboBox15->Text="";


Label14->Caption="";
Label15->Caption="";
Label16->Caption="";
Label17->Caption="";
Label18->Caption="";
Label19->Caption="";

gbb->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TF_disp::butuClick(TObject *Sender)
{

gbb->Caption=butu->Caption;
gbb->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::butdClick(TObject *Sender)
{

gbb->Caption=butd->Caption;
gbb->Visible=true;

 if (MessageDlg("������� ������� ������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {
  //   delete  from telsp where pns=:pns1
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="delete  from disp where disp_nom=:disp_nom";
        qub->Parameters->ParamByName("disp_nom")->Value=dm->aqdisp->FieldByName("disp_nom")->AsInteger;
        qub->ExecSQL();
    sb1->Click();
    gbb->Visible=false;

  }
else
    {
       gbb->Visible=false;
    }








}
//---------------------------------------------------------------------------

void __fastcall TF_disp::BitokClick(TObject *Sender)
{
        gl_dat[1]=DateToStr(dtp1->DateTime);
     //   gl_dat[2]=DateToStr(dtp2->DateTime);
        gl_dat[3]=DateToStr(dtp3->DateTime);
    //    gl_dat[4]=DateToStr(dtp4->DateTime);




if (MessageDlg("�� ������� � ��������� ������?",mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes)
  {

  try
    {
       if (gbb->Caption==buta->Caption)
      {

 //     "SELECT disp_nom,  disp_dv, disp_ds,disp_nya, disp_otmya, disp_krg, disp_slvn, disp_perinv, disp_prsn, disp_zabol";

      //  ShowMessage("����������");
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="insert into disp (srz_tabnom, disp_dv, disp_ds,disp_nya, disp_otmya, disp_krg, disp_slvn, disp_perinv, disp_prsn, disp_zabol) values(:srz_tabnom, :disp_dv, :disp_ds, :disp_nya, :disp_otmya, :disp_krg, :disp_slvn, :disp_perinv, :disp_prsn, :disp_zabol) ";

        qub->Parameters->ParamByName("srz_tabnom")->Value=StrToInt(Edit1->Text);


        qub->Parameters->ParamByName("disp_dv")->Value=StrToDate(gl_dat[1]);
          // qub->Parameters->ParamByName("disp_ds")->Value=StrToDate(gl_dat[2]);
          // qub->Parameters->ParamByName("disp_otmya")->Value=StrToDate(gl_dat[4]);
        qub->Parameters->ParamByName("disp_ds")->Value=me1->Text;
        qub->Parameters->ParamByName("disp_otmya")->Value=me2->Text;

        qub->Parameters->ParamByName("disp_nya")->Value=StrToDate(gl_dat[3]);


        qub->Parameters->ParamByName("disp_krg")->Value=ComboBox8->Text;
        qub->Parameters->ParamByName("disp_slvn")->Value=Edit6->Text;
        qub->Parameters->ParamByName("disp_perinv")->Value=ComboBox14->Text;
        qub->Parameters->ParamByName("disp_prsn")->Value=Edit2->Text;
        qub->Parameters->ParamByName("disp_zabol")->Value=ComboBox15->Text;

        qub->ExecSQL();

       }

       if (gbb->Caption==butu->Caption)
      {
    //    ShowMessage("���������");
        qub->Close();
        qub->SQL->Clear();
        qub->SQL->Text="update disp set srz_tabnom=:srz_tabnom, disp_dv=:disp_dv, disp_ds=:disp_ds, disp_nya=:disp_nya, disp_otmya=:disp_otmya, disp_krg=:disp_krg, disp_slvn=:disp_slvn, disp_perinv=:disp_perinv, disp_prsn=:disp_prsn, disp_zabol=:disp_zabol where disp_nom=:disp_nom";

        qub->Parameters->ParamByName("srz_tabnom")->Value=StrToInt(Edit1->Text);

        qub->Parameters->ParamByName("disp_dv")->Value=StrToDate(gl_dat[1]);
        qub->Parameters->ParamByName("disp_nya")->Value=StrToDate(gl_dat[3]);
        qub->Parameters->ParamByName("disp_ds")->Value=me1->Text;
        qub->Parameters->ParamByName("disp_otmya")->Value=me2->Text;

      //   qub->Parameters->ParamByName("disp_ds")->Value=StrToDate(gl_dat[2]);
     //   qub->Parameters->ParamByName("disp_otmya")->Value=StrToDate(gl_dat[4]);

        qub->Parameters->ParamByName("disp_krg")->Value=ComboBox8->Text;
        qub->Parameters->ParamByName("disp_slvn")->Value=Edit6->Text;
        qub->Parameters->ParamByName("disp_perinv")->Value=ComboBox14->Text;
        qub->Parameters->ParamByName("disp_prsn")->Value=Edit2->Text;
        qub->Parameters->ParamByName("disp_zabol")->Value=ComboBox15->Text;



      qub->Parameters->ParamByName("disp_nom")->Value=dm->aqdisp->FieldByName("disp_nom")->AsInteger;


        qub->ExecSQL();


       }

    } //try end
   catch  (Exception &e)   // "�" - ��� ������
     {
       ShowMessage("������� ������: "+e.Message);
         // ���������� "�" � ����� ���������
     }

  }
else
    {

    }



gbb->Visible=false;
//FormCreate(Sender);
sb1->Click();

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::BitcanClick(TObject *Sender)
{

  gbb->Visible=false;

}
//---------------------------------------------------------------------------


void __fastcall TF_disp::DSbolDataChange(TObject *Sender, TField *Field)
{

 dtp1->Date=dm->aqdisp->FieldByName("disp_dv")->AsDateTime;
//dtp2->Date=dm->aqdisp->FieldByName("disp_ds")->AsDateTime;
 dtp3->Date=dm->aqdisp->FieldByName("disp_nya")->AsDateTime;
//dtp4->Date=dm->aqdisp->FieldByName("disp_otmya")->AsDateTime;
me1->Text=dm->aqdisp->FieldByName("disp_ds")->AsString;
me2->Text=dm->aqdisp->FieldByName("disp_otmya")->AsString;

 Edit1->Text=dm->aqdisp->FieldByName("srz_tabnom")->AsString;
 ComboBox8->Text=dm->aqdisp->FieldByName("disp_krg")->AsString;
 Edit6->Text=dm->aqdisp->FieldByName("disp_slvn")->AsString;
 ComboBox14->Text=dm->aqdisp->FieldByName("disp_perinv")->AsString;
 Edit2->Text=dm->aqdisp->FieldByName("disp_prsn")->AsString;
 ComboBox15->Text=dm->aqdisp->FieldByName("disp_zabol")->AsString;



TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("Tn",Edit1->Text,Opts);


Label14->Caption=dm->aqsrz->FieldByName("Fam")->AsString;
Label15->Caption=dm->aqsrz->FieldByName("Im")->AsString;
Label16->Caption=dm->aqsrz->FieldByName("Otch")->AsString;
Label17->Caption=dm->aqsrz->FieldByName("dr")->AsString;
Label18->Caption=dm->aqsrz->FieldByName("CEX")->AsString;
Label19->Caption=dm->aqsrz->FieldByName("naimprof")->AsString;

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::sb1Click(TObject *Sender)
{

  dm->aqdisp->Close();
  dm->aqdisp->SQL->Clear();
  dm->aqdisp->SQL->Text=gl_sql+" order by srz.FAM ";
  dm->aqdisp->Open();
//  FormCreate(Sender);



}
//---------------------------------------------------------------------------

void __fastcall TF_disp::SpeedButton1Click(TObject *Sender)
{

TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
dm->aqsrz->Locate("tn",StrToInt(Edit1->Text),Opts);

F_srz->Show();
//F_srz->gl_datform=2;
F_srz->p3->Visible=true;

}

void __fastcall TF_disp::ComfamChange(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"srz.FAM",Comfam->Text,"srz.FAM");
}
//---------------------------------------------------------------------------

void __fastcall TF_disp::ComboBox1Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"srz.im",ComboBox1->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::ComboBox2Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"srz.otch",ComboBox2->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::ComboBox4Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"srz.cex",ComboBox4->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::ComboBox5Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"prof.naimprof",ComboBox5->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::ComboBox6Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"disp_slvn",ComboBox6->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::ComboBox9Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"disp_zabol",ComboBox9->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::ComboBox7Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"disp_perinv",ComboBox7->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

void __fastcall TF_disp::ComboBox3Change(TObject *Sender)
{
wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"srz.dr",ComboBox3->Text,"srz.FAM");

}
//---------------------------------------------------------------------------


void __fastcall TF_disp::ComboBox14Change(TObject *Sender)
{
//wdb->MEGAZaprosNaVyborku(dm->aqflur,gl_sql,"flu_grup",ComboBox14->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

void __fastcall TF_disp::ComboBox13Change(TObject *Sender)
{
 wdb->MEGAZaprosNaVyborku(dm->aqdisp,gl_sql,"disp_krg",ComboBox13->Text,"srz.FAM");

}
//---------------------------------------------------------------------------

