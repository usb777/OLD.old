//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_prof.h"
#include "Udm.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_prof *F_prof;
//---------------------------------------------------------------------------
__fastcall TF_prof::TF_prof(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TF_prof::butaClick(TObject *Sender)
{
gb->Caption=buta->Caption;

gb->Visible=true;

}
//---------------------------------------------------------------------------
void __fastcall TF_prof::butuClick(TObject *Sender)
{
gb->Caption=butu->Caption;

gb->Visible=true;
}
//---------------------------------------------------------------------------
void __fastcall TF_prof::butdClick(TObject *Sender)
{
gb->Caption=butd->Caption;

gb->Visible=true;        
}
//---------------------------------------------------------------------------
void __fastcall TF_prof::BitokClick(TObject *Sender)
{
gb->Visible=false;        
}
//---------------------------------------------------------------------------
void __fastcall TF_prof::BitcanClick(TObject *Sender)
{
gb->Visible=false;        
}
//---------------------------------------------------------------------------
