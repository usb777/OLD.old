//---------------------------------------------------------------------------

#ifndef UdmH
#define UdmH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------
class Tdm : public TDataModule
{
__published:	// IDE-managed Components
        TADOConnection *adc1;
        TADOQuery *aqboln;
        TDataSource *DSB;
        TADOQuery *aqsrz;
        TDataSource *DSsrz;
        TDataSource *DSprof;
        TADOQuery *aqprof;
        TADOQuery *aqflur;
        TDataSource *DSF;
        TADOQuery *aqpriv;
        TDataSource *DSP;
        TADOQuery *aqgen;
        TDataSource *DSG;
        TADOQuery *aqdisp;
        TDataSource *DSD;
private:	// User declarations
public:		// User declarations
        __fastcall Tdm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tdm *dm;
//---------------------------------------------------------------------------
#endif
