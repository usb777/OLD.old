//---------------------------------------------------------------------------
    
#include <vcl.h>
#pragma hdrstop

#include "U_vhod.h"
#include "Unit2.h"
#include "U_ishod.h"
#include "U_razn1.h"
#include "U_pskvh.h"
#include "U_glav.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"



     TF_vhod *F_vhod;
//---------------------------------------------------------------------------
__fastcall TF_vhod::TF_vhod(TComponent* Owner)   : TForm(Owner)
{
}


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void __fastcall TF_vhod::Exp2Excel()
{ Variant App,Sh;
   String File;
App=Variant::CreateObject("Excel.Application");
if (File!="")
    { App.OlePropertyGet("WorkBooks").OleProcedure("Open",File);  }
    else
     {App.OlePropertyGet("WorkBooks").OleProcedure("add");
      Sh=App.OlePropertyGet("WorkSheets",1);
     }

if (!App.IsEmpty())
   App.OlePropertySet("Visible",true);

}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void __fastcall TF_vhod::FormCreate(TObject *Sender)
{
        F_vhod->aqvh1->Active=true;
  for (int i=1;i<=12;i++)
 { StatusBar1->Panels->Items[i-1]->Text="F"+IntToStr(i);
 }
 StatusBar1->Panels->Items[0]->Text=StatusBar1->Panels->Items[0]->Text+" ������";
 StatusBar1->Panels->Items[1]->Text=StatusBar1->Panels->Items[1]->Text+" ������";
 StatusBar1->Panels->Items[3]->Text=StatusBar1->Panels->Items[3]->Text+" �����";
  OpenVhod(F_vhod->DBGrid1);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void __fastcall TF_vhod::DBGrid1Exit(TObject *Sender)
{
ShowMessage("��������! ��� ��������������� ������ � ������� �xcel");
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------





void __fastcall TF_vhod::FormActivate(TObject *Sender)
{ 

countvisible=DBGrid1->FieldCount;
}
//---------------------------------------------------------------------------


void __fastcall TF_vhod::OpenVhod(TDBGrid* tdb)
{
   TIniFile *ini;
   ini = new TIniFile(ChangeFileExt( Application->ExeName, ".INI" ) );
tdb->Font->Size= ini->ReadInteger("Options Grid", tdb->Name+" font-size",10);
tdb->Font->Name=ini->ReadString("Options Grid", tdb->Name+" font-name","Times New Roman");

     for (int i=0;i<=9;i++)
     {DBGrid1->Columns->Items[i]->Width=ini->ReadInteger( "TableVhod_"+Label1->Caption, "Col"+IntToStr(i)+"Width",128);
     }

   delete ini;

 }
 
void __fastcall TF_vhod::DBGrid1KeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{


if (Key==VK_F2)
        { F_glav->MakeReport(DBGrid1,aqvh1);
          //ShowMessage(DBGrid1->Columns->Count);
        }



if (Key==VK_F4)
  { F_psvh->Tag=1;
    F_psvh->ShowModal();
  }
if (Key==13)
  {  //ShowMessage("�� ������ �nter");
                aqvh1->Edit();
                aqvh1->Post();
  }


 }


//---------------------------------------------------------------------------

void __fastcall TF_vhod::DBGrid1EditButtonClick(TObject *Sender)
{
//ShowMessage("ZI");

}
//---------------------------------------------------------------------------



//

void __fastcall TF_vhod::SpeedButton1Click(TObject *Sender)
{
  F_glav->MakeReport(DBGrid1,aqvh1);
}
//---------------------------------------------------------------------------

void __fastcall TF_vhod::SpeedButton2Click(TObject *Sender)
{
aqvh1->First();
}
//---------------------------------------------------------------------------

void __fastcall TF_vhod::SpeedButton3Click(TObject *Sender)
{
aqvh1->Prior();
}
//---------------------------------------------------------------------------

void __fastcall TF_vhod::SpeedButton4Click(TObject *Sender)
{
aqvh1->Next();
}
//---------------------------------------------------------------------------

void __fastcall TF_vhod::SpeedButton5Click(TObject *Sender)
{
aqvh1->Last();
}
//---------------------------------------------------------------------------

