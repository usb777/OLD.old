//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "u_razn1.h"
#include "U_rep_kom.h"
#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_rep_kom *F_rep_kom;
//---------------------------------------------------------------------------
__fastcall TF_rep_kom::TF_rep_kom(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------






