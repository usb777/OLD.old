//---------------------------------------------------------------------------


#pragma hdrstop

#include "Ufunc.h"
//---------------------------------------------------------------------------

#pragma package(smart_init)
void __fastcall SaveINI(TDBGrid* tdb)
{  TIniFile *ini;
   ini = new TIniFile(ChangeFileExt( Application->ExeName, ".INI" ) );

  for (int i=0;i<=10;i++)
  { ini->WriteInteger( "TableRazn", "Col"+IntToStr(i)+"Width",tdb->Columns->Items[i]->Width );
  }

   delete ini;
 }

void __fastcall OpenINI(TDBGrid* tdb)
{
   TIniFile *ini;
   ini = new TIniFile( ChangeFileExt( Application->ExeName, ".INI" ) );
   for (int i=0;i<=10;i++)
  {tdb->Columns->Items[i]->Width= ini->ReadInteger( "TableRazn", "Col"+IntToStr(i)+"Width",64);
  }

   delete ini;

 }
