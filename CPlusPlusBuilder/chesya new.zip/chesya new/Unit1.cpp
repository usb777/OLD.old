//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "U_ishod.h"
#include "U_razn1.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"



     TF_main *F_main;
//---------------------------------------------------------------------------
__fastcall TF_main::TF_main(TComponent* Owner)   : TForm(Owner)
{ // dm2->adc1->Connected=true;


}


void __fastcall TF_main::connect(TADOTable* a,char s[10])
{

a->Active=false;
a->TableName=s;
a->Active=true;

 }

 /*
void __fastcall TF_main::connect(TDataSet* Table)
{
Table->Active=false;
//Table->TableName="";
Table->Active=true;
 }

 */
//---------------------------------------------------------------------------



void __fastcall TF_main::N7Click(TObject *Sender)
{
//atvh1->Active=false;
//atvh1->TableName="bx_bt";
//atvh1->Active=true;
connect(atvh1,"bx_bt");
Label1->Caption=N7->Caption;
}
//---------------------------------------------------------------------------
void __fastcall TF_main::N6Click(TObject *Sender)
{

connect(atvh1,"bx_map");
Label1->Caption=N6->Caption;
}
//---------------------------------------------------------------------------
void __fastcall TF_main::N8Click(TObject *Sender)
{

connect(atvh1,"bx_ob");

Label1->Caption=N8->Caption;

}
//---------------------------------------------------------------------------
void __fastcall TF_main::N9Click(TObject *Sender)
{
connect(atvh1,"bx_pmp");
Label1->Caption=N9->Caption;
}
//---------------------------------------------------------------------------
void __fastcall TF_main::FormCreate(TObject *Sender)
{
   for(int i=0;i<=11;i++)
  {     // StatusBar1->Panels[1]="F";
  }

}
//---------------------------------------------------------------------------
void __fastcall TF_main::N11Click(TObject *Sender)
{


connect(F_ish->atih1,"is_pic");
F_ish->Label1->Caption=N11->Caption;
F_ish->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TF_main::N12Click(TObject *Sender)
{

connect(F_ish->atih1,"is_fax");

F_ish->Label1->Caption=N12->Caption;
F_ish->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TF_main::N13Click(TObject *Sender)
{

connect(F_ish->atih1,"is_tel");

F_ish->Label1->Caption=N13->Caption;
F_ish->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TF_main::DBGrid1Exit(TObject *Sender)
{
ShowMessage("��������� ������?");  
}
//---------------------------------------------------------------------------
void __fastcall TF_main::N15Click(TObject *Sender)
{
connect(F_razn->atr,"bx_dz");
F_razn->Label1->Caption=N15->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TF_main::N16Click(TObject *Sender)
{
connect(F_razn->atr,"bx_k");

F_razn->Label1->Caption=N16->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TF_main::N17Click(TObject *Sender)
{

connect(F_razn->atr,"bx_mp");

F_razn->Label1->Caption=N17->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TF_main::N18Click(TObject *Sender)
{

connect(F_razn->atr,"bx_plv");

F_razn->Label1->Caption=N18->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TF_main::N19Click(TObject *Sender)
{
connect(F_razn->atr,"rz_rpt");
F_razn->Label1->Caption=N19->Caption;
F_razn->ShowModal();

}
//---------------------------------------------------------------------------

void __fastcall TF_main::N20Click(TObject *Sender)
{

connect(F_razn->atr,"rz_ucpr");

F_razn->Label1->Caption=N20->Caption;
F_razn->ShowModal();

}
//---------------------------------------------------------------------------

void __fastcall TF_main::N21Click(TObject *Sender)
{

connect(F_razn->atr,"rz_ucko");

F_razn->Label1->Caption=N21->Caption;
F_razn->ShowModal();

}
//---------------------------------------------------------------------------

void __fastcall TF_main::N22Click(TObject *Sender)
{


connect(F_razn->atr,"rz_ra");

F_razn->Label1->Caption=N22->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TF_main::N23Click(TObject *Sender)
{


connect(F_razn->atr,"adres");

F_razn->Label1->Caption=N23->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TF_main::N24Click(TObject *Sender)
{


connect(F_razn->atr,"rz_pr");

F_razn->Label1->Caption=N24->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TF_main::N25Click(TObject *Sender)
{


connect(F_razn->atr,"dn_rojd");

F_razn->Label1->Caption=N25->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TF_main::N26Click(TObject *Sender)
{


connect(F_razn->atr,"putev");


F_razn->Label1->Caption=N26->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TF_main::N27Click(TObject *Sender)
{

connect(F_razn->atr,"bx_uvol");

F_razn->Label1->Caption=N27->Caption;
F_razn->ShowModal();
}
//---------------------------------------------------------------------------

