//---------------------------------------------------------------------------

#ifndef u_razn1H
#define u_razn1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ADODB.hpp>
#include <ComCtrls.hpp>
#include <DB.hpp>
#include <DBGrids.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <DBCtrls.hpp>
#include <Inifiles.hpp>
#include <Buttons.hpp>
#include      <ComObj.hpp>
#include      <utilcls.h>


//---------------------------------------------------------------------------
class TF_razn : public TForm
{
__published:	// IDE-managed Components

        TPanel *Panel1;
        TLabel *Label1;
        TGroupBox *GroupBox1;
        TStatusBar *StatusBar1;
        TDBNavigator *DBNavigator1;
        TDataSource *DataSource2;
        TDBGrid *DBGrid1;
        TSpeedButton *bprint;
        TPanel *Panel2;
        TSpeedButton *SpeedButton2;
        TPanel *Panel3;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton3;
        TSpeedButton *SpeedButton4;
        TSpeedButton *SpeedButton5;
        TADOQuery *aqr;
        TSpeedButton *Sprint;
        TSpeedButton *SPWOrd;
        TMemo *Memo1;
        void __fastcall DBGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton3Click(TObject *Sender);
        void __fastcall SpeedButton4Click(TObject *Sender);
        void __fastcall SpeedButton5Click(TObject *Sender);
        void __fastcall SprintClick(TObject *Sender);
        void __fastcall SPWOrdClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TF_razn(TComponent* Owner);
         int countvisible;
         void __fastcall Openrazn(TDBGrid* tdb);

              Variant App,Sh, Rang;

              Variant         vVarApp,vVarDocs,vVarDoc,vVarParagraphs,
                                vVarParagraph,vVarRange,vVarTables,vVarTable,
                                vVarCell, v,v1;
               bool fStart;
               String str;
      };
//---------------------------------------------------------------------------
extern PACKAGE TF_razn *F_razn;
//---------------------------------------------------------------------------
#endif
