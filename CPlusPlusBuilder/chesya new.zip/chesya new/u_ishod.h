//---------------------------------------------------------------------------

#ifndef u_ishodH
#define u_ishodH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ADODB.hpp>
#include <ComCtrls.hpp>
#include <DB.hpp>
#include <DBGrids.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <DBCtrls.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TF_ish : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TLabel *Label1;
        TGroupBox *GroupBox1;
        TStatusBar *StatusBar1;
        TDataSource *DataSource2;
        TDBNavigator *DBNavigator1;
        TDBGrid *DBGrid1;
        TPanel *Panel2;
        TSpeedButton *SpeedButton2;
        TPanel *Panel3;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton3;
        TSpeedButton *SpeedButton4;
        TSpeedButton *SpeedButton5;
        TADOQuery *aqih1;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall DBGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall DBGrid1KeyPress(TObject *Sender, char &Key);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton3Click(TObject *Sender);
        void __fastcall SpeedButton4Click(TObject *Sender);
        void __fastcall SpeedButton5Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TF_ish(TComponent* Owner);
        int countvisible ;
        void __fastcall OpenIsh(TDBGrid* tdb);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_ish *F_ish;
//---------------------------------------------------------------------------
#endif
