//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_glav.h"
#include "U_vhod.h"
#include "Unit2.h"
#include "U_razn1.h"
#include "u_ishod.h"
#include "Uabout.h"



//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

  String Cap;

     TF_glav *F_glav;
//---------------------------------------------------------------------------
__fastcall TF_glav::TF_glav(TComponent* Owner)   : TForm(Owner)
{

}

//---------------------------------------------------------------------------



 void __fastcall TF_glav::connect(TADOQuery* a,String sql)
{
a->Active=false;
a->SQL->Clear();
a->SQL->Text=sql;
a->Active=true;

a->Last();
}



void __fastcall TF_glav::connect(TADOQuery* a,String sql,String t1)
{

a->Active=false;
a->SQL->Clear();
a->SQL->Text=sql;
a->Active=true;

a->FieldByName(t1)->EditMask="!99/99/00;1;_";

a->Last();
 }


void __fastcall TF_glav::connect(TADOQuery* a,String sql,String t1,String t2)
{

 a->Active=false;
  a->SQL->Clear();
  a->SQL->Text=sql;
 a->Active=true;

   a->FieldByName(t1)->EditMask="!99/99/00;1;_";
   a->FieldByName(t2)->EditMask="!99/99/00;1;_";
a->Last();

 }

void __fastcall TF_glav::connect(TADOQuery* a,String sql,String t1,String t2,String t3)
{

 a->Active=false;
  a->SQL->Clear();
  a->SQL->Text=sql;
 a->Active=true;

   a->FieldByName(t1)->EditMask="!99/99/00;1;_";
   a->FieldByName(t2)->EditMask="!99/99/00;1;_";
   a->FieldByName(t3)->EditMask="!99/99/00;1;_";

a->Last();

 }

void __fastcall TF_glav::connect(TADOQuery* a,String sql,String t1,String t2,String t3, String t4)
{

 a->Active=false;
  a->SQL->Clear();
  a->SQL->Text=sql;
 a->Active=true;

   a->FieldByName(t1)->EditMask="!99/99/00;1;_";
   a->FieldByName(t2)->EditMask="!99/99/00;1;_";
   a->FieldByName(t3)->EditMask="!99/99/00;1;_";
   a->FieldByName(t4)->EditMask="!99/99/00;1;_";


a->Last();

 }




 void __fastcall TF_glav::gridvisual(TDBGrid* dbg,short i1)
{    short i2=15; // ���-�� �������� -1  � �������
    for(int i=i1;i<=i2;i++)
    { dbg->Columns->Items[i]->Visible=false;}

   for(int i=0;i<=i1-1;i++)
    { dbg->Columns->Items[i]->Visible=true;}

 }


//---------------------------------------------------------------------------



void __fastcall TF_glav::Formstyle(TForm* f1,TForm* f2,TForm* f3,bool fv1,bool fv2,bool fv3)
{
  if ((fv1==false)||(fv2==false)||(fv3==false))
  { f1->WindowState=wsMinimized;
    f2->WindowState=wsMinimized;
    f3->WindowState=wsMinimized;
  };

  if ((fv1==true)||(fv2==false)||(fv3==false))
  { f1->WindowState=wsMaximized;
    f2->WindowState=wsMinimized;
    f3->WindowState=wsMinimized;
  };

  if ((fv1==false)||(fv2==true)||(fv3==false))
  { f1->WindowState=wsMinimized;
    f2->WindowState=wsMaximized;
    f3->WindowState=wsMinimized;
  };
    if ((fv1==false)||(fv2==false)||(fv3==true))
  { f1->WindowState=wsMinimized;
    f2->WindowState=wsMinimized;
    f3->WindowState=wsMaximized;
  };


 }



//---------------------------------------------------------------------------
void __fastcall TF_glav::SaveGrid1(TDBGrid* tdb,String tn)
{  TIniFile *ini;
   ini = new TIniFile(ChangeFileExt( Application->ExeName, ".INI" ));
   ini->WriteInteger("Options Grid", tdb->Name+" font-size",tdb->Font->Size);
   ini->WriteString( "Options Grid", tdb->Name+" font-name",tdb->Font->Name);



     if ((tn==N6->Caption)||(tn==N7->Caption)||(tn==N8->Caption)||(tn==N9->Caption))
    { for (int i=0;i<=9;i++)
        { ini->WriteInteger( "TableVhod_"+tn, "Col"+IntToStr(i)+"Width",tdb->Columns->Items[i]->Width );
        }
     }

    if ((tn==N11->Caption)||(tn==N12->Caption)||(tn==N13->Caption)  )
     { for (int j=0;j<=4;j++)
         { ini->WriteInteger( "TableIshod_"+tn, "Col"+IntToStr(j)+"Width",tdb->Columns->Items[j]->Width );
         }
      }

     if ((tn==N15->Caption)||(tn==N16->Caption)||(tn==N17->Caption)||(tn==N18->Caption)||(tn==N19->Caption)||(tn==N20->Caption)||(tn==N21->Caption)||(tn==N22->Caption)||(tn==N23->Caption)||(tn==N24->Caption)||(tn==N25->Caption)||(tn==N26->Caption)||(tn==N27->Caption))
        for (int j=0;j<=11;j++)
         { ini->WriteInteger( "TableRazn_"+tn, "Col"+IntToStr(j)+"Width",tdb->Columns->Items[j]->Width );
         }


   delete ini;
 }

//------------------------------------------------------------------------




void __fastcall TF_glav::Zachistka(TADOTable* t1,TADOQuery* q1)
{
F_vhod->aqvh1->Active=false;
F_ish->aqih1->Active=false;
F_razn->aqr->Active=false;

  t1->Open();
  t1->Active;
  t1->First();

    String c="";

 while (!(t1->Eof))
 {
  q1->Close();
  q1->SQL->Clear();

  if ((t1->FieldByName("IM_NTX")->AsString=="adres")) {goto m1;}
    else{
      if ((t1->FieldByName("IM_NTX")->AsString=="dn_rojd")) {goto m1;}
            {
             q1->SQL->Text="delete * from "+t1->FieldByName("IM_NTX")->AsString+";";
             // c="delete * from "+t1->FieldByName("IM_NTX")->AsString+";" ;
            //  ShowMessage(c);
             q1->ExecSQL();
            }
         } //else
 m1:
     t1->Next();
 }


F_vhod->aqvh1->Active=true;
F_ish->aqih1->Active=true;
F_razn->aqr->Active=true;

}

//---------------------------------------------------------------------

void __fastcall TF_glav::N7Click(TObject *Sender)
{


//connect(F_vhod->atvh1,"bx_bt","date","data");
sql1="select * from bx_bt ";
sql2="order by ind";

connect(F_vhod->aqvh1,sql1+sql2,"date","data");

F_vhod->Label1->Caption=N7->Caption;
F_vhod->OpenVhod(F_vhod->DBGrid1);

F_vhod->WindowState=wsMaximized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMinimized;

//Formstyle(F_vhod,F_ish,F_razn,bool v1=true ,bool v2=false,bool v3=false);
//F_vhod->WindowState=wsMaximized;


}
//---------------------------------------------------------------------------
void __fastcall TF_glav::N6Click(TObject *Sender)
{
sql1="select * from bx_map ";
sql2="order by ind";


//connect(F_vhod->atvh1,"bx_map","date","data");
connect(F_vhod->aqvh1,sql1+sql2,"date","data");

F_vhod->Label1->Caption=N6->Caption;
F_vhod->OpenVhod(F_vhod->DBGrid1);

F_vhod->WindowState=wsMaximized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMinimized;


}
//---------------------------------------------------------------------------
void __fastcall TF_glav::N8Click(TObject *Sender)
{

sql1="select * from bx_ob ";
sql2="order by ind";

//connect(F_vhod->atvh1,"bx_ob","date","data","di");
connect(F_vhod->aqvh1,sql1+sql2,"date","data","di");


F_vhod->Label1->Caption=N8->Caption;
F_vhod->WindowState=wsMaximized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMinimized;
  // F_vhod->DBGrid1->Columns->Items[10]->Title->Caption="���������� �����";
   //F_vhod->DBGrid1->Columns->Items[10]->FieldName="ind" ;
F_vhod->OpenVhod(F_vhod->DBGrid1);
   }
//---------------------------------------------------------------------------
void __fastcall TF_glav::N9Click(TObject *Sender)
{

sql1="select * from bx_pmp ";
sql2="order by ind";

F_vhod->OpenVhod(F_vhod->DBGrid1);

//connect(F_vhod->atvh1,"bx_pmp","date","data");
connect(F_vhod->aqvh1,sql1+sql2,"date","data");


F_vhod->Label1->Caption=N9->Caption;
F_vhod->WindowState=wsMaximized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMinimized;

F_vhod->OpenVhod(F_vhod->DBGrid1);
}
//---------------------------------------------------------------------------
void __fastcall TF_glav::FormCreate(TObject *Sender)
{

  priarh=0;
   Cap=Caption;
   CopyFile("cbaza.mdb","c_rest.mdb",true);
  

}

//---------------------------------------------------------------------------
void __fastcall TF_glav::N11Click(TObject *Sender)
{


sql1="select * from is_pic ";
sql2="order by ind";

connect(F_ish->aqih1,sql1+sql2,"date");



F_ish->Label1->Caption=N11->Caption;
F_ish->OpenIsh(F_ish->DBGrid1);

F_ish->WindowState=wsMaximized;
F_vhod->WindowState=wsMinimized;
F_razn->WindowState=wsMinimized;

}
//---------------------------------------------------------------------------
void __fastcall TF_glav::N12Click(TObject *Sender)
{

//connect(F_ish->atih1,"is_fax","date");

sql1="select * from is_fax ";
sql2="order by ind";

connect(F_ish->aqih1,sql1+sql2,"date");


F_ish->Label1->Caption=N12->Caption;
F_ish->OpenIsh(F_ish->DBGrid1);

  F_ish->WindowState=wsMaximized;
F_vhod->WindowState=wsMinimized;
F_razn->WindowState=wsMinimized;
}
//---------------------------------------------------------------------------
void __fastcall TF_glav::N13Click(TObject *Sender)
{

//connect(F_ish->atih1,"is_tel","date");
sql1="select * from is_tel ";
sql2="order by ind";
connect(F_ish->aqih1,sql1+sql2,"date");

F_ish->Label1->Caption=N13->Caption;
F_ish->OpenIsh(F_ish->DBGrid1);


F_ish->WindowState=wsMaximized;
F_vhod->WindowState=wsMinimized;
F_razn->WindowState=wsMinimized;
}
//---------------------------------------------------------------------------
void __fastcall TF_glav::DBGrid1Exit(TObject *Sender)
{
ShowMessage("��������� ������?");
}
//---------------------------------------------------------------------------
void __fastcall TF_glav::N15Click(TObject *Sender)
{
F_razn->Sprint->Visible=false;
F_razn->SPWOrd->Visible=false;



F_razn->Label1->Caption=N15->Caption;


F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="���� ���������";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="�.�.�. ��������������";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="���������� ���������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="���� ���������";
F_razn->DBGrid1->Columns->Items[5]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[6]->Title->Caption="����������";

gridvisual(F_razn->DBGrid1,7);
//F_razn->countvisible=6;

//connect(F_razn->atr,"bx_dz","date","date","date");

sql1="select * from  bx_dz ";
sql2="order by ind";

connect(F_razn->aqr,sql1+sql2,"date","date","date");



F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="sdoc" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="komy" ;
F_razn->DBGrid1->Columns->Items[5]->FieldName="rez" ;
F_razn->DBGrid1->Columns->Items[6]->FieldName="prim" ;
F_razn->DBGrid1->Columns->Items[7]->FieldName="ind" ;

F_razn->DBGrid1->DataSource=F_razn->DataSource2;
 F_razn->DBGrid1->Refresh();


F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;

}
//---------------------------------------------------------------------------


void __fastcall TF_glav::N16Click(TObject *Sender)
{
F_razn->Sprint->Visible=true;
F_razn->SPWOrd->Visible=false;
// poka ih 8
F_razn->Label1->Caption=N16->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="���� ���������";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="�.�.�";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="���� ���������";
F_razn->DBGrid1->Columns->Items[5]->Title->Caption="���� ������";
F_razn->DBGrid1->Columns->Items[6]->Title->Caption="���� ���������";
F_razn->DBGrid1->Columns->Items[7]->Title->Caption="�.�.�. ������������, ������������ ��" ;
F_razn->DBGrid1->Columns->Items[8]->Title->Caption="������" ;


gridvisual(F_razn->DBGrid1,8);
//F_razn->countvisible=8;

sql1="select * from bx_k ";
sql2="order by ind";

connect(F_razn->aqr,sql1+sql2,"date","nk","kk");



F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="dol" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="gorod" ;
F_razn->DBGrid1->Columns->Items[5]->FieldName="nk" ;
F_razn->DBGrid1->Columns->Items[6]->FieldName="kk" ;
F_razn->DBGrid1->Columns->Items[7]->FieldName="prim" ;
F_razn->DBGrid1->Columns->Items[8]->FieldName="ind" ;


F_razn->DBGrid1->Refresh();

F_razn->Openrazn(F_razn->DBGrid1);
F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;

}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N17Click(TObject *Sender)
{
F_razn->Sprint->Visible=false;
F_razn->SPWOrd->Visible=false;
F_razn->Label1->Caption=N17->Caption;


F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="���� ���������";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="�.�.� ��������������";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="������� ���������";
F_razn->DBGrid1->Columns->Items[5]->Title->Caption="��� �������������";
F_razn->DBGrid1->Columns->Items[6]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[7]->Title->Caption="������� � ����������";



gridvisual(F_razn->DBGrid1,8);
//F_razn->countvisible=6;

//connect(F_razn->atr,"bx_mp","date");

sql1="select * from bx_mp ";
sql2="order by ind";
connect(F_razn->aqr,sql1+sql2,"date");


F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="dol" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="prich" ;
F_razn->DBGrid1->Columns->Items[5]->FieldName="komy" ;
F_razn->DBGrid1->Columns->Items[6]->FieldName="rez" ;
F_razn->DBGrid1->Columns->Items[7]->FieldName="ovyp" ;

F_razn->DBGrid1->Columns->Items[8]->FieldName="ind";

F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;



}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N18Click(TObject *Sender)
{
F_razn->Sprint->Visible=false;
F_razn->SPWOrd->Visible=false;
F_razn->Label1->Caption=N18->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="���� ���������";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="�.�.� ��������������";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="������� ���������";
F_razn->DBGrid1->Columns->Items[5]->Title->Caption="��� �������������";
F_razn->DBGrid1->Columns->Items[6]->Title->Caption="���������";

gridvisual(F_razn->DBGrid1,7);
//F_razn->countvisible=6;

//connect(F_razn->atr,"bx_plv","date");
sql1="select * from bx_plv ";
sql2="order by ind";
connect(F_razn->aqr,sql1+sql2,"date");


F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="dol" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="prich" ;
F_razn->DBGrid1->Columns->Items[5]->FieldName="komy" ;
F_razn->DBGrid1->Columns->Items[6]->FieldName="rez" ;
F_razn->DBGrid1->Columns->Items[7]->FieldName="ind" ;


F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;



}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N19Click(TObject *Sender)
{
F_razn->Sprint->Visible=false;
F_razn->SPWOrd->Visible=false;

F_razn->Label1->Caption=N19->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="���� �����������";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="�.�.� ��������������, �����, �������";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="���������� ��������� (�����, �����)";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="��� ���������";
F_razn->DBGrid1->Columns->Items[5]->Title->Caption="������� ����������";
F_razn->DBGrid1->Columns->Items[6]->Title->Caption="������������ �����������";
F_razn->DBGrid1->Columns->Items[7]->Title->Caption="���� ����������";
F_razn->DBGrid1->Columns->Items[8]->Title->Caption="���� ����������";
F_razn->DBGrid1->Columns->Items[9]->Title->Caption="���������� ���������";
F_razn->DBGrid1->Columns->Items[10]->Title->Caption="���������� ���������";

  // F_razn->countvisible=10;

  gridvisual(F_razn->DBGrid1,10);


 sql1="select * from rz_rpt ";
 sql2="order by ind";
   connect(F_razn->aqr,sql1+sql2,"date","date_is","so_re");


F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="korr" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="pr_ob" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="vi_do" ;
F_razn->DBGrid1->Columns->Items[5]->FieldName="kr_so" ;
F_razn->DBGrid1->Columns->Items[6]->FieldName="ot_is" ;
F_razn->DBGrid1->Columns->Items[7]->FieldName="sr_is" ;
F_razn->DBGrid1->Columns->Items[8]->FieldName="date_is" ;
F_razn->DBGrid1->Columns->Items[9]->FieldName="so_re" ;
F_razn->DBGrid1->Columns->Items[10]->FieldName="na_ma" ;
F_razn->DBGrid1->Columns->Items[11]->FieldName="ind" ;




F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;




}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N20Click(TObject *Sender)
{
F_razn->Sprint->Visible=false;
F_razn->SPWOrd->Visible=false;


F_razn->Label1->Caption=N20->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="�.�.�";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="����";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="�� ����� ����������� ������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="�� ������ �������";

gridvisual(F_razn->DBGrid1,5);

// F_razn->countvisible=4;

//connect(F_razn->atr,"rz_ucpr","date");

 sql1="select * from rz_ucpr ";
 sql2="order by ind";
connect(F_razn->aqr,sql1+sql2,"date");



F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="pror" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="vopr" ;
F_razn->DBGrid1->Columns->Items[5]->FieldName="ind" ;



F_razn->Openrazn(F_razn->DBGrid1);
F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;



}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N21Click(TObject *Sender)
{

F_razn->Sprint->Visible=false;
 F_razn->SPWOrd->Visible=false;


F_razn->Label1->Caption=N21->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="���� �����������";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="�.�.�";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="����� ������";
F_razn->DBGrid1->Columns->Items[5]->Title->Caption="���� ������ ������������";
F_razn->DBGrid1->Columns->Items[6]->Title->Caption="���� ��������� ������������";

gridvisual(F_razn->DBGrid1,7);
F_razn->countvisible=6;

//connect(F_razn->atr,"rz_ucko","date","datenk","datekk");


 sql1="select * from rz_ucko ";
 sql2="order by ind";
connect(F_razn->aqr,sql1+sql2,"date","datenk","datekk");


F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="dolg" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="mr" ;
F_razn->DBGrid1->Columns->Items[5]->FieldName="datenk" ;
F_razn->DBGrid1->Columns->Items[6]->FieldName="datekk" ;
F_razn->DBGrid1->Columns->Items[7]->FieldName="ind" ;


F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;




}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N22Click(TObject *Sender)
{
F_razn->Sprint->Visible=true;
F_razn->SPWOrd->Visible=false;

F_razn->Label1->Caption=N22->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="����";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="������������ �����������";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="������� ����������";

gridvisual(F_razn->DBGrid1,4);
 F_razn->countvisible=3;

 //connect(F_razn->atr,"rz_ra","date");

 sql1="select * from rz_ra ";
 sql2="order by ind";

  connect(F_razn->aqr,sql1+sql2,"date");


F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="ot_is" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="kr_so" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="ind" ;




F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;


}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N23Click(TObject *Sender)
{
F_razn->Sprint->Visible=false;
 F_razn->SPWOrd->Visible=false;


F_razn->Label1->Caption=N23->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="�.�.�";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="�������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="�������� �����";

gridvisual(F_razn->DBGrid1,5);
F_razn->countvisible=4;

//connect(F_razn->atr,"adres");


 sql1="select * from adres ";
 sql2="order by ind";
connect(F_razn->aqr,sql1+sql2);



F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="dol" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="tel" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="adr" ;
F_razn->DBGrid1->Columns->Items[5]->FieldName="ind" ;


F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;



}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N24Click(TObject *Sender)
{
F_razn->Sprint->Visible=true;
F_razn->SPWOrd->Visible=false;

F_razn->Label1->Caption=N24->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="����";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="������������ �����������";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="������� ����������";

gridvisual(F_razn->DBGrid1,4);
 F_razn->countvisible=3;

 //connect(F_razn->atr,"rz_pr","date");
 sql1="select * from rz_pr ";
 sql2="order by ind";

 connect(F_razn->aqr,sql1+sql2,"date");


F_razn->DBGrid1->Columns->Items[0]->FieldName="no";
F_razn->DBGrid1->Columns->Items[1]->FieldName="date";
F_razn->DBGrid1->Columns->Items[2]->FieldName="ot_is";
F_razn->DBGrid1->Columns->Items[3]->FieldName="kr_so";
F_razn->DBGrid1->Columns->Items[4]->FieldName="ind";


F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;


}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N25Click(TObject *Sender)
{

F_razn->Sprint->Visible=false;
F_razn->SPWOrd->Visible=false;


 sql1="select * from dn_rojd ";
 sql2="order by ind";
connect(F_razn->aqr,sql1+sql2,"date");

F_razn->Label1->Caption=N25->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="�.�.�";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="���� ��������";

gridvisual(F_razn->DBGrid1,4);
 F_razn->countvisible=3;

F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="dol" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="ind" ;


 F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;



}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N26Click(TObject *Sender)
{
F_razn->Sprint->Visible=false;
F_razn->SPWOrd->Visible=false;

//connect(F_razn->atr,"putev","date");

 sql1="select * from putev ";
 sql2="order by ind";
connect(F_razn->aqr,sql1+sql2,"date");



F_razn->Label1->Caption=N26->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="���� �����������";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="�.�.�";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="������� ���������";
F_razn->DBGrid1->Columns->Items[5]->Title->Caption="��� �������������";
F_razn->DBGrid1->Columns->Items[6]->Title->Caption="���������";

gridvisual(F_razn->DBGrid1,7);
F_razn->countvisible=6;

F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="dolg" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="prich";
F_razn->DBGrid1->Columns->Items[5]->FieldName="rasm" ;
F_razn->DBGrid1->Columns->Items[6]->FieldName="rez" ;
F_razn->DBGrid1->Columns->Items[7]->FieldName="ind" ;


F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;


}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N27Click(TObject *Sender)
{
F_razn->Sprint->Visible=false;
F_razn->SPWOrd->Visible=false;


F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="���� ���������";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="�.�.�";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="���������� ���������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="���������";
F_razn->DBGrid1->Columns->Items[5]->Title->Caption="���� ���������";
F_razn->DBGrid1->Columns->Items[6]->Title->Caption="����������";

gridvisual(F_razn->DBGrid1,7);
F_razn->countvisible=6;

//connect(F_razn->atr,"bx_uvol","date");

 sql1="select * from bx_uvol ";
 sql2="order by ind";
connect(F_razn->aqr,sql1+sql2,"date");


F_razn->DBGrid1->Columns->Items[0]->FieldName="no" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="date" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="sdoc" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="rez" ;
F_razn->DBGrid1->Columns->Items[5]->FieldName="komy" ;
F_razn->DBGrid1->Columns->Items[6]->FieldName="prim" ;
F_razn->DBGrid1->Columns->Items[7]->FieldName="ind" ;



F_razn->Label1->Caption=N27->Caption;


F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;

}
//---------------------------------------------------------------------------


void __fastcall TF_glav::FormClose(TObject *Sender, TCloseAction &Action)
{
  if  (F_vhod->WindowState==wsMaximized)
   {
     // SaveGrid(F_vhod->DBGrid1,F_vhod->atvh1);
      SaveGrid1(F_vhod->DBGrid1,F_vhod->Label1->Caption);

      }

  if  (F_ish->WindowState==wsMaximized)
   {
   //SaveGrid(F_ish->DBGrid1,F_ish->atih1);
   SaveGrid1(F_ish->DBGrid1,F_ish->Label1->Caption);

   }

  if  (F_razn->WindowState==wsMaximized)
   //{ SaveGrid(F_razn->DBGrid1,F_razn->atr);}
    {SaveGrid1(F_razn->DBGrid1,F_razn->Label1->Caption);
}
   DeleteFile("c_rest.mdb") ;
    Action=caFree;

}
//---------------------------------------------------------------------------


void __fastcall TF_glav::N31Click(TObject *Sender)
{
AnsiString year;
ShortDateFormat = "yyyy";
year=DateToStr(Date());
AnsiString c;
try {
  c=InputBox("�������� ������ �������� ����", "������� ���!","");
if (StrToInt(c)<=StrToInt(year))
 {
  AnsiString arh="archiv//c"+c+".mdb";

char warh[20];
StrPCopy(warh,arh);
  //ShowMessage(warh);
  //if( MessageBox("��������! ������ ����� ������ ����� �������� ����, � ��� ������� ��������. ���������?","���������",MB_YESNO)== IDYES )
  if (MessageDlg("��������! ������ ����� ������ ����� �������� ����, � ��� ������� ��������. ���������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes  )
{  if (CopyFile("cbaza.mdb",warh,true)==true)
       {ShowMessage("������������� ������ �������");
        // ������� ����� ���� ������

     if (MessageDlg("��������! ������ ���� ������ ����� �������. ���������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes  )
        { try
           {Zachistka(dm2->tarh,dm2->adq1) ;
           }
          __finally  {ShowMessage("������� ������� ���������!");}
        }
}
        else { if (MessageDlg("����� ����� ���� ��� ����������. ������������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes  )
              { DeleteFile(warh)  ;
                CopyFile("cbaza.mdb",warh,true);
                // ������� ����� ���� ������

               if (MessageDlg("��������! ������ ���� ������ ����� �������. ���������?",mtInformation, TMsgDlgButtons() << mbYes << mbNo, 0)==mrYes  )
                  {   try
                       {Zachistka(dm2->tarh,dm2->adq1) ;
                       }
                       __finally  {ShowMessage("������� ������� ���������!");
                  }
              }
             } ;
             }

 }
          /*"archiv//c2006.mdb"*/
  }

 else {ShowMessage("���� ��� ��� �� ��������");  }  //if
 }
 catch (Exception &e)
 {
   ShowMessage ("������ ����: "+e.Message+"   �������� ������������ (423)");
 }



 }
//---------------------------------------------------------------------------



void __fastcall TF_glav::N30Click(TObject *Sender)
{
String s="";
s=InputBox("�������� �������","������� ��� �� ������� ��������������� �����","");
if (FileExists("archiv\\c"+s+".mdb"))
{dm2->adc1->Connected=false;
dm2->adc1->ConnectionString="Provider=Microsoft.Jet.OLEDB.4.0;Data Source=archiv\\c"+s+".mdb;Persist Security Info=False" ;
dm2->adc1->Connected=true;

F_glav->Caption=F_glav->Caption+"�������� ������ �� "+s+" ���";
priarh=1;
N1->Visible=true;
N31->Enabled=false;}
else
        {ShowMessage("������ ��"+s+" ��� �� ����������!");
        }
 CloseOpen(1);

}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N1Click(TObject *Sender)
{
dm2->adc1->Connected=false;
dm2->adc1->ConnectionString="Provider=Microsoft.Jet.OLEDB.4.0;Data Source=cbaza.mdb;Persist Security Info=False" ;
//dm2->adc1->Connected=true;
CloseOpen(1);
F_glav->Caption="��� ��������  ��������� ���������� � ������� ������������." ;
N1->Visible=false;
N31->Enabled=true;
F_glav->Caption=Cap;

}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N3Click(TObject *Sender)
{ fd1->Font->Size=F_vhod->DBGrid1->Font->Size;
  fd1->Font->Name=F_vhod->DBGrid1->Font->Name;
if (fd1->Execute())
    { F_vhod->DBGrid1->Font->Size=fd1->Font->Size;
      F_vhod->DBGrid1->Font->Name=fd1->Font->Name;
      F_vhod->DBGrid1->Font->Style=fd1->Font->Style;
      F_ish->DBGrid1->Font->Size=fd1->Font->Size;
      F_ish->DBGrid1->Font->Name=fd1->Font->Name;
      F_ish->DBGrid1->Font->Style=fd1->Font->Style;
      F_razn->DBGrid1->Font->Size=fd1->Font->Size;
      F_razn->DBGrid1->Font->Name=fd1->Font->Name;
      F_razn->DBGrid1->Font->Style=fd1->Font->Style;
    }
}
//---------------------------------------------------------------------------
//-------------------------SAVEGRID-----------------------------------------------

void __fastcall TF_glav::N32Click(TObject *Sender)
{
//connectAR();
/* dm2->adc1->Connected=false;

   F_vhod->atvh1->Active=false;
   F_ish->atih1->Active=false;
   F_razn->atr->Active=false;
*/
CloseOpen(0);

  if (CopyFile("c_rest.mdb","cbaza.mdb",true)==true)
       {ShowMessage("�������������� ������ �������");}
   else
        {       DeleteFile("cbaza.mdb")  ;
                CopyFile("c_rest.mdb","cbaza.mdb",true);
                ShowMessage("�������������� ������ �������");
        }
  CloseOpen(1);

   N1->Visible=false;
   N31->Enabled=true;
}
//---------------------------------------------------------------------------






void TF_glav::MakeReport(TDBGrid* dbg,TADOQuery* q1)
{
       ExcelInit("",q1,dbg);


       dbg->Visible=false;
  dbg->Cursor=crHourGlass;



    for(int i=0; i < q1->FieldCount; i++)
     {
       toExcelCell(2,i+2,dbg->Columns->Items[i]->Title->Caption);

         q1->First();
         int j=4;
       while (!q1->Eof)
          {  toExcelCell(j,i+2, q1->FieldByName(dbg->Columns->Items[i]->FieldName)->AsString) ;
             j++;
             q1->Next();
          }


     }

    dbg->Visible=true;
     dbg->Cursor=crDefault;
      q1->First();


    if(!App.IsEmpty())App.OlePropertySet("Visible",true);

    // ����������� �������
    Sh.Clear();
    App.Clear();

}            

//------------------------------------------------------------------------




void __fastcall TF_glav::ExcelInit(String File,TADOQuery* q,TDBGrid* dbg)
{
  // ���� Excel ������� - ������������ � ����
  try {
        App=Variant::GetActiveObject("Excel.Application");
      }

    catch(...)
     {
     // Excel �� ������� - ��������� ���
     try { App=Variant::CreateObject("Excel.Application");
     }
     catch (...)
      {
      Application->MessageBox("���������� ������� Microsoft Excel!"
      "�������� Excel �� ���������� �� ����������.","������",MB_OK+MB_ICONERROR);
      }  }
  try {  App.OlePropertyGet("EnableEvents")=false;//OlePropertySet<P1>()
    if(File!="")
     {  App.OlePropertyGet("WorkBooks").OleProcedure("Open",File);
     }
    else
     App.OlePropertyGet("WorkBooks").OleProcedure("add");
    Sh=App.OlePropertyGet("WorkSheets",1);


     for (int j=3;j<q->FieldCount+3;j++)
   {
  Sh.OlePropertyGet("Columns").OlePropertyGet("Item",j).OlePropertySet("ColumnWidth",20/*dbg->Columns->Items[j-3]->Width*/);
   }
   // ���� �����
  /* Rang=Sh.OlePropertyGet("Range", "A3:A"+IntToStr(columncount));
    Rang.OlePropertyGet("Interior").OlePropertySet("ColorIndex",4);
  */
      } catch(...) {
    Application->MessageBox("������ �������� ����� Microsoft Excel!",
                                         "������",MB_OK+MB_ICONERROR);
  }


}
//----------------------------------------------------------------



void __fastcall TF_glav::toExcelCell(int Row,int Column, AnsiString data)
{
  try {
    Variant  cur = Sh.OlePropertyGet("Cells", Row,Column);
    cur.OlePropertySet("Value", data.c_str());

    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("HorizontalAlignment", 3); //2 -�� ������ ����
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("VerticalAlignment",1);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("WrapText", true);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("Orientation",0);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("AddIndent",false );
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("IndentLevel",0);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("ShrinkToFit",false);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("ReadingOrder","xlContext" );
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("MergeCells",false);

      } catch(...) { ; }
}



//------------------------------------------------------------------------
void __fastcall TF_glav::toExcelCell(int Row,int Column, Variant data)
{
  try {
    Variant  cur = Sh.OlePropertyGet("Cells", Row,Column);
     cur.OlePropertySet("Value", data);

    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("HorizontalAlignment", 1);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("VerticalAlignment",1);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("WrapText", true);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("Orientation",0);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("AddIndent",false );
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("IndentLevel",0);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("ShrinkToFit",false);
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("ReadingOrder","xlContext" );
    Sh.OlePropertyGet("Cells", Row,Column).OlePropertySet("MergeCells",false);
   
  } catch(...) { ; }
}

void __fastcall TF_glav:: CloseOpen(int pr)
{

switch (pr)
{case 0:
         {   dm2->adc1->Connected=false;
             F_vhod->aqvh1->Active=false;
             F_ish->aqih1->Active=false;
             F_razn->aqr->Active=false;
          }
case 1:  {   dm2->adc1->Connected=true;
             F_vhod->aqvh1->Active=true;
             F_ish->aqih1->Active=true;
             F_razn->aqr->Active=true;
         }
}

 }
void __fastcall TF_glav::N33Click(TObject *Sender)
{
Fabout->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TF_glav::N35Click(TObject *Sender)
{
F_razn->Sprint->Visible=false;
F_razn->SPWOrd->Visible=true;


 sql1="select * from rz_regkon ";
 sql2="order by ind";
connect(F_razn->aqr,sql1+sql2,"data_pr","sr_isp","data_isp","data_otveta");


F_razn->Label1->Caption=N26->Caption;

F_razn->DBGrid1->Columns->Items[0]->Title->Caption="�/�";
F_razn->DBGrid1->Columns->Items[1]->Title->Caption="�.�.�";
F_razn->DBGrid1->Columns->Items[2]->Title->Caption="�����";
F_razn->DBGrid1->Columns->Items[3]->Title->Caption="�������";
F_razn->DBGrid1->Columns->Items[4]->Title->Caption="����� ������";
F_razn->DBGrid1->Columns->Items[5]->Title->Caption="���� �����";
F_razn->DBGrid1->Columns->Items[6]->Title->Caption="��������";
F_razn->DBGrid1->Columns->Items[7]->Title->Caption="������ ���������";
F_razn->DBGrid1->Columns->Items[8]->Title->Caption="��� ������������";
F_razn->DBGrid1->Columns->Items[9]->Title->Caption="�����������";
F_razn->DBGrid1->Columns->Items[10]->Title->Caption="���� ����������";
F_razn->DBGrid1->Columns->Items[11]->Title->Caption="���� ����������";
F_razn->DBGrid1->Columns->Items[12]->Title->Caption="��������� �������";
F_razn->DBGrid1->Columns->Items[13]->Title->Caption="���� ������";
F_razn->DBGrid1->Columns->Items[14]->Title->Caption="������� � ������ � ��������";



gridvisual(F_razn->DBGrid1,15);      // ���-�� ����� Title
//F_razn->countvisible=14 ;

F_razn->DBGrid1->Columns->Items[0]->FieldName="nom" ;
F_razn->DBGrid1->Columns->Items[1]->FieldName="fio" ;
F_razn->DBGrid1->Columns->Items[2]->FieldName="adres" ;
F_razn->DBGrid1->Columns->Items[3]->FieldName="tel" ;
F_razn->DBGrid1->Columns->Items[4]->FieldName="mesto_raboty";
F_razn->DBGrid1->Columns->Items[5]->FieldName="data_pr" ;
F_razn->DBGrid1->Columns->Items[6]->FieldName="temat" ;
F_razn->DBGrid1->Columns->Items[7]->FieldName="vopobr" ;
F_razn->DBGrid1->Columns->Items[8]->FieldName="hrasm" ;
F_razn->DBGrid1->Columns->Items[9]->FieldName="isp" ;
F_razn->DBGrid1->Columns->Items[10]->FieldName="sr_isp" ;
F_razn->DBGrid1->Columns->Items[11]->FieldName="data_isp" ;
F_razn->DBGrid1->Columns->Items[12]->FieldName="rezr" ;
F_razn->DBGrid1->Columns->Items[13]->FieldName="data_otveta" ;
F_razn->DBGrid1->Columns->Items[14]->FieldName="otmsnkon" ;
F_razn->DBGrid1->Columns->Items[15]->FieldName="ind" ;



F_razn->Openrazn(F_razn->DBGrid1);

F_vhod->WindowState=wsMinimized;
F_ish->WindowState=wsMinimized;
F_razn->WindowState=wsMaximized;
}
//---------------------------------------------------------------------------

