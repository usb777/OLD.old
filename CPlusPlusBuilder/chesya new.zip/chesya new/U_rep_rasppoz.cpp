//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "u_razn1.h"
#include "U_rep_rasppoz.h"
#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_rep_rasppoz *F_rep_rasppoz;
//---------------------------------------------------------------------------
__fastcall TF_rep_rasppoz::TF_rep_rasppoz(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------







