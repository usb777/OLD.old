//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_pskvh.h"
#include "U_vhod.h"
#include "u_ishod.h"
#include "u_razn1.h"
#include "U_glav.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_psvh *F_psvh;
int gl=0;
int priznak=0;
//---------------------------------------------------------------------------
__fastcall TF_psvh::TF_psvh(TComponent* Owner)
        : TForm(Owner)
   {

}
//---------------------------------------------------------------------------
void __fastcall TF_psvh::BitBtn1Click(TObject *Sender)
{


switch (priznak)//(F_psvh->Tag)
{
case 1: {  QuickPoisk(F_vhod->aqvh1,F_vhod->DBGrid1,RadioGroup1);break;}
case 2: {  QuickPoisk(F_ish->aqih1,F_ish->DBGrid1,RadioGroup1);break;}
case 3: {  QuickPoisk(F_razn->aqr,F_razn->DBGrid1,RadioGroup1);break;}
//default: ShowMessage("Form.Tag ���� ����� �� ����� ��������!") ;
}
  Close();

}

 // Organisation of search
void __fastcall TF_psvh::QuickPoisk(TADOQuery* q,TDBGrid* grid,TRadioGroup* rg)
{

q->Open();
q->Active=true;
TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey;

 for (int i=0;i<=grid->Columns->Count-1;i++)
{if (rg->ItemIndex==i)
   { q->Locate(grid->Columns->Items[i]->FieldName,Edit1->Text,Opts);
  /*   q->Active=false;
     q->SQL->Clear();
     q->SQL->Add(F_glav->sql1+" where no="+Edit1->Text+" "+F_glav->sql2);
    ShowMessage(q->SQL->Text);
      q->Active=true;
      q->Open();
   */
    }
}

}
//---------------------------------------------------------------------------

void __fastcall TF_psvh::CreationfF(TLabel* l,TDBGrid* grid,TRadioGroup* rg,short kolfield)
{  rg->Caption="����� �� "+l->Caption;
    lp->Caption=l->Caption;
    rg->Items->Clear();
   for (int i=0;i<=kolfield/*grid->Columns->Count-1*/;i++)
   {
      rg->Items->Add("�� "+grid->Columns->Items[i]->Title->Caption);
   }
}


void __fastcall TF_psvh::FormActivate(TObject *Sender)
{
switch (F_psvh->Tag)
{
case 1: {CreationfF(F_vhod->Label1,F_vhod->DBGrid1,RadioGroup1,9);priznak=1; ;break;}   /*F_vhod->countvisible-1*/
case 2: {CreationfF(F_ish->Label1,F_ish->DBGrid1,RadioGroup1,4);priznak=2;break;}    /*F_ish->countvisible-1)*/
case 3: {CreationfF(F_razn->Label1,F_razn->DBGrid1,RadioGroup1,F_razn->countvisible);priznak=3;;break;};
//default: ShowMessage("Form.Tag ���� ����� �� ����� ��������!!!!");
}


}
//---------------------------------------------------------------------------



