//---------------------------------------------------------------------------

#ifndef U_vhodH
#define U_vhodH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <DBCtrls.hpp>
#include "Word_2K_SRVR.h"
#include <OleServer.hpp>
#include "Excel_2K_SRVR.h"
#include <Buttons.hpp>

//---------------------------------------------------------------------------
class TF_vhod : public TForm
{
__published:	// IDE-managed Components
        TDataSource *DataSource2;
        TGroupBox *GroupBox1;
        TPanel *Panel1;
        TLabel *Label1;
        TDBNavigator *DBNavigator1;
        TStatusBar *StatusBar1;
        TDBGrid *DBGrid1;
        TPanel *Panel2;
        TSpeedButton *SpeedButton1;
        TPanel *Panel3;
        TSpeedButton *SpeedButton2;
        TSpeedButton *SpeedButton3;
        TSpeedButton *SpeedButton4;
        TSpeedButton *SpeedButton5;
        TADOQuery *aqvh1;

        void __fastcall FormCreate(TObject *Sender);

        void __fastcall DBGrid1Exit(TObject *Sender);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall DBGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall DBGrid1EditButtonClick(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall SpeedButton3Click(TObject *Sender);
        void __fastcall SpeedButton4Click(TObject *Sender);
        void __fastcall SpeedButton5Click(TObject *Sender);

     private:          	// User declarations
             



public:		// User declarations
        __fastcall TF_vhod(TComponent* Owner);
        void __fastcall TF_vhod::Exp2Excel();
        void __fastcall OpenVhod(TDBGrid* tdb);
         int countvisible ;


};
//---------------------------------------------------------------------------
extern PACKAGE TF_vhod *F_vhod;
//---------------------------------------------------------------------------


#endif
/*
class forma : public TF_main
{
   void __fastcall connect1(TADOTable* a, char s[10],TF_main* f) ;

}

*/
