//---------------------------------------------------------------------------

#ifndef UfuncH
#define UfuncH
#include <Inifiles.hpp>
#include <DBGrids.hpp>

//---------------------------------------------------------------------------

void __fastcall SaveINI(TDBGrid* tdb);
void __fastcall OpenINI(TDBGrid* tdb) ;
       

#endif
