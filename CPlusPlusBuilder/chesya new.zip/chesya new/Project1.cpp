//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("U_glav.cpp", F_glav);
USEFORM("Unit2.cpp", dm2); /* TDataModule: File Type */
USEFORM("u_razn1.cpp", F_razn);
USEFORM("u_ishod.cpp", F_ish);
USEFORM("U_vhod.cpp", F_vhod);
USEFORM("U_pskvh.cpp", F_psvh);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TF_glav), &F_glav);
                 Application->CreateForm(__classid(Tdm2), &dm2);
                 Application->CreateForm(__classid(TF_razn), &F_razn);
                 Application->CreateForm(__classid(TF_ish), &F_ish);
                 Application->CreateForm(__classid(TF_vhod), &F_vhod);
                 Application->CreateForm(__classid(TF_psvh), &F_psvh);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
