//---------------------------------------------------------------------------

#ifndef U_rep_komH
#define U_rep_komH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <QRCtrls.hpp>
#include <QuickRpt.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------
class TF_rep_kom : public TForm
{
__published:	// IDE-managed Components
        TQuickRep *QuickRep1;
        TDataSource *DataSource1;
        TQRBand *QRBand1;
        TQRLabel *QRLabel5;
        TQRShape *QRShape3;
        TQRLabel *QRLabel1;
        TQRShape *QRShape4;
        TQRLabel *QRLabel3;
        TQRLabel *QRLabel2;
        TQRLabel *QRLabel4;
        TQRShape *QRShape6;
        TQRShape *QRShape8;
        TQRExpr *QRExpr1;
        TQRSubDetail *QRSubDetail1;
        TQRShape *QRShape5;
        TQRShape *QRShape1;
        TQRShape *QRShape7;
        TQRShape *QRShape2;
        TADOTable *ADOTable1;
        TQRExpr *QRExpr2;
        TQRExpr *QRExpr3;
        TQRExpr *QRExpr4;
        TQRExpr *QRExpr5;
        TQRLabel *QRLabel6;
        TQRExpr *QRExpr6;
        TQRLabel *QRLabel7;
        TQRExpr *QRExpr7;
        TQRExpr *QRExpr8;
        TQRLabel *QRLabel8;
        TQRLabel *QRLabel9;
        TAutoIncField *ADOTable1ind;
        TWideStringField *ADOTable1no;
        TDateTimeField *ADOTable1date;
        TWideStringField *ADOTable1fio;
        TWideStringField *ADOTable1dol;
        TWideStringField *ADOTable1gorod;
        TDateTimeField *ADOTable1nk;
        TDateTimeField *ADOTable1kk;
        TWideStringField *ADOTable1prim;
        TWideStringField *ADOTable1podpis;
        TQRShape *QRShape9;
        TQRShape *QRShape10;
        TQRShape *QRShape11;
        TQRShape *QRShape12;
        TQRShape *QRShape13;
        TQRShape *QRShape14;
        TQRShape *QRShape15;
        TQRShape *QRShape16;
        TQRExpr *QRExpr9;
private:	// User declarations
public:		// User declarations
        __fastcall TF_rep_kom(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_rep_kom *F_rep_kom;
//---------------------------------------------------------------------------
#endif
