//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Unit2.h"
#include "u_ishod.h"
#include "ufunc.h"
#include "U_pskvh.h"
#include "U_glav.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_ish *F_ish;
//---------------------------------------------------------------------------
__fastcall TF_ish::TF_ish(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TF_ish::FormCreate(TObject *Sender)
{ OpenIsh(DBGrid1);
for (int i=1;i<=12;i++)
 { StatusBar1->Panels->Items[i-1]->Text="F"+IntToStr(i);
 }
 StatusBar1->Panels->Items[3]->Text=StatusBar1->Panels->Items[3]->Text+" �����";
StatusBar1->Panels->Items[1]->Text=StatusBar1->Panels->Items[1]->Text+" ������";
}
//---------------------------------------------------------------------------

void __fastcall TF_ish::DBGrid1KeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{

 if (Key==VK_F2)
        { F_glav->MakeReport(DBGrid1,aqih1);
          //ShowMessage(DBGrid1->Columns->Count);
        }
 if (Key==VK_F4)
 { F_psvh->Tag=2;
   F_psvh->ShowModal();
  }

 if (Key==13)
 {  //ShowMessage("�� ������ �nter");
    aqih1->Edit();
    aqih1->Post();
  }

}
//---------------------------------------------------------------------------

void __fastcall TF_ish::FormActivate(TObject *Sender)
{
countvisible=DBGrid1->FieldCount;
}
//---------------------------------------------------------------------------



void __fastcall TF_ish::OpenIsh(TDBGrid* tdb)
{
   TIniFile *ini;
   ini = new TIniFile(ChangeFileExt( Application->ExeName, ".INI" ) );

tdb->Font->Size= ini->ReadInteger("Options Grid", tdb->Name+" font-size",10);
tdb->Font->Name=ini->ReadString("Options Grid", tdb->Name+" font-name","Times New Roman");

for (int j=0;j<=4;j++)
         {tdb->Columns->Items[j]->Width=ini->ReadInteger( "TableIshod_"+Label1->Caption, "Col"+IntToStr(j)+"Width",128 );
         }

   delete ini;

 }

void __fastcall TF_ish::DBGrid1KeyPress(TObject *Sender, char &Key)
{
 /*if (Key=='#13')
    { Key='#0';
      SelectNext(ActiveControl,true,true) ;
     }
  */
 }
//---------------------------------------------------------------------------

//F_glav->MakeReport(DBGrid1,atih1);
void __fastcall TF_ish::SpeedButton2Click(TObject *Sender)
{
  F_glav->MakeReport(DBGrid1,aqih1);
}
//---------------------------------------------------------------------------

void __fastcall TF_ish::SpeedButton1Click(TObject *Sender)
{
aqih1->First();
}
//---------------------------------------------------------------------------

void __fastcall TF_ish::SpeedButton3Click(TObject *Sender)
{
aqih1->Prior();
}
//---------------------------------------------------------------------------

void __fastcall TF_ish::SpeedButton4Click(TObject *Sender)
{
aqih1->Next();
}
//---------------------------------------------------------------------------

void __fastcall TF_ish::SpeedButton5Click(TObject *Sender)
{
aqih1->Last();        
}
//---------------------------------------------------------------------------

