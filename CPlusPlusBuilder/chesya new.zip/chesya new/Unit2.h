//---------------------------------------------------------------------------

#ifndef Unit2H
#define Unit2H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------
class Tdm2 : public TDataModule
{
__published:	// IDE-managed Components
        TADOConnection *adc1;
        TADOQuery *adq1;
        TADOTable *tarh;
        void __fastcall DataModuleCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall Tdm2(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tdm2 *dm2;
//---------------------------------------------------------------------------
#endif
