//---------------------------------------------------------------------------

#ifndef U_pskvhH
#define U_pskvhH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
#include <DBGrids.hpp>
//---------------------------------------------------------------------------
class TF_psvh : public TForm
{
__published:	// IDE-managed Components
        TEdit *Edit1;
        TLabel *lp;
        TBitBtn *BitBtn1;
        TRadioGroup *RadioGroup1;
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall FormActivate(TObject *Sender);

private:	// User declarations
public:		// User declarations
      
        __fastcall TF_psvh(TComponent* Owner);
        void __fastcall QuickPoisk(TADOQuery* q,TDBGrid* grid,TRadioGroup* rg);
        void __fastcall CreationfF(TLabel* l,TDBGrid* grid,TRadioGroup* rg,short kolfield);


};
//---------------------------------------------------------------------------
extern PACKAGE TF_psvh *F_psvh;
//---------------------------------------------------------------------------
#endif
