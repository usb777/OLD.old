//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
Tdm2 *dm2;
//---------------------------------------------------------------------------
__fastcall Tdm2::Tdm2(TComponent* Owner)
        : TDataModule(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall Tdm2::DataModuleCreate(TObject *Sender)
{         //  adc1->DataSets->DeleteRecords();
//  ShowMessage();

}
//---------------------------------------------------------------------------

