//---------------------------------------------------------------------------

#ifndef U_repH
#define U_repH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <QRCtrls.hpp>
#include <QuickRpt.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------
class TF_rep : public TForm
{
__published:	// IDE-managed Components
        TQuickRep *QuickRep1;
        TDataSource *DataSource1;
        TQRBand *QRBand1;
        TQRLabel *QRLabel5;
        TQRShape *QRShape3;
        TQRLabel *QRLabel1;
        TQRShape *QRShape4;
        TQRLabel *QRLabel3;
        TQRLabel *QRLabel2;
        TQRLabel *QRLabel4;
        TQRShape *QRShape6;
        TQRShape *QRShape8;
        TQRExpr *QRExpr1;
        TQRSubDetail *QRSubDetail1;
        TQRShape *QRShape5;
        TQRShape *QRShape1;
        TQRShape *QRShape7;
        TQRShape *QRShape2;
        TADOTable *ADOTable1;
        TQRExpr *QRExpr2;
        TQRExpr *QRExpr3;
        TQRExpr *QRExpr4;
        TQRExpr *QRExpr5;
private:	// User declarations
public:		// User declarations
        __fastcall TF_rep(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_rep *F_rep;
//---------------------------------------------------------------------------
#endif
