//---------------------------------------------------------------------------

#ifndef UglH
#define UglH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TF_gl : public TForm
{
__published:	// IDE-managed Components
        TMainMenu *MainMenu1;
        TMenuItem *N5;
        TMenuItem *N7;
        TMenuItem *N6;
        TMenuItem *N8;
        TMenuItem *N9;
        TMenuItem *N10;
        TMenuItem *N11;
        TMenuItem *N12;
        TMenuItem *N13;
        TMenuItem *N14;
        TMenuItem *N15;
        TMenuItem *N16;
        TMenuItem *N17;
        TMenuItem *N18;
        TMenuItem *N19;
        TMenuItem *N20;
        TMenuItem *N21;
        TMenuItem *N22;
        TMenuItem *N23;
        TMenuItem *N24;
        TMenuItem *N25;
        TMenuItem *N26;
        TMenuItem *N27;
        TMenuItem *N28;
        TMenuItem *N30;
        TMenuItem *N31;
        TMenuItem *N29;
        TMenuItem *N32;
private:	// User declarations
public:		// User declarations
        __fastcall TF_gl(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_gl *F_gl;
//---------------------------------------------------------------------------
#endif
