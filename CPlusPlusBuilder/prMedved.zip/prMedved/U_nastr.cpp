//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_nastr.h"
#include "U_gl.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_nastr *F_nastr;
TCheckBox *chb[20];

//---------------------------------------------------------------------------
__fastcall TF_nastr::TF_nastr(TComponent* Owner)
        : TForm(Owner)
{
//CheckBox8->Caption="janvar";
chb[1]=CheckBox1;
chb[2]=CheckBox2;
chb[3]=CheckBox3;
chb[4]=CheckBox4;
chb[5]=CheckBox5;
chb[6]=CheckBox6;
chb[7]=CheckBox7;
chb[8]=CheckBox8;
chb[9]=CheckBox9;
chb[10]=CheckBox10;
chb[11]=CheckBox11;
chb[12]=CheckBox12;
chb[13]=CheckBox13;
chb[14]=CheckBox14;
chb[15]=CheckBox15;
chb[16]=CheckBox16;
chb[17]=CheckBox17;
chb[18]=CheckBox18;
chb[19]=CheckBox19;
}
//---------------------------------------------------------------------------

void __fastcall TF_nastr::BitBtn1Click(TObject *Sender)
{



for (int i=1; i<=19;i++)
{
if (chb[i]->Checked==true)
   {F_gl->DBGrid1->Columns->Items[i]->Visible=false;}
 else
   {F_gl->DBGrid1->Columns->Items[i]->Visible=true;}
}

 Close();
}
//---------------------------------------------------------------------------

void __fastcall  TF_nastr::nSaveIni()
{  TIniFile *ini;
   ini = new TIniFile(ChangeFileExt( Application->ExeName, ".INI" ));
 for (int i=1;i<=19;i++)
   {ini->WriteInteger("Options NCheckBox", chb[i]->Name+" checked",chb[i]->Checked);
   }

}

//---------------------------------------------------------------------------
void __fastcall  TF_nastr::nOpenIni()
{
   TIniFile *ini;
   ini = new TIniFile(ChangeFileExt( Application->ExeName, ".INI" ) );

 for (int i=1;i<=19;i++)
{
 chb[i]->Checked= ini->ReadInteger("Options NCheckBox", chb[i]->Name+" checked",false);
}

}
void __fastcall TF_nastr::FormClose(TObject *Sender, TCloseAction &Action)
{
  // nSaveIni();
}
//---------------------------------------------------------------------------

void __fastcall TF_nastr::FormCreate(TObject *Sender)
{
nOpenIni();
//
}
//---------------------------------------------------------------------------

void __fastcall TF_nastr::BitBtn3Click(TObject *Sender)
{
for (int i=1; i<=19;i++)
  {
    chb[i]->Checked=true;
   }
}
//---------------------------------------------------------------------------

void __fastcall TF_nastr::BitBtn2Click(TObject *Sender)
{
for (int i=1; i<=19;i++)
  {
    chb[i]->Checked=false;
   }

}
//---------------------------------------------------------------------------


