//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "U_poisk.h"
#include "U_dm.h"
#include "U_gl.h"
#include "U_rpoisk.h"

#include "CL_MY_DBWork.h"

//#include "U_rspoisk.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_poisk *F_poisk;
//---------------------------------------------------------------------------
__fastcall TF_poisk::TF_poisk(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
 /*
void __fastcall TF_poisk::Poisk(TIBTable* t,TDBGrid* grid,TRadioGroup* rg)
{
t->Open();
t->Active=true;
TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey;

 for (int i=0; i<=grid->Columns->Count-1; i++)
  {if (rg->ItemIndex==i)
    { t->Locate(grid->Columns->Items[i]->FieldName,Edit1->Text,Opts);
    }
  }

}
 */
void __fastcall TF_poisk::BitBtn1Click(TObject *Sender)
{

short kritp=0;

//Dm->IBQosm->Open();
//Dm->IBQosm->Active=true;
//TLocateOptions Opts;
//Opts.Clear();

 if ((RB1->Checked==true)&&(RB2->Checked==false))
  {
    kritp=RG1->ItemIndex;
    String param;

switch (kritp)
{
case 0:
        {

      /*    TADOQuery *q = DM1->Quchot;
          TADOQuery *q1 = DM1->Qnaim;
                 TLocateOptions Opts;
                 Opts.Clear();
                 Opts << loPartialKey	;
                 q1->Locate("naim_name",Edit1->Text,Opts);
                 MY_DBWork* wdb =new MY_DBWork;
                 wdb->ZaprosNaVyborkui(q,"uchot","naim_kod",q1->FieldByName("naim_kod")->AsInteger,"uchot_N");
        */
      TADOQuery *q = DM1->Quchot;
      MY_DBWork* wdb =new MY_DBWork;
      wdb->ZaprosNaVyborku(q,"uchot","naim_name",Edit1->Text,"uchot_ind");

                 break ;

        }
case 1:
        {
      ShowMessage("����� �� ������� ����");
      TADOQuery *q = DM1->Quchot;
      MY_DBWork* wdb =new MY_DBWork;
      wdb->ZaprosNaVyborku(q,"uchot","uchot_cena",StrToFloat(Edit1->Text),"uchot_ind");


  //        param="uchot_cena";
    //      PPoisk(param,StrToFloat(Edit1->Text));
          break;
        }
case 2:
           {
         /*   ShowMessage("����� �� ����������");
         param="f_name";
         PPoisk(param,Edit1->Text);
         */
          ShowMessage("����� �� ����������");
         TADOQuery *q = DM1->Quchot;
         TADOQuery *q1 = DM1->Qpost;
         TLocateOptions Opts;
         Opts.Clear();
         Opts << loPartialKey	;
         q1->Locate("post_name",Edit1->Text,Opts);
         MY_DBWork* wdb =new MY_DBWork;
         wdb->ZaprosNaVyborkui(q,"uchot","post_kod",q1->FieldByName("post_kod")->AsInteger,"uchot_ind");

          break;

           }

case 3:   {
             ShowMessage("����� �� c������� ������� �� �����");
             TADOQuery *q = DM1->Quchot;
             MY_DBWork* wdb =new MY_DBWork;
             wdb->ZaprosNaVyborku(q,"uchot","uchot_sredm",StrToFloat(Edit1->Text),"uchot_ind");
             break;

          }


}

  goto m1;
  }


 if ((RB2->Checked==true)&&(RB1->Checked==false))
  {


   kritp=RG1->ItemIndex;
    String param;

 switch (kritp)
 {
case 0:
        {
         //KosvPoiskPoVhoj(DM1->Qnaim,"naim","naim_kod","naim_name",Edit1->Text);
         TADOQuery *q = DM1->Quchot;
         MY_DBWork* wdb =new MY_DBWork;
         wdb->ZVyborkaVhoj(q,"uchot","naim_name",(Edit1->Text),"uchot_ind");
                 break ;
         }
case 1:
        {
      ShowMessage("����� �� ������� ����");
      TADOQuery *q = DM1->Quchot;
      MY_DBWork* wdb =new MY_DBWork;
      wdb->ZVyborkaVhoj(q,"uchot","uchot_cena",(Edit1->Text),"uchot_ind");

          break;
        }
case 2:
        {

          KosvPoiskPoVhoj(DM1->Qpost,"postman","post_kod","post_name",Edit1->Text);
          break;

        }

case 3:  {

             ShowMessage("����� �� c������� ������� �� �����");
             TADOQuery *q = DM1->Quchot;
             MY_DBWork* wdb =new MY_DBWork;
             wdb->ZVyborkaVhoj(q,"uchot","uchot_sredm",Edit1->Text,"uchot_ind");
             break;
         }

}// switch

  }       //if rb
m1:
  Close();

}
//---------------------------------------------------------------------------


void __fastcall TF_poisk::KosvPoiskPoVhoj(TADOQuery* q,String knameTable,String kkod,String kfield,String param)
{
int z[5000];
int i=0;

q->Close();
q->SQL->Clear();
//q->SQL->Add("select * from naim where naim_name like '%��%'");

q->SQL->Add("select * from "+knameTable+" where "+kfield+" like '%"+param+"%'");


q->Open();

   q->First();
while (!q->Eof)
  {
   z[i]=q->FieldByName(kkod)->AsInteger;
   i++;
   q->Next();
  }
String c=" "+kkod+"=";
String cc=" ";
for (int j=0;j<i;j++)
 {
    cc=cc+c+IntToStr(z[j])+" or"   ;
 }

int len=cc.Length();
cc.SetLength(len-2);
ShowMessage(cc);

 String query="select * from uchot where "+cc+" order by naim_kod" ;

 //ShowMessage(query);

TADOQuery *q1=DM1->Quchot;
q1->Close();
q1->SQL->Clear();
q1->SQL->Add(query);
q1->Open();
q1->Last();



}



void __fastcall TF_poisk::RadioButton1Click(TObject *Sender)
{
   Close();
   F_rpoisk->Caption="����������� ����� �� ����";
   F_rpoisk->ShowModal();



   }
//---------------------------------------------------------------------------

void __fastcall TF_poisk::FormActivate(TObject *Sender)
{
RadioButton1->Checked=false;
RadioButton2->Checked=false;

RB1->Checked=true;
RB2->Checked=false;
}
//---------------------------------------------------------------------------

void __fastcall TF_poisk::RB2Click(TObject *Sender)
{
if (RB2->Checked==true)
 {RB1->Checked=false;}

}
//---------------------------------------------------------------------------


void __fastcall TF_poisk::Edit1KeyPress(TObject *Sender, char &Key)
{
int kritp=RG1->ItemIndex;
 if  ((kritp==1)||(kritp==3))
      {
       if ((Key >= '0') && (Key <= '9')) {}
else if (Key == 8) {}  // <-
else if ((Key == '.') || (Key == ','))
        {
        if (((TEdit*)Sender)->Text.Pos(DecimalSeparator)!=0) // ???? ??????? ??? ????
                Key = 0;
        else
                Key = DecimalSeparator;
        }
          else
           {ShowMessage("��� ������ �� ���� �������� ������ �������� ��������!");
            Key = 0;

            }
      }
}
//---------------------------------------------------------------------------


void __fastcall TF_poisk::RG1Click(TObject *Sender)
{
 short kritp=0;
    kritp=RG1->ItemIndex;


switch (kritp)
{
case 0: {  RadioButton1->Visible=false;
           RadioButton2->Visible=false;
           break;
        }
case 1: {  RadioButton1->Visible=true;
           RadioButton2->Visible=false;

           break;
        }
case 2: {  RadioButton1->Visible=false;
           RadioButton2->Visible=false;

           break;
        }
case 3: {  RadioButton1->Visible=false;
           RadioButton2->Visible=true;

           break;
        }


}


}
//---------------------------------------------------------------------------

void __fastcall TF_poisk::SpeedButton5Click(TObject *Sender)
{
//Application->HelpContext(13) ;
}
//---------------------------------------------------------------------------


void __fastcall TF_poisk::RadioButton2Click(TObject *Sender)
{
   Close();
   F_rpoisk->Caption="����������� ����� �� �������� ������� � �����";
   F_rpoisk->ShowModal();

}
//---------------------------------------------------------------------------

