//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_spr_naim.h"
#include "U_dm.h"
#include "CL_MY_DBWork.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_naim *F_naim;
const String gl_fquery="select * from naim  order by naim_name";

//---------------------------------------------------------------------------
__fastcall TF_naim::TF_naim(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TF_naim::DBGrid1KeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{

TADOQuery *t = DM1->Qqnaim;
TADOQuery *q = DM1->Qnaim;



switch (Key)
{
case 13:  {     q->Edit();
                q->Post();
                q->Refresh();
                //q->Last();

                break;
          }
case 40:
           {
                int ln;

              t->Close();
              t->Open();


              TLocateOptions Opts;
              Opts.Clear();
              Opts << loPartialKey	;

              t->Locate("naim_kod",lns,Opts);


              ln=t->FieldByName("naim_kod")->AsInteger;

             if (q->FieldByName("naim_kod")->AsInteger==ln)
            {    q->Insert();
                 q->FieldByName("type_kod")->AsInteger=1;
                 q->Post();

                lns=q->FieldByName("naim_kod")->AsInteger;

                 q->Refresh();
                 q->Prior();
            }

                break;
          }
case 27: {Close(); break;}

}





}
//---------------------------------------------------------------------------

void __fastcall TF_naim::FormActivate(TObject *Sender)
{
DBGrid1->Visible=false;
MY_DBWork* wdb1 =new MY_DBWork;

wdb1->ComboFulling(DM1->Qnaim,CBnaim,"naim_name");
wdb1->ComboFulling(DM1->TType,CBtype,"type_name");

DM1->Qnaim->Close();
DM1->Qnaim->SQL->Clear();
DM1->Qnaim->SQL->Add(gl_fquery);
DM1->Qnaim->Open();

DM1->Qnaim->Last();
lns=DM1->Qnaim->FieldByName("naim_kod")->AsInteger;

DM1->Qnaim->First();

DBGrid1->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_naim::N4Click(TObject *Sender)
{
DM1->Qnaim->Close();
DM1->Qnaim->SQL->Clear();
DM1->Qnaim->SQL->Add("select * from naim order by naim_name");
DM1->Qnaim->Open();
DM1->Qnaim->Last();
lns=DM1->Qnaim->FieldByName("naim_kod")->AsInteger;
}
//---------------------------------------------------------------------------

void __fastcall TF_naim::N5Click(TObject *Sender)
{

DM1->Qnaim->Close();
DM1->Qnaim->SQL->Clear();
DM1->Qnaim->SQL->Add("select * from naim order by type_kod");
DM1->Qnaim->Open();
DM1->Qnaim->Last();
lns=DM1->Qnaim->FieldByName("naim_kod")->AsInteger;

}
//---------------------------------------------------------------------------

void __fastcall TF_naim::SpeedButton1Click(TObject *Sender)
{
TADOQuery *q = DM1->Qnaim;
q->Close();
q->SQL->Clear();
q->SQL->Text=gl_fquery;//"select * from naim order by naim_name";
q->Open();
q->Last();
lns=DM1->Qnaim->FieldByName("naim_kod")->AsInteger;

}
//---------------------------------------------------------------------------

void __fastcall TF_naim::CBnaimChange(TObject *Sender)
{
TADOQuery *q = DM1->Qnaim;
MY_DBWork* wdb =new MY_DBWork;
wdb->ZaprosNaVyborku(q,"naim","naim_name",CBnaim->Text,"naim_name");

lns=q->FieldByName("naim_kod")->AsInteger;



}
//---------------------------------------------------------------------------

void __fastcall TF_naim::CBtypeChange(TObject *Sender)
{
TADOQuery *q1 = DM1->Qnaim;
TADOQuery *q2 = DM1->Qtype;

TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
q2->Locate("type_name",CBtype->Text,Opts);


MY_DBWork* wdb =new MY_DBWork;
wdb->ZaprosNaVyborkui(q1,"naim","type_kod",q2->FieldByName("type_kod")->AsInteger,"naim_name");

lns=q1->FieldByName("naim_kod")->AsInteger;  // ������� �� ��������� �����

//ShowMessage("��������� �����="+IntToStr(lns));

}
//---------------------------------------------------------------------------

void __fastcall TF_naim::SpeedButton2Click(TObject *Sender)
{
int z[5000];
int i=0;
TADOQuery *q1 = DM1->Qnaim;
q1->Close();
q1->SQL->Clear();
q1->SQL->Add("select * from naim where naim_name like '%��%'");
q1->Open();
   q1->First();
while (!q1->Eof)
  {
   z[i]=q1->FieldByName("naim_kod")->AsInteger;
   i++;
   q1->Next();
  }
String c="or i=";
String cc=" ";
for (int j=0;j<i;j++)
 {
    cc=cc+c+IntToStr(z[j])+" "   ;
 }
   ShowMessage(cc);

}
//---------------------------------------------------------------------------

void __fastcall TF_naim::FormClose(TObject *Sender, TCloseAction &Action)
{
F_naim->BtnSelect->Visible=false;        
}
//---------------------------------------------------------------------------

void __fastcall TF_naim::BtnSelectClick(TObject *Sender)
{
TADOQuery *q = DM1->Quchot;
TADOQuery *q1 = DM1->Qnaim;
q->Edit();
q->FieldByName("naim_name")->AsString=q1->FieldByName("naim_name")->AsString;
q->FieldByName("type_kod")->AsInteger=q1->FieldByName("type_kod")->AsInteger;

q->Post();
Close();


}
//---------------------------------------------------------------------------


void __fastcall TF_naim::CBnaimKeyPress(TObject *Sender, char &Key)
{
TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
DM1->Qnaim->Locate("naim_name",CBnaim->Text,Opts);
}
//---------------------------------------------------------------------------

