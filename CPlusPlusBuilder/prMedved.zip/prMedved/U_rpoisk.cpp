//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_rpoisk.h"
#include "U_poisk.h"
#include "U_dm.h"
#include "U_gl.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_rpoisk *F_rpoisk;
//---------------------------------------------------------------------------
__fastcall TF_rpoisk::TF_rpoisk(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TF_rpoisk::BitBtn1Click(TObject *Sender)
{
int var1=0;
int var2=0;

if ((Edit1->Text=="") ||(Edit2->Text==""))
{ ShowMessage("��������� ������� ��������!!!");
  goto m1;
}
else
{


 var1=StrToInt(Edit1->Text);
 var2=StrToInt(Edit2->Text);

 if (var1>var2)
      {  ShowMessage("����������� �������� ������ �������������, ������� ��� ���!!!");
         goto m1;
      }


      if ( F_rpoisk->Caption=="����������� ����� �� ����")

         { TADOQuery *q = DM1->Quchot;
          q->Close();
          q->SQL->Clear();
  q->SQL->Text="select * from uchot where (uchot_cena>="+Edit1->Text+") And (uchot_cena<="+Edit2->Text+")  order by uchot_N ";
          q->Open();
          q->Last();
         }

     if (F_rpoisk->Caption=="����������� ����� �� �������� ������� � �����")

         {
         ShowMessage("����������� ����� �� �������� ������� � �����");
         TADOQuery *q = DM1->Quchot;
         q->Close();
         q->SQL->Clear();
  q->SQL->Text="select * from uchot where (uchot_sredm>="+Edit1->Text+") And (uchot_sredm<="+Edit2->Text+")  order by uchot_N ";
         q->Open();
         q->Last();
         }


}



m1:
        Edit1->Clear();
        Edit2->Clear();

 Close();
}
//---------------------------------------------------------------------------
void __fastcall TF_rpoisk::FormClose(TObject *Sender, TCloseAction &Action)
{
// F_poisk->RadioButton1->Checked=false;

}
//---------------------------------------------------------------------------

void __fastcall TF_rpoisk::FormCloseQuery(TObject *Sender, bool &CanClose)
{
// F_poisk->RadioButton1->Checked=false;
        
}
//---------------------------------------------------------------------------

void __fastcall TF_rpoisk::Edit1KeyPress(TObject *Sender, char &Key)
{
if ((Key >= '0') && (Key <= '9')) {}  // ?????
else if (Key == 8) {}  // <-
else if ((Key == '.') || (Key == ',')) // ???????
        {
        if (((TEdit*)Sender)->Text.Pos(DecimalSeparator)!=0) // ???? ??????? ??? ????
                Key = 0;
        else // ???? ??? ???
                Key = DecimalSeparator;
        }
else Key = 0; // ?? ?????
        
}
//---------------------------------------------------------------------------


void __fastcall TF_rpoisk::Edit2KeyPress(TObject *Sender, char &Key)
{

if ((Key >= '0') && (Key <= '9')) {}  // ?????
else if (Key == 8) {}  // <-
else if ((Key == '.') || (Key == ',')) // ???????
        {
        if (((TEdit*)Sender)->Text.Pos(DecimalSeparator)!=0) // ???? ??????? ??? ????
                Key = 0;
        else // ???? ??? ???
                Key = DecimalSeparator;
        }
else Key = 0; // ?? ?????        
}
//---------------------------------------------------------------------------

void __fastcall TF_rpoisk::SpeedButton5Click(TObject *Sender)
{
//Application->HelpContext(13) ;
}
//---------------------------------------------------------------------------

