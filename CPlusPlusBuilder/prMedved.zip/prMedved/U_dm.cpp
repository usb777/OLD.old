//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_dm.h"
#include "U_gl.h"
#include "U_spr_naim.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDM1 *DM1;
//---------------------------------------------------------------------------
__fastcall TDM1::TDM1(TComponent* Owner)
        : TDataModule(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDM1::QuchotAfterDelete(TDataSet *DataSet)
{
Quchot->Last();
F_gl->ln=Quchot->FieldByName("uchot_N")->AsInteger;  // ������� �� ��������� �����

}
//---------------------------------------------------------------------------

void __fastcall TDM1::QnaimAfterDelete(TDataSet *DataSet)
{
Qnaim->Last();
F_naim->lns=Qnaim->FieldByName("naim_kod")->AsInteger;
}
//---------------------------------------------------------------------------


void __fastcall TDM1::QuchotAfterPost(TDataSet *DataSet)
{


int pos=DM1->Quchot->FieldByName("uchot_N")->AsInteger;


// ShowMessage("������� � �������");
TADOQuery *q =Quchot;

q->Close();
q->SQL->Clear();
q->SQL->Text="select * from uchot order by uchot_iNd"; //
q->Open();
q->Last();

F_gl->ln=q->FieldByName("uchot_N")->AsInteger;

TLocateOptions Opts;
Opts.Clear();
Opts << loPartialKey	;
q->Locate("uchot_n",pos,Opts);

//F_gl->DBNavigator1->VisibleButtons = TButtonSet() << nbFirst << nbPrior << nbNext << nbLast <<nbInsert <<nbDelete <<nbEdit <<nbPost <<nbCancel <<nbRefresh;



}
//---------------------------------------------------------------------------

