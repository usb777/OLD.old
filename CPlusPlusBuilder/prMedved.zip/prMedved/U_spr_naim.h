//---------------------------------------------------------------------------

#ifndef U_spr_naimH
#define U_spr_naimH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <Graphics.hpp>
#include <Menus.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TF_naim : public TForm
{
__published:	// IDE-managed Components
        TStatusBar *StatusBar1;
        TPanel *Panel1;
        TPanel *Panel2;
        TDBGrid *DBGrid1;
        TImage *Image1;
        TDBNavigator *DBNavigator1;
        TMainMenu *MainMenu1;
        TMenuItem *N1;
        TMenuItem *N2;
        TMenuItem *N3;
        TMenuItem *N4;
        TMenuItem *N5;
        TPanel *Panel3;
        TComboBox *CBnaim;
        TComboBox *CBtype;
        TLabel *Label1;
        TLabel *Label4;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton2;
        TBitBtn *BtnSelect;
        void __fastcall DBGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall N4Click(TObject *Sender);
        void __fastcall N5Click(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall CBnaimChange(TObject *Sender);
        void __fastcall CBtypeChange(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall BtnSelectClick(TObject *Sender);
        void __fastcall CBnaimKeyPress(TObject *Sender, char &Key);
private:	// User declarations

public:		// User declarations
        __fastcall TF_naim(TComponent* Owner);
             int lns;
};
//---------------------------------------------------------------------------
extern PACKAGE TF_naim *F_naim;
//---------------------------------------------------------------------------
#endif
