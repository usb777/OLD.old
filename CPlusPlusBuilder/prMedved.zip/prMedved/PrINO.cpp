//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

//---------------------------------------------------------------------------
USEFORM("U_gl.cpp", F_gl);
USEFORM("U_dm.cpp", DM1); /* TDataModule: File Type */
USEFORM("U_spr_naim.cpp", F_naim);
USEFORM("U_spr_type.cpp", F_type);
USEFORM("U_spr_post.cpp", F_post);
USEFORM("U_poisk.cpp", F_poisk);
USEFORM("U_rpoisk.cpp", F_rpoisk);
USEFORM("U_rep.cpp", F_QRep);
USEFORM("U_selectMounth.cpp", F_sm);
USEFORM("U_nastr.cpp", F_nastr);
USEFORM("Uabout.cpp", Fabout);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TF_gl), &F_gl);
                 Application->CreateForm(__classid(TDM1), &DM1);
                 Application->CreateForm(__classid(TF_naim), &F_naim);
                 Application->CreateForm(__classid(TF_type), &F_type);
                 Application->CreateForm(__classid(TF_post), &F_post);
                 Application->CreateForm(__classid(TF_poisk), &F_poisk);
                 Application->CreateForm(__classid(TF_rpoisk), &F_rpoisk);
                 Application->CreateForm(__classid(TF_QRep), &F_QRep);
                 Application->CreateForm(__classid(TF_sm), &F_sm);
                 Application->CreateForm(__classid(TF_nastr), &F_nastr);
                 Application->CreateForm(__classid(TFabout), &Fabout);
                 Application->Run();


        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
