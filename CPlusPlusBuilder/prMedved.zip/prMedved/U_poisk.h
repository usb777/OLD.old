//---------------------------------------------------------------------------

#ifndef U_poiskH
#define U_poiskH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <DBCtrls.hpp>
#include <ADODB.hpp>
#include <DB.hpp>


//---------------------------------------------------------------------------
class TF_poisk : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TRadioButton *RB1;
        TRadioButton *RB2;
        TSpeedButton *SpeedButton5;
        TRadioGroup *RG1;
        TLabel *Label1;
        TEdit *Edit1;
        TBitBtn *BitBtn1;
        TRadioButton *RadioButton1;
        TImage *Image1;
        TRadioButton *RadioButton2;
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall RadioButton1Click(TObject *Sender);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall RB2Click(TObject *Sender);
        void __fastcall Edit1KeyPress(TObject *Sender, char &Key);
        void __fastcall RG1Click(TObject *Sender);
        void __fastcall SpeedButton5Click(TObject *Sender);
        void __fastcall RadioButton2Click(TObject *Sender);
private:	// User declarations

public:		// User declarations
        __fastcall TF_poisk(TComponent* Owner);
void __fastcall KosvPoiskPoVhoj(TADOQuery* q, String knameTable,String kkod, String kfield, String param);

      

};
//---------------------------------------------------------------------------
extern PACKAGE TF_poisk *F_poisk;
//---------------------------------------------------------------------------
#endif
