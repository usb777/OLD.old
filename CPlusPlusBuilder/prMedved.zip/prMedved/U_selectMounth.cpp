//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "U_dm.h"
#include "U_gl.h"

#include "U_selectMounth.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TF_sm *F_sm;
String gl_c;
Graphics::TBitmap *pBitmap = new Graphics::TBitmap();

//---------------------------------------------------------------------------
__fastcall TF_sm::TF_sm(TComponent* Owner)
        : TForm(Owner)
{
    int x1;
           pBitmap->LoadFromFile("bigs.bmp");
           F_sm->TransparentColorValue=clWhite;   // !!! ���� ���� ��������
           F_sm->TransparentColor=true;

}
//---------------------------------------------------------------------------

void __fastcall TF_sm::FormActivate(TObject *Sender)
{

//gl_c=ComboBox1->Text;
//ComboBox1->Clear();
//ComboBox1->Items->Add("�� ��� ������");
/*for (int i=8;i<=19;i++)
 {
   ComboBox1->Items->Add(F_gl->DBGrid1->Columns->Items[i]->Title->Caption);
 }

ComboBox1->Text=gl_c;

*/
}
//---------------------------------------------------------------------------
void __fastcall TF_sm::BitBtn1Click(TObject *Sender)
{
  if (Spe1->Text>Spe2->Text)
   { ShowMessage("������� ������ ���������!");
     Spe1->Text="1" ;
     Spe2->Text="12" ;
     goto m1;
   }


 if (Spe1->Text==Spe2->Text)
    {
      String mesiac=F_gl->NumbToMounth(StrToInt(Spe1->Text));
      F_gl->MakeReport(F_gl->DBGrid1,DM1->Quchot,mesiac );
      Close();
    }

 if (Spe1->Text<Spe2->Text)
    {
      F_gl->MakeReport(F_gl->DBGrid1,DM1->Quchot,StrToInt(Spe1->Text),StrToInt(Spe2->Text));

     Close();
    }



m1:
}
//---------------------------------------------------------------------------
void __fastcall TF_sm::FormCreate(TObject *Sender)
{
/*

  gl_c=ComboBox1->Text;
  ComboBox1->Clear();
  ComboBox1->Items->Add("�� ��� ������");
 for (int i=6;i<=17;i++)
  {
    ComboBox1->Items->Add(F_gl->DBGrid1->Columns->Items[i]->Title->Caption);
  }

ComboBox1->Text=gl_c;

*/

}
//---------------------------------------------------------------------------

void __fastcall TF_sm::FormPaint(TObject *Sender)
{
 int x,y,x1,y1;
       x1=int(F_sm->ClientWidth/pBitmap->Width);
       y1=int(F_sm->ClientHeight/pBitmap->Height);
     for( x = 0 ; x<=x1;x++)
         { for (y = 0;y<=y1;y++)
              {
       F_sm->Canvas->Draw(int(x* pBitmap->Width),
       int(y * pBitmap->Height), pBitmap);
              }
         }

}
//---------------------------------------------------------------------------

void __fastcall TF_sm::BitBtn2Click(TObject *Sender)
{
Close();        
}
//---------------------------------------------------------------------------


void __fastcall TF_sm::Spe1Change(TObject *Sender)
{
Label5->Caption=F_gl->NumbToMounth(StrToInt(Spe1->Text));
}
//---------------------------------------------------------------------------


void __fastcall TF_sm::Spe2Change(TObject *Sender)
{
Label7->Caption=F_gl->NumbToMounth(StrToInt(Spe2->Text));

}
//---------------------------------------------------------------------------

