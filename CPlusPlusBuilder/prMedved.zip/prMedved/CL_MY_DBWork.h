class MY_DBWork
{

private:
public: TMY_DBWork();


      void  SortedBase(TADOQuery *q,String nameT,String sortfield)
      { q->Close();
        q->SQL->Clear();
        q->SQL->Text="select * from "+nameT+" order by "+sortfield;
        q->Open();
        q->Last();
       }


      void ZVyborkaVhoj(TADOQuery *q,String nameT,String izfield,String IskZn,String sortfield)
         {
          q->Close();
          q->SQL->Clear();
          q->SQL->Text="select * from "+nameT+" where "+izfield+" like  '%"+IskZn+"%'"+" order by "+sortfield;
  
          q->Open();
          q->Last();
         }


      void ZaprosNaVyborku(TADOQuery *q,String nameT,String izfield,String IskZn,String sortfield)
         {
          q->Close();
          q->SQL->Clear();
          q->SQL->Text="select * from "+nameT+" where "+izfield+"='"+IskZn+"'"+" order by "+sortfield;
          q->Open();
          q->Last();
         }

      void ZaprosNaVyborku(TADOQuery *q,String nameT,String izfield,float IskZn,String sortfield)
         {
           q->Close();
           q->SQL->Clear();
           q->SQL->Text="select * from "+nameT+" where "+izfield+"="+IskZn+""+" order by "+sortfield;
           q->Open();
           q->Last();
         }


       void ZaprosNaVyborkui(TADOQuery *q,String nameT,String izfield,int IskZn,String sortfield)
         {
           q->Close();
           q->SQL->Clear();
           q->SQL->Text="select * from "+nameT+" where "+izfield+"="+IskZn+""+" order by "+sortfield;
           q->Open();
           q->Last();
         }



      void ComboFulling(TADOQuery* q,TComboBox* cb,String field)
      {
        cb->Items->Clear();
        q->First();
       while (!q->Eof)
        {
            cb->Items->Add(q->FieldByName(field)->AsString);
            q->Next();
        }

       }
      void ComboFulling(TADOTable* t,TComboBox* cb,String field)
      {
        cb->Items->Clear();
        t->First();
       while (!t->Eof)
        {
            cb->Items->Add(t->FieldByName(field)->AsString);
            t->Next();
        }
       }

      void UpdateByOrder(TADOQuery* q,TADOQuery* qu,String tname,String pole,String ind)
      {
           qu->Close();
           qu->SQL->Clear();
           q->First();
           int i=1;
           while (!q->Eof)
           {

            qu->SQL->Add("update "+tname+" set "+pole+"="+IntToStr(i)+" where "+ind+"="+IntToStr(q->FieldByName("uchot_N")->AsInteger)) ;

           i++;
             q->Next();
           }
           qu->ExecSQL();
          try
           {q->Close();
            q->Open();
           }
         catch (Exception &e)
           {ShowMessage(e.Message);}

      }

    void DeleteDataTable (TADOQuery *q,TADOQuery *Qop,String tname)
     {

       q->Active=false;

        Qop->Close();
        Qop->SQL->Clear();
        Qop->SQL->Text="DELETE "+tname+".* FROM "+tname;
        Qop->ExecSQL();

       //q->Active=true;
         q->Close();
         q->Open();
     }



}   ;
