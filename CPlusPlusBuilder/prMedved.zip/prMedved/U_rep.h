//---------------------------------------------------------------------------

#ifndef U_repH
#define U_repH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <QuickRpt.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
#include <QRCtrls.hpp>
//---------------------------------------------------------------------------
class TF_QRep : public TForm
{
__published:	// IDE-managed Components
        TQuickRep *QuickRep1;
        TADOTable *QTuchot;
        TQRBand *QRBand1;
        TQRSubDetail *QRSubDetail1;
        TQRLabel *QRLabel1;
        TQRLabel *QRLabel2;
        TQRLabel *QRLabel3;
        TQRLabel *QRLabel4;
        TQRLabel *QRLabel5;
        TQRLabel *QRLabel6;
        TQRLabel *QRLabel7;
        TQRLabel *QRLabel8;
        TQRLabel *QRLabel9;
        TQRLabel *QRLabel10;
        TQRLabel *QRLabel11;
        TQRLabel *QRLabel12;
        TQRLabel *QRLabel13;
        TQRLabel *QRLabel14;
        TQRLabel *QRLabel15;
        TQRLabel *QRLabel16;
        TQRShape *QRShape1;
        TQRDBText *QRDBText2;
        TQRShape *QRShape2;
        TQRDBText *QRDBText1;
        TQRShape *QRShape3;
        TQRDBText *QRDBText3;
        TQRShape *QRShape4;
        TQRDBText *QRDBText4;
        TQRDBText *QRDBText5;
        TQRShape *QRShape5;
        TQRShape *QRShape6;
        TQRShape *QRShape7;
        TQRShape *QRShape8;
        TQRShape *QRShape9;
        TQRShape *QRShape10;
        TQRShape *QRShape11;
        TQRShape *QRShape12;
        TQRShape *QRShape13;
        TQRShape *QRShape14;
        TQRShape *QRShape15;
        TQRShape *QRShape16;
        TQRDBText *QRDBText6;
        TQRDBText *QRDBText7;
        TQRDBText *QRDBText8;
        TQRDBText *QRDBText9;
        TQRDBText *QRDBText10;
        TQRDBText *QRDBText11;
        TQRDBText *QRDBText12;
        TQRDBText *QRDBText13;
        TQRDBText *QRDBText14;
        TQRDBText *QRDBText15;
        TQRDBText *QRDBText16;
        TQRChildBand *QRChildBand1;
        TQRSysData *QRSysData1;
        TQRLabel *QRLabel17;
private:	// User declarations
public:		// User declarations
        __fastcall TF_QRep(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_QRep *F_QRep;
//---------------------------------------------------------------------------
#endif
