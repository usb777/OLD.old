//---------------------------------------------------------------------------

#ifndef U_spr_typeH
#define U_spr_typeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <DBCtrls.hpp>
#include <ExtCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TF_type : public TForm
{
__published:	// IDE-managed Components
        TStatusBar *StatusBar1;
        TPanel *Panel1;
        TPanel *Panel2;
        TDBGrid *DBGrid1;
        TImage *Image1;
        TDBNavigator *DBNavigator1;
        void __fastcall DBGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
public:		// User declarations
        __fastcall TF_type(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_type *F_type;
//---------------------------------------------------------------------------
#endif
