//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_spr_post.h"
#include "U_dm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "U_spr_type"
#pragma resource "*.dfm"
TF_post *F_post;
//---------------------------------------------------------------------------
__fastcall TF_post::TF_post(TComponent* Owner)
        : TF_type(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TF_post::DBGrid1KeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
switch (Key)
  {
    case 27: {Close(); break;}
  }
}
//---------------------------------------------------------------------------
