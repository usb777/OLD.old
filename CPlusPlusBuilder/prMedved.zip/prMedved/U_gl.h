//---------------------------------------------------------------------------

#ifndef U_glH
#define U_glH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <ComCtrls.hpp>
#include <Buttons.hpp>
#include <Menus.hpp>
#include <ADODB.hpp>
#include <DB.hpp>

#include <Inifiles.hpp>

//---------------------------------------------------------------------------
class TF_gl : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TDBGrid *DBGrid1;
        TStatusBar *StatusBar1;
        TPanel *Panel3;
        TDBNavigator *DBNavigator1;
        TMainMenu *MainMenu1;
        TMenuItem *N1;
        TMenuItem *N2;
        TMenuItem *N3;
        TMenuItem *N4;
        TMenuItem *N5;
        TMenuItem *N6;
        TMenuItem *N7;
        TPanel *Panel2;
        TComboBox *CBnaim;
        TComboBox *CBcena;
        TComboBox *CByear;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TComboBox *CBtype;
        TLabel *Label4;
        TSpeedButton *SpeedButton1;
        TMenuItem *N8;
        TLabel *Label5;
        TComboBox *CBpost;
        TSpeedButton *SpeedButton2;
        TMenuItem *Excel1;
        TMenuItem *N9;
        TMenuItem *N10;
        TMenuItem *N11;
        TMenuItem *N12;
        TMenuItem *N13;
        TMenuItem *N14;
        TMenuItem *N15;
        TMenuItem *N16;
        TMenuItem *N17;
        TMenuItem *N18;
        TMenuItem *N19;
        TMenuItem *N20;
        TMenuItem *N21;
        TMenuItem *N22;
        TMenuItem *N23;
        TADOQuery *Qop;
        void __fastcall N2Click(TObject *Sender);
        void __fastcall DBGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall N4Click(TObject *Sender);
        void __fastcall N7Click(TObject *Sender);
        void __fastcall CByearChange(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall CBcenaChange(TObject *Sender);
        void __fastcall CBnaimChange(TObject *Sender);
        void __fastcall CBtypeChange(TObject *Sender);
        void __fastcall N8Click(TObject *Sender);
        void __fastcall CBpostChange(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall N10Click(TObject *Sender);
        void __fastcall Excel1Click(TObject *Sender);
        void __fastcall N12Click(TObject *Sender);
        void __fastcall N13Click(TObject *Sender);
        void __fastcall N14Click(TObject *Sender);
        void __fastcall N15Click(TObject *Sender);
        void __fastcall N16Click(TObject *Sender);
        void __fastcall DBGrid1EditButtonClick(TObject *Sender);
        void __fastcall N18Click(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall N6Click(TObject *Sender);
        void __fastcall N19Click(TObject *Sender);
        void __fastcall N22Click(TObject *Sender);
        void __fastcall N21Click(TObject *Sender);
        void __fastcall N23Click(TObject *Sender);
        


private:	// User declarations
              //  bool sort;
                String c[5];

public:		// User declarations
        __fastcall TF_gl(TComponent* Owner);

          void __fastcall ComboFulling(TADOQuery* q,TComboBox* cb,String field);
          void __fastcall ComboFulling(TADOTable* t,TComboBox* cb,String field);
          void __fastcall MakeReport(TDBGrid* dbg,TADOQuery* q1);
          void __fastcall MakeReport(TDBGrid* dbg,TADOQuery* q1,String mes);
          void __fastcall MakeReport(TDBGrid* dbg,TADOQuery* q1,int mnach,int mend);

          void __fastcall ExcelInit(String File,TADOQuery* q,TDBGrid* dbg);
          void __fastcall toExcelCell(int Row,int Column, AnsiString data);
          void __fastcall toExcelCell(int Row,int Column, Variant data) ;

          Variant App,Sh;
          int ln ;
          bool gl_s;
          int  gl_pos;

          void __fastcall  SaveIni(TDBGrid* dbg);
          void __fastcall  OpenIni(TDBGrid* dbg);
          String NumbToMounth(int mn);



};
//---------------------------------------------------------------------------
extern PACKAGE TF_gl *F_gl;
//---------------------------------------------------------------------------
#endif


