//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "U_spr_type.h"
#include "U_dm.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TF_type *F_type;
//---------------------------------------------------------------------------
__fastcall TF_type::TF_type(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TF_type::DBGrid1KeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
if (Key==27)
   { Close();
   }        
}
//---------------------------------------------------------------------------

