//---------------------------------------------------------------------------

#ifndef U_dmH
#define U_dmH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DB.hpp>
#include <IBDatabase.hpp>
#include <IBCustomDataSet.hpp>
#include <IBTable.hpp>
#include <IBQuery.hpp>
#include <ADODB.hpp>
//---------------------------------------------------------------------------
class TDM1 : public TDataModule
{
__published:	// IDE-managed Components
        TADOConnection *Adc1;
        TADOTable *Tuchot;
        TADOTable *Tnaim;
        TDataSource *DS1;
        TADOTable *TType;
        TAutoIncField *Tnaimnaim_kod;
        TWideStringField *Tnaimnaim_name;
        TIntegerField *Tnaimtype_kod;
        TAutoIncField *TTypetype_kod;
        TWideStringField *TTypetype_name;
        TADOQuery *Quchot;
        TAutoIncField *Quchotuchot_N;
        TBCDField *Quchotuchot_cena;
        TWideStringField *Quchotuchot_god;
        TIntegerField *QuchotDSDesigner;
        TIntegerField *QuchotDSDesigner2;
        TIntegerField *QuchotDSDesigner3;
        TIntegerField *QuchotDSDesigner4;
        TIntegerField *QuchotDSDesigner5;
        TIntegerField *QuchotDSDesigner6;
        TIntegerField *QuchotDSDesigner7;
        TIntegerField *QuchotDSDesigner8;
        TIntegerField *QuchotDSDesigner9;
        TIntegerField *QuchotDSDesigner10;
        TIntegerField *QuchotDSDesigner11;
        TIntegerField *QuchotDSDesigner12;
        TDataSource *DS2;
        TStringField *Tnaimtype_name;
        TDataSource *DStype;
        TADOQuery *Qnaim;
        TAutoIncField *Qnaimnaim_kod;
        TWideStringField *Qnaimnaim_name;
        TIntegerField *Qnaimtype_kod;
        TStringField *Qnaimtype_name;
        TDataSource *DSpost;
        TIntegerField *Quchotpost_kod;
        TADOQuery *Qpost;
        TADOTable *Tpost;
        TStringField *Quchotpost_name;
        TBCDField *Quchotuchot_sredm;
        TADOQuery *Qtype;
        TADOQuery *Qqnaim;
        TAutoIncField *AutoIncField1;
        TWideStringField *WideStringField1;
        TIntegerField *IntegerField1;
        TStringField *StringField1;
        TADOQuery *Qqpost;
        TADOQuery *Qqtype;
        TIntegerField *Quchottype_kod;
        TWideStringField *Quchotnaim_name;
        TStringField *Quchottype_name;
        TAutoIncField *Tuchotuchot_N;
        TWideStringField *Tuchotnaim_name;
        TBCDField *Tuchotuchot_cena;
        TWideStringField *Tuchotuchot_god;
        TBCDField *Tuchotuchot_sredm;
        TIntegerField *TuchotDSDesigner;
        TIntegerField *TuchotDSDesigner2;
        TIntegerField *TuchotDSDesigner3;
        TIntegerField *TuchotDSDesigner4;
        TIntegerField *TuchotDSDesigner5;
        TIntegerField *TuchotDSDesigner6;
        TIntegerField *TuchotDSDesigner7;
        TIntegerField *TuchotDSDesigner8;
        TIntegerField *TuchotDSDesigner9;
        TIntegerField *TuchotDSDesigner10;
        TIntegerField *TuchotDSDesigner11;
        TIntegerField *TuchotDSDesigner12;
        TIntegerField *Tuchotuchot_ind;
        TIntegerField *Tuchotpost_kod;
        TIntegerField *Tuchottype_kod;
        TIntegerField *Quchotuchot_ind;
        void __fastcall QuchotAfterDelete(TDataSet *DataSet);
        void __fastcall QnaimAfterDelete(TDataSet *DataSet);
        void __fastcall QuchotAfterPost(TDataSet *DataSet);
private:	// User declarations
public:		// User declarations
        __fastcall TDM1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDM1 *DM1;
//---------------------------------------------------------------------------
#endif
