//---------------------------------------------------------------------------

#ifndef U_rpoiskH
#define U_rpoiskH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TF_rpoisk : public TForm
{
__published:	// IDE-managed Components
        TEdit *Edit1;
        TEdit *Edit2;
        TBitBtn *BitBtn1;
        TImage *Image1;
        TBevel *Bevel1;
        TLabel *Label1;
        TLabel *Label2;
        TSpeedButton *SpeedButton5;
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
        void __fastcall Edit1KeyPress(TObject *Sender, char &Key);
        void __fastcall Edit2KeyPress(TObject *Sender, char &Key);
        void __fastcall SpeedButton5Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TF_rpoisk(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_rpoisk *F_rpoisk;
//---------------------------------------------------------------------------
#endif
