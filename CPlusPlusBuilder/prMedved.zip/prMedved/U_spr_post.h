//---------------------------------------------------------------------------

#ifndef U_spr_postH
#define U_spr_postH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "U_spr_type.h"
#include <ComCtrls.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TF_post : public TF_type
{
__published:	// IDE-managed Components
        void __fastcall DBGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
public:		// User declarations
        __fastcall TF_post(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_post *F_post;
//---------------------------------------------------------------------------
#endif
