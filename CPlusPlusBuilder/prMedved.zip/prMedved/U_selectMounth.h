//---------------------------------------------------------------------------

#ifndef U_selectMounthH
#define U_selectMounthH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
class TF_sm : public TForm
{
__published:	// IDE-managed Components
        TBitBtn *BitBtn1;
        TBitBtn *BitBtn2;
        TLabel *Label1;
        TLabel *Label2;
        TCSpinEdit *Spe1;
        TCSpinEdit *Spe2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormPaint(TObject *Sender);
        void __fastcall BitBtn2Click(TObject *Sender);
        void __fastcall Spe1Change(TObject *Sender);
        void __fastcall Spe2Change(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TF_sm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_sm *F_sm;
//---------------------------------------------------------------------------
#endif
